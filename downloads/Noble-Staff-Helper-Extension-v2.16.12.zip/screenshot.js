// Captures and caches the initial full Leaflet view, then copies it without
// moving or zooming the live map.
(() => {
  "use strict";

  const BTN_ID = "np-ext-copy-map-btn";
  const FULLSCREEN_BTN_ID = "np-ext-map-fullscreen-btn";
  const MAP_CORNER_TOOLS_ID = "np-map-corner-tools";
  const WRAP_ID = "np-ext-copy-map-wrap";
  const TOAST_ID = "np-ext-copy-map-toast";
  const MAX_CANVAS_PIXELS = 14_000_000;
  const MAX_CAPTURE_SCALE = 2;
  const MIN_CAPTURE_SCALE = 1.75;
  const READY_TIMEOUT = 12_000;
  const QUIET_WINDOW = 700;
  const MIN_READY_AGE = 1_100;
  const TEAM_FALLBACK_AGE = 1_800;
  const OUTPUT_MAP_SIZE = 900;
  const FRAME_PADDING_RATIO = 0.028;
  const MIN_FRAME_PADDING = 24;
  const BACKGROUND_COLOR_DISTANCE = 54;

  let settings = NPSettings.cloneDefaults();
  let activeState = null;
  let generation = 0;
  let copyInProgress = false;
  let cachedBadgeRow = null;
  let lastRoute = null;
  let fullscreenMap = null;

  const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
  const sessionKey = () => `${location.pathname}${location.search}`;
  const isSessionMapPage = () => /^\/sessions\/[^/?#]+/i.test(location.pathname);
  lastRoute = sessionKey();

  function visibleMapElements() {
    return Array.from(document.querySelectorAll(".leaflet-container, [class*='leaflet-container']"))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return rect.width >= 280 && rect.height >= 240 && style.display !== "none" && style.visibility !== "hidden";
      })
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return br.width * br.height - ar.width * ar.height;
      });
  }

  function findMapElement() {
    return visibleMapElements()[0] || null;
  }

  function captureSurfaceForMap(mapElement) {
    const parent = mapElement?.parentElement;
    if (!parent) return mapElement;
    const mapRect = mapElement.getBoundingClientRect();
    const parentRect = parent.getBoundingClientRect();
    const sameSurface =
      Math.abs(mapRect.width - parentRect.width) <= 3 &&
      Math.abs(mapRect.height - parentRect.height) <= 3;
    const hasNobleBackdrop = Array.from(parent.children).some((child) =>
      child !== mapElement && /nobleprac\.com/i.test(child.textContent || "")
    );
    return sameSurface && hasNobleBackdrop ? parent : mapElement;
  }

  function captureBackground(surface) {
    const value = surface ? getComputedStyle(surface).backgroundColor : "";
    return value && value !== "rgba(0, 0, 0, 0)" && value !== "transparent"
      ? value
      : "#0e3470";
  }

  function toast(message) {
    let element = document.getElementById(TOAST_ID);
    if (!element) {
      element = document.createElement("div");
      element.id = TOAST_ID;
      Object.assign(element.style, {
        position: "fixed", left: "50%", bottom: "24px", transform: "translateX(-50%)", zIndex: "2147483647",
        padding: "9px 12px", border: "1px solid rgba(255,191,64,.32)", borderRadius: "7px",
        color: "#fff", background: "#0f1c25", boxShadow: "0 10px 30px rgba(0,0,0,.35)",
        font: "600 12px/1.35 system-ui,-apple-system,Segoe UI,sans-serif", display: "none", pointerEvents: "none"
      });
      document.body.appendChild(element);
    }
    element.textContent = message;
    element.style.display = "block";
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { element.style.display = "none"; }, 1900);
  }

  function mapButtonMarkup(label = "Copy Map") {
    return `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="4" y="4" width="16" height="16" rx="2.5" stroke="currentColor" stroke-width="1.8"/>
        <circle cx="15.8" cy="8.4" r="1.35" fill="currentColor"/>
        <path d="m7.5 16 3.2-3.5 2.6 2.35 2.05-1.9L18 16" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
      <span>${label}</span>
    `;
  }

  function fullscreenIcon(active = false) {
    if (active) {
      return `
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M9 9H4M9 9V4m6 5h5m-5 0V4M9 15H4m5 0v5m6-5h5m-5 0v5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      `;
    }
    return `
      <svg width="17" height="17" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M9 4H4v5M15 4h5v5M9 20H4v-5m11 5h5v-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>
    `;
  }

  function refreshMapLayout() {
    requestAnimationFrame(() => {
      window.dispatchEvent(new Event("resize"));
      setTimeout(() => window.dispatchEvent(new Event("resize")), 180);
    });
  }

  function updateFullscreenButton() {
    const button = document.getElementById(FULLSCREEN_BTN_ID);
    if (!button) return;
    const active = Boolean(fullscreenMap);
    const state = active ? "active" : "idle";
    if (button.dataset.npFullscreenState !== state || !button.querySelector("svg")) {
      button.innerHTML = fullscreenIcon(active);
      button.dataset.npFullscreenState = state;
    }
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-pressed", String(active));
    button.setAttribute("aria-label", active ? "Exit map full screen" : "Open map full screen");
    button.title = active ? "Exit full screen (Esc)" : "Open map full screen";
  }

  function exitMapFullscreen({ restoreFocus = true } = {}) {
    if (!fullscreenMap) return;
    const mapElement = fullscreenMap;
    fullscreenMap = null;
    mapElement.classList.remove("np-map-fullscreen-active");
    document.documentElement.classList.remove("np-map-fullscreen-open");
    document.body?.classList.remove("np-map-fullscreen-open");
    updateFullscreenButton();
    refreshMapLayout();
    const button = document.getElementById(FULLSCREEN_BTN_ID);
    if (restoreFocus && button?.isConnected) button.focus({ preventScroll: true });
  }

  function enterMapFullscreen(trigger) {
    const mapElement = findMapElement();
    if (!mapElement) {
      toast("Map is not ready yet.");
      return;
    }
    if (fullscreenMap === mapElement) {
      exitMapFullscreen();
      return;
    }
    if (fullscreenMap) exitMapFullscreen({ restoreFocus: false });

    fullscreenMap = mapElement;
    mapElement.classList.add("np-map-fullscreen-active");
    document.documentElement.classList.add("np-map-fullscreen-open");
    document.body?.classList.add("np-map-fullscreen-open");
    updateFullscreenButton();
    refreshMapLayout();
  }

  function makeFullscreenButton() {
    const button = document.createElement("button");
    button.id = FULLSCREEN_BTN_ID;
    button.type = "button";
    button.className = "np-map-tool-button np-map-round-button np-map-fullscreen-button";
    button.innerHTML = fullscreenIcon(false);
    button.title = "Open map full screen";
    button.setAttribute("aria-label", "Open map full screen");
    button.setAttribute("aria-pressed", "false");
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      enterMapFullscreen(button);
    });
    return button;
  }

  function ensureMapCornerTools(mapElement) {
    let tools = document.getElementById(MAP_CORNER_TOOLS_ID);
    if (!tools) {
      tools = document.createElement("div");
      tools.id = MAP_CORNER_TOOLS_ID;
      tools.className = "leaflet-control np-map-corner-tools";
      document.body?.appendChild(tools);
    } else if (tools.parentElement !== document.body) {
      document.body?.appendChild(tools);
    }
    return tools;
  }

  function placeFullscreenButton() {
    if (!isSessionMapPage()) {
      exitMapFullscreen({ restoreFocus: false });
      document.getElementById(FULLSCREEN_BTN_ID)?.remove();
      return;
    }
    const mapElement = findMapElement();
    if (!mapElement) return;
    const tools = ensureMapCornerTools(mapElement);
    if (!tools) return;
    let button = document.getElementById(FULLSCREEN_BTN_ID);
    if (!button) {
      button = makeFullscreenButton();
      tools.appendChild(button);
    } else if (button.parentElement !== tools) {
      tools.appendChild(button);
    }
    updateFullscreenButton();
  }

  function updateButton() {
    const button = document.getElementById(BTN_ID);
    if (!button || copyInProgress) return;
    const ready = Boolean(activeState?.blob);
    // Avoid replacing identical children: the page-level MutationObserver
    // would otherwise schedule this function again forever.
    if (!button.querySelector("svg") || button.querySelector("span")?.textContent !== "Copy Map") {
      button.innerHTML = mapButtonMarkup();
    }
    button.disabled = false;
    button.classList.toggle("np-map-snapshot-ready", Boolean(ready));
    button.title = ready
      ? "Copy the full map captured when this session loaded"
      : activeState?.status === "failed" || activeState?.status === "missed"
        ? "Full-map snapshot unavailable; refresh the session before zooming"
        : "The initial full-map snapshot is being prepared";
  }

  function makeButton() {
    const button = document.createElement("button");
    button.id = BTN_ID;
    button.type = "button";
    button.className = "np-map-tool-button";
    button.innerHTML = mapButtonMarkup();
    Object.assign(button.style, {
      display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "7px", minHeight: "34px",
      padding: "8px 11px", border: "1px solid rgba(255,255,255,.14)", borderRadius: "6px",
      color: "#fff", background: "#131e27", cursor: "pointer", userSelect: "none",
      font: "600 12px/1 system-ui,-apple-system,Segoe UI,sans-serif", whiteSpace: "nowrap"
    });
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      copyCachedMap(button);
    });
    return button;
  }

  function textHas(element, needle) {
    return (element?.innerText || "").toLowerCase().includes(needle);
  }

  function hasMarkedStatus(element) {
    return /\b(?:teams?|players?)\s+marked\b/i.test(element?.innerText || "");
  }

  function findBadgeRow() {
    if (
      cachedBadgeRow?.isConnected &&
      textHas(cachedBadgeRow, "contested drops") &&
      hasMarkedStatus(cachedBadgeRow)
    ) return cachedBadgeRow;

    let best = null;
    let smallestArea = Infinity;
    for (const element of document.querySelectorAll("div, header, nav, section")) {
      const text = (element.innerText || "").toLowerCase();
      if (!text.includes("contested drops") || !/\b(?:teams?|players?)\s+marked\b/i.test(text)) continue;
      const rect = element.getBoundingClientRect();
      if (rect.width < 200 || rect.height < 20 || rect.height > 160) continue;
      const area = rect.width * rect.height;
      if (area < smallestArea) {
        best = element;
        smallestArea = area;
      }
    }
    if (best) {
      cachedBadgeRow = best;
      return best;
    }

    const contested = Array.from(document.querySelectorAll("button, a, div, span")).find((element) => textHas(element, "contested drops"));
    for (let current = contested, depth = 0; current && depth < 10; current = current.parentElement, depth++) {
      if (!hasMarkedStatus(current)) continue;
      const rect = current.getBoundingClientRect();
      if (rect.width > 200 && rect.height > 20 && rect.height < 160) {
        cachedBadgeRow = current;
        return current;
      }
    }
    return null;
  }

  function removeButton() {
    document.getElementById(WRAP_ID)?.remove();
    document.getElementById(BTN_ID)?.remove();
  }

  function placeButton() {
    if (fullscreenMap && !fullscreenMap.isConnected) exitMapFullscreen({ restoreFocus: false });
    if (!settings.mapCopy || !isSessionMapPage()) {
      removeButton();
      return;
    }
    const existingWrapper = document.getElementById(WRAP_ID);
    if (existingWrapper) {
      updateButton();
      return;
    }
    const row = findBadgeRow();
    if (!row) return;

    const wrapper = document.createElement("span");
    wrapper.id = WRAP_ID;
    Object.assign(wrapper.style, { display: "inline-flex", alignItems: "center", flex: "0 0 auto", marginRight: "6px" });
    wrapper.appendChild(makeButton());

    const computed = getComputedStyle(row);
    if (computed.display !== "flex" && computed.display !== "inline-flex") row.style.display = "flex";
    row.style.alignItems ||= "center";
    row.style.gap ||= "10px";
    row.insertAdjacentElement("afterbegin", wrapper);
    updateButton();
  }

  function teamStatus() {
    const row = findBadgeRow();
    const text = row?.innerText || "";
    const match = text.match(/(\d+)\s*\/\s*(\d+)\s*(?:Teams?|Players?) Marked/i);
    return match ? { marked: Number(match[1]), total: Number(match[2]) } : null;
  }

  function teamStatusText() {
    const status = teamStatus();
    return status ? `${status.marked}/${status.total}` : "";
  }

  function viewSignature(mapElement) {
    const selectors = [
      ".leaflet-map-pane",
      ".leaflet-overlay-pane",
      ".leaflet-marker-pane",
      ".leaflet-shadow-pane"
    ];
    const rect = mapElement.getBoundingClientRect();
    const geometry = `${Math.round(rect.width)}x${Math.round(rect.height)}`;
    return `${geometry}|${selectors.map((selector) => {
      const element = mapElement.querySelector(selector);
      return `${selector}:${element?.getAttribute("style") || ""}`;
    }).join("|")}`;
  }

  function contentSignature(mapElement) {
    const overlays = Array.from(mapElement.querySelectorAll(".leaflet-overlay-pane img, img.leaflet-image-layer"));
    const markers = Array.from(mapElement.querySelectorAll(".leaflet-marker-pane img, .leaflet-marker-icon"));
    const paths = Array.from(mapElement.querySelectorAll(".leaflet-overlay-pane path, .leaflet-marker-pane path"));
    return [
      viewSignature(mapElement),
      teamStatusText(),
      overlays.map((image) => `${image.currentSrc || image.src}|${image.complete}|${image.naturalWidth}|${image.getAttribute("style") || ""}`).join(","),
      markers.map((image) => `${image.currentSrc || image.src}|${image.getAttribute("style") || ""}|${image.textContent || ""}`).join(","),
      paths.map((path) => path.getAttribute("d") || "").join(",")
    ].join("||");
  }

  function allImagesReady(mapElement, visibleElapsed) {
    const overlays = Array.from(mapElement.querySelectorAll(".leaflet-overlay-pane img, img.leaflet-image-layer"));
    if (!overlays.length) return false;
    const markerImages = Array.from(mapElement.querySelectorAll(".leaflet-marker-pane img"));
    const overlaysReady = overlays.every((image) => image.complete && image.naturalWidth > 0);
    if (!overlaysReady) return false;

    // A single expired Discord avatar used to block large 24/7 sessions
    // forever. Wait for marker requests to settle, but do not require every
    // remote avatar to decode successfully before the map itself can capture.
    const markersSettled = markerImages.every((image) => image.complete);
    return markersSettled || visibleElapsed >= 2_200;
  }

  function stateIsCurrent(state) {
    return activeState === state && state.generation === generation && state.key === sessionKey() && state.mapElement.isConnected;
  }

  async function waitForInitialMap(state) {
    let remaining = READY_TIMEOUT;
    let visibleElapsed = 0;
    let previousTick = performance.now();
    let lastSignature = "";
    let quietSince = 0;

    while (remaining > 0) {
      if (!stateIsCurrent(state)) throw new Error("Session changed");
      if (state.userInteracted) throw new Error("Initial map view was changed");

      const mapElement = state.mapElement;
      const rect = mapElement.getBoundingClientRect();
      const now = performance.now();
      const documentVisible = document.visibilityState !== "hidden";
      const elapsed = now - previousTick;
      previousTick = now;
      if (documentVisible) {
        remaining -= elapsed;
        visibleElapsed += elapsed;
      }
      const visible = documentVisible && rect.width >= 280 && rect.height >= 240;
      const stable = !mapElement.classList.contains("leaflet-zoom-anim");
      const signature = contentSignature(mapElement);
      if (signature !== lastSignature) {
        lastSignature = signature;
        quietSince = performance.now();
      }

      const teams = teamStatus();
      const markerCount = mapElement.querySelectorAll(".leaflet-marker-pane .leaflet-marker-icon").length;
      // Noble's redesigned counter is a player count, while each marker is a
      // team/drop. Comparing the two made every duo/trio map wait forever.
      const hasTeamState = teams
        ? teams.marked > 0
          ? markerCount > 0
          : visibleElapsed >= 900
        : visibleElapsed > TEAM_FALLBACK_AGE;
      if (
        visible &&
        stable &&
        visibleElapsed >= MIN_READY_AGE &&
        allImagesReady(mapElement, visibleElapsed) &&
        hasTeamState &&
        performance.now() - quietSince >= QUIET_WINDOW
      ) {
        return signature;
      }
      await wait(60);
    }
    throw new Error("Map assets did not finish loading");
  }

  function captureScale(mapElement) {
    const rect = mapElement.getBoundingClientRect();
    const desired = Math.min(MAX_CAPTURE_SCALE, Math.max(MIN_CAPTURE_SCALE, window.devicePixelRatio || 1));
    const pixelLimitScale = Math.sqrt(MAX_CANVAS_PIXELS / Math.max(1, rect.width * rect.height));
    return Math.min(desired, pixelLimitScale);
  }

  function canvasToBlob(canvas) {
    return new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
  }

  function canvasLooksUsable(canvas) {
    if (!canvas || canvas.width < 280 || canvas.height < 240) return false;
    try {
      const context = canvas.getContext("2d", { willReadFrequently: true });
      if (!context) return false;
      let opaque = 0;
      const colors = new Set();
      for (let y = 1; y <= 6; y++) {
        for (let x = 1; x <= 8; x++) {
          const px = Math.min(canvas.width - 1, Math.floor((canvas.width * x) / 9));
          const py = Math.min(canvas.height - 1, Math.floor((canvas.height * y) / 7));
          const data = context.getImageData(px, py, 1, 1).data;
          if (data[3] > 32) opaque++;
          colors.add(`${data[0] >> 4}:${data[1] >> 4}:${data[2] >> 4}:${data[3] >> 5}`);
        }
      }
      return opaque >= 28 && colors.size >= 4;
    } catch {
      return false;
    }
  }

  function averageCornerColor(pixels, width, height, cornerX, cornerY) {
    const samples = [];
    const xStart = cornerX === 0 ? 0.012 : 0.94;
    const yStart = cornerY === 0 ? 0.012 : 0.94;

    for (let yStep = 0; yStep < 5; yStep++) {
      for (let xStep = 0; xStep < 5; xStep++) {
        const xRatio = xStart + xStep * 0.011;
        const yRatio = yStart + yStep * 0.011;
        const x = Math.max(0, Math.min(width - 1, Math.round(width * xRatio)));
        const y = Math.max(0, Math.min(height - 1, Math.round(height * yRatio)));
        const index = (y * width + x) * 4;
        if (pixels[index + 3] > 32) {
          samples.push([pixels[index], pixels[index + 1], pixels[index + 2]]);
        }
      }
    }

    if (!samples.length) return [10, 21, 32];
    return [0, 1, 2].map((channel) =>
      Math.round(samples.reduce((total, sample) => total + sample[channel], 0) / samples.length)
    );
  }

  function findVisibleMapBounds(canvas) {
    try {
      const context = canvas.getContext("2d", { willReadFrequently: true });
      if (!context) return null;

      const { width, height } = canvas;
      const pixels = context.getImageData(0, 0, width, height).data;
      const corners = [
        averageCornerColor(pixels, width, height, 0, 0),
        averageCornerColor(pixels, width, height, 1, 0),
        averageCornerColor(pixels, width, height, 0, 1),
        averageCornerColor(pixels, width, height, 1, 1)
      ];
      const stride = Math.max(2, Math.floor(Math.max(width, height) / 720));
      let left = width;
      let top = height;
      let right = -1;
      let bottom = -1;
      let visibleSamples = 0;

      for (let y = 0; y < height; y += stride) {
        const yMix = height > 1 ? y / (height - 1) : 0;
        for (let x = 0; x < width; x += stride) {
          const xMix = width > 1 ? x / (width - 1) : 0;
          const topRed = corners[0][0] + (corners[1][0] - corners[0][0]) * xMix;
          const topGreen = corners[0][1] + (corners[1][1] - corners[0][1]) * xMix;
          const topBlue = corners[0][2] + (corners[1][2] - corners[0][2]) * xMix;
          const bottomRed = corners[2][0] + (corners[3][0] - corners[2][0]) * xMix;
          const bottomGreen = corners[2][1] + (corners[3][1] - corners[2][1]) * xMix;
          const bottomBlue = corners[2][2] + (corners[3][2] - corners[2][2]) * xMix;
          const backgroundRed = topRed + (bottomRed - topRed) * yMix;
          const backgroundGreen = topGreen + (bottomGreen - topGreen) * yMix;
          const backgroundBlue = topBlue + (bottomBlue - topBlue) * yMix;
          const index = (y * width + x) * 4;
          if (pixels[index + 3] <= 32) continue;

          const colorDistance =
            Math.abs(pixels[index] - backgroundRed) +
            Math.abs(pixels[index + 1] - backgroundGreen) +
            Math.abs(pixels[index + 2] - backgroundBlue);
          if (colorDistance <= BACKGROUND_COLOR_DISTANCE) continue;

          visibleSamples++;
          left = Math.min(left, x);
          top = Math.min(top, y);
          right = Math.max(right, x);
          bottom = Math.max(bottom, y);
        }
      }

      if (
        visibleSamples < 80 ||
        right <= left ||
        bottom <= top ||
        right - left < width * 0.15 ||
        bottom - top < height * 0.15
      ) {
        return null;
      }

      return {
        left,
        top,
        right: Math.min(width, right + stride),
        bottom: Math.min(height, bottom + stride),
        background: corners.reduce(
          (result, corner) => result.map((value, channel) => value + corner[channel] / corners.length),
          [0, 0, 0]
        )
      };
    } catch {
      return null;
    }
  }

  function frameMapAsSquare(canvas) {
    const { width, height } = canvas;
    const bounds = findVisibleMapBounds(canvas);
    const fallbackSide = Math.min(width, height);
    const padding = Math.max(MIN_FRAME_PADDING, Math.round(fallbackSide * FRAME_PADDING_RATIO));
    const contentWidth = bounds ? bounds.right - bounds.left : 0;
    const contentHeight = bounds ? bounds.bottom - bounds.top : 0;
    const neededSide = bounds
      ? Math.ceil(Math.max(contentWidth, contentHeight) + padding * 2)
      : fallbackSide;
    const side = Math.max(fallbackSide, neededSide);
    const centerX = bounds ? (bounds.left + bounds.right) / 2 : width / 2;
    const centerY = bounds ? (bounds.top + bounds.bottom) / 2 : height / 2;
    const frameLeft = Math.round(centerX - side / 2);
    const frameTop = Math.round(centerY - side / 2);
    const sourceLeft = Math.max(0, frameLeft);
    const sourceTop = Math.max(0, frameTop);
    const sourceRight = Math.min(width, frameLeft + side);
    const sourceBottom = Math.min(height, frameTop + side);
    const sourceWidth = Math.max(0, sourceRight - sourceLeft);
    const sourceHeight = Math.max(0, sourceBottom - sourceTop);

    const sourceFrame = document.createElement("canvas");
    sourceFrame.width = side;
    sourceFrame.height = side;
    const context = sourceFrame.getContext("2d");
    if (!context) return canvas;

    const background = bounds?.background || [10, 21, 32];
    context.fillStyle = `rgb(${background.map((channel) => Math.round(channel)).join(",")})`;
    context.fillRect(0, 0, side, side);
    if (sourceWidth && sourceHeight) {
      context.drawImage(
        canvas,
        sourceLeft,
        sourceTop,
        sourceWidth,
        sourceHeight,
        sourceLeft - frameLeft,
        sourceTop - frameTop,
        sourceWidth,
        sourceHeight
      );
    }
    if (side === OUTPUT_MAP_SIZE) return sourceFrame;

    // A fixed final size keeps markers, labels, and drop outlines visually
    // consistent across 1080p, ultrawide, and high-DPI monitors.
    const framed = document.createElement("canvas");
    framed.width = OUTPUT_MAP_SIZE;
    framed.height = OUTPUT_MAP_SIZE;
    const output = framed.getContext("2d");
    if (!output) return sourceFrame;
    output.imageSmoothingEnabled = true;
    output.imageSmoothingQuality = "high";
    output.fillStyle = context.fillStyle;
    output.fillRect(0, 0, OUTPUT_MAP_SIZE, OUTPUT_MAP_SIZE);
    output.drawImage(sourceFrame, 0, 0, OUTPUT_MAP_SIZE, OUTPUT_MAP_SIZE);
    return framed;
  }

  function translationFromTransform(value) {
    const text = String(value || "").trim();
    if (!text || text === "none") return null;
    const matrix = text.match(/^matrix\(\s*([^)]*)\)$/i);
    if (matrix) {
      const parts = matrix[1].split(",").map(Number);
      if (
        parts.length === 6 &&
        parts.every(Number.isFinite) &&
        Math.abs(parts[0] - 1) < 0.0001 &&
        Math.abs(parts[1]) < 0.0001 &&
        Math.abs(parts[2]) < 0.0001 &&
        Math.abs(parts[3] - 1) < 0.0001
      ) return { x: parts[4], y: parts[5] };
    }
    const matrix3d = text.match(/^matrix3d\(\s*([^)]*)\)$/i);
    if (matrix3d) {
      const parts = matrix3d[1].split(",").map(Number);
      const identityIndexes = [0, 5, 10, 15];
      const zeroIndexes = [1, 2, 3, 4, 6, 7, 8, 9, 11, 14];
      if (
        parts.length === 16 &&
        parts.every(Number.isFinite) &&
        identityIndexes.every((index) => Math.abs(parts[index] - 1) < 0.0001) &&
        zeroIndexes.every((index) => Math.abs(parts[index]) < 0.0001)
      ) return { x: parts[12], y: parts[13] };
    }
    return null;
  }

  function flattenLeafletTranslations(mapElement, clone) {
    // html2canvas can apply nested Leaflet translate3d transforms out of sync,
    // leaving SVG drop boxes detached from the image. Convert pure Leaflet
    // translations to equivalent top/left offsets in the cloned document.
    const selector = [
      ".leaflet-map-pane",
      ".leaflet-zoom-animated",
      ".leaflet-marker-icon",
      ".leaflet-marker-shadow"
    ].join(",");
    const baseLayer = (element) => !element.closest(".leaflet-marker-pane, .leaflet-shadow-pane, .leaflet-control-container, .leaflet-overlay-pane svg");
    const originals = Array.from(mapElement.querySelectorAll(selector)).filter(baseLayer);
    const clones = Array.from(clone.querySelectorAll(selector)).filter(baseLayer);
    for (let index = 0; index < Math.min(originals.length, clones.length); index++) {
      const original = originals[index];
      const cloned = clones[index];
      const translation = translationFromTransform(getComputedStyle(original).transform);
      if (!translation) continue;
      const style = getComputedStyle(original);
      // offsetLeft/offsetTop already include the icon's negative anchor
      // margins. Using them as CSS left/top applies that anchor twice.
      const offsetLeft = Number.parseFloat(style.left) || 0;
      const offsetTop = Number.parseFloat(style.top) || 0;
      cloned.style.left = `${offsetLeft + translation.x}px`;
      cloned.style.top = `${offsetTop + translation.y}px`;
      cloned.style.transform = "none";
      cloned.style.webkitTransform = "none";
    }
  }

  function normalizeIndividualTransforms(mapElement, clone) {
    // Tailwind v4 uses the individual translate/rotate/scale properties.
    // html2canvas only understands the older combined transform property,
    // so names with translate: -50% otherwise start at the avatar's center.
    const baseLayer = (element) => !element.closest(".leaflet-marker-pane, .leaflet-shadow-pane, .leaflet-control-container, .leaflet-overlay-pane svg");
    const originals = [mapElement, ...mapElement.querySelectorAll("*")].filter(baseLayer);
    const clones = [clone, ...clone.querySelectorAll("*")].filter(baseLayer);
    for (let index = 0; index < originals.length; index++) {
      const original = originals[index];
      const cloned = clones[index];
      if (!cloned) continue;
      const style = getComputedStyle(original);
      const transforms = [];
      if (style.translate && style.translate !== "none") {
        const [x, y = "0px", z = "0px"] = style.translate.split(/\s+/);
        transforms.push(`translate3d(${x}, ${y}, ${z})`);
      }
      if (style.rotate && style.rotate !== "none") {
        const values = style.rotate.split(/\s+/);
        transforms.push(values.length === 1 ? `rotate(${values[0]})` :
          values.length === 2 ? `rotate${values[0].toUpperCase()}(${values[1]})` :
            `rotate3d(${values.join(", ")})`);
      }
      if (style.scale && style.scale !== "none") {
        const [x, y = x, z = "1"] = style.scale.split(/\s+/);
        transforms.push(`scale3d(${x}, ${y}, ${z})`);
      }
      if (!transforms.length) continue;
      // Use the clone's transform: pure Leaflet translations may already
      // have been flattened above. Retain the original transform origin.
      const existing = cloned.ownerDocument.defaultView.getComputedStyle(cloned).transform;
      if (existing && existing !== "none") transforms.push(existing);
      cloned.style.setProperty("translate", "none", "important");
      cloned.style.setProperty("rotate", "none", "important");
      cloned.style.setProperty("scale", "none", "important");
      cloned.style.setProperty("transform", transforms.join(" "), "important");
    }
  }

  function fullMapCaptureRect(surface, mapElement) {
    const viewport = surface.getBoundingClientRect();
    const image = mapElement.querySelector("img.leaflet-image-layer");
    if (!image) return viewport;
    const bounds = image.getBoundingClientRect();
    const left = Math.min(viewport.left, bounds.left - 24);
    const top = Math.min(viewport.top, bounds.top - 24);
    const right = Math.max(viewport.right, bounds.right + 24);
    const bottom = Math.max(viewport.bottom, bounds.bottom + 24);
    return {left, top, right, bottom, width: right - left, height: bottom - top};
  }

  function freezeClonedMap(clonedDocument, mapElement, captureRect, surface = mapElement) {
    const clone = mapElement.id
      ? clonedDocument.getElementById(mapElement.id)
      : clonedDocument.querySelector(".leaflet-container");
    if (!clone) return;
    clone.classList.remove("leaflet-zoom-anim", "leaflet-touching");
    clone.querySelectorAll(".np-map-layer-hidden").forEach((element) => {
      element.classList.remove("np-map-layer-hidden");
    });
    Object.assign(clone.style, {
      width: `${captureRect.width}px`,
      height: `${captureRect.height}px`,
      minWidth: `${captureRect.width}px`,
      minHeight: `${captureRect.height}px`,
      maxWidth: `${captureRect.width}px`,
      maxHeight: `${captureRect.height}px`,
      boxSizing: "border-box",
      overflow: "hidden"
    });
    flattenLeafletTranslations(mapElement, clone);
    normalizeIndividualTransforms(mapElement, clone);
    const liveRect = surface.getBoundingClientRect();
    const dx = liveRect.left - captureRect.left;
    const dy = liveRect.top - captureRect.top;
    if (dx || dy || captureRect.height !== liveRect.height || captureRect.width !== liveRect.width) {
      // A short browser window can crop the initial Leaflet view. Grow only
      // the export surface and shift its existing panes, never the live map.
      const clonedSurface = surface === mapElement ? clone : clone.parentElement;
      for (const element of [clone, clonedSurface]) Object.assign(element.style, {
        width: `${captureRect.width}px`, height: `${captureRect.height}px`,
        minWidth: `${captureRect.width}px`, minHeight: `${captureRect.height}px`,
        maxWidth: `${captureRect.width}px`, maxHeight: `${captureRect.height}px`
      });
      const pane = clone.querySelector(".leaflet-map-pane");
      if (pane) {
        pane.style.left = `${(parseFloat(pane.style.left) || 0) + dx}px`;
        pane.style.top = `${(parseFloat(pane.style.top) || 0) + dy}px`;
      }
    }
    for (const element of [clone, ...clone.querySelectorAll("*")]) {
      element.style.animation = "none";
      element.style.transition = "none";
      element.style.caretColor = "transparent";
      element.style.willChange = "auto";
    }
    normalizeCaptureColors(clonedDocument, clone.parentElement || clone);
  }

  function normalizeCaptureColors(clonedDocument, surface) {
    // Tailwind now computes translucent colors as oklab/color-mix(). The
    // bundled html2canvas predates those CSS colors. Let the browser convert
    // them to sRGB in a 1px canvas, and change only the disposable export DOM.
    const sample = clonedDocument.createElement("canvas");
    sample.width = sample.height = 1;
    const context = sample.getContext("2d", { willReadFrequently: true });
    if (!context) return;
    const colors = new Map();
    const convert = (color) => {
      if (colors.has(color)) return colors.get(color);
      context.clearRect(0, 0, 1, 1);
      context.fillStyle = color;
      context.fillRect(0, 0, 1, 1);
      const [r, g, b, a] = context.getImageData(0, 0, 1, 1).data;
      const result = `rgba(${r}, ${g}, ${b}, ${a / 255})`;
      colors.set(color, result);
      return result;
    };
    const compatibleValue = (value) => {
      // Gradient interpolation syntax is also newer than html2canvas.
      let result = value.replace(/\bin\s+(?:oklab|oklch|lab|lch|srgb)(?:\s+(?:shorter|longer|increasing|decreasing)\s+hue)?\s*,?/gi, "");
      const start = /\b(?:oklab|oklch|lab|lch|color|color-mix)\(/i;
      let match;
      while ((match = start.exec(result))) {
        let end = match.index + match[0].length;
        let depth = 1;
        while (end < result.length && depth) {
          if (result[end] === "(") depth++;
          if (result[end] === ")") depth--;
          end++;
        }
        if (depth) break;
        const color = result.slice(match.index, end);
        result = result.slice(0, match.index) + convert(color) + result.slice(end);
      }
      return result;
    };
    const nodes = [surface, ...surface.querySelectorAll("*")];
    for (let parent = surface.parentElement; parent; parent = parent.parentElement) nodes.push(parent);
    for (const element of nodes) {
      const computed = clonedDocument.defaultView.getComputedStyle(element);
      for (const property of ["color", "background-color", "background-image", "border-top-color", "border-right-color", "border-bottom-color", "border-left-color", "outline-color", "text-decoration-color", "text-shadow", "box-shadow", "fill", "stroke"]) {
        const value = computed.getPropertyValue(property);
        if (/\b(?:oklab|oklch|lab|lch|color|color-mix)\(/i.test(value) || /\bin\s+(?:oklab|oklch|lab|lch|srgb)\b/i.test(value)) {
          element.style.setProperty(property, compatibleValue(value), "important");
        }
      }
    }
  }

  function measureMapMarkers(mapElement, captureRect) {
    // Do not ask html2canvas to lay out player markers. Read the browser's
    // actual avatar coordinates once and anchor each name to that center.
    // Text width, Unicode names and nested CSS translations cannot move it.
    return Array.from(mapElement.querySelectorAll(".leaflet-marker-pane .leaflet-marker-icon"))
      .map((marker, order) => {
        const avatar = marker.querySelector("img");
        const label = Array.from(marker.querySelectorAll("span")).find((span) => span.textContent.trim());
        if (!avatar || !label) return null;
        const rect = avatar.getBoundingClientRect();
        if (!rect.width || !rect.height) return null;
        const avatarStyle = getComputedStyle(avatar);
        const labelStyle = getComputedStyle(label);
        const range = document.createRange();
        range.selectNodeContents(label);
        const textRect = range.getBoundingClientRect();
        return {
          order, zIndex: Number.parseInt(getComputedStyle(marker).zIndex, 10) || 0,
          x: rect.left - captureRect.left, y: rect.top - captureRect.top,
          width: rect.width, height: rect.height,
          source: avatar.currentSrc || avatar.src,
          border: Number.parseFloat(avatarStyle.borderTopWidth) || 0,
          borderColor: avatarStyle.borderTopColor,
          text: label.textContent.trim(),
          centerX: rect.left - captureRect.left + rect.width / 2,
          textTop: textRect.top - captureRect.top,
          font: `${labelStyle.fontStyle} ${labelStyle.fontWeight} ${labelStyle.fontSize} ${labelStyle.fontFamily}`,
          fontSize: Number.parseFloat(labelStyle.fontSize) || 13.3333,
          letterSpacing: labelStyle.letterSpacing,
          color: labelStyle.color,
          direction: labelStyle.direction,
          // Noble names use four one-pixel black shadows. Preserve that
          // legibility with a centered outline when drawing the name once.
          outlined: labelStyle.textShadow !== "none"
        };
      }).filter(Boolean)
      .sort((a, b) => a.zIndex - b.zIndex || a.order - b.order);
  }

  function measureMapPaths(mapElement, captureRect) {
    return Array.from(mapElement.querySelectorAll(".leaflet-overlay-pane path")).map((path) => {
      const matrix = path.getScreenCTM();
      if (!matrix) return null;
      const style = getComputedStyle(path);
      return {
        d: path.getAttribute("d"),
        transform: [matrix.a, matrix.b, matrix.c, matrix.d, matrix.e - captureRect.left, matrix.f - captureRect.top],
        fill: style.fill, fillRule: style.fillRule, fillOpacity: Number(style.fillOpacity),
        stroke: style.stroke, strokeOpacity: Number(style.strokeOpacity),
        opacity: Number(style.opacity), width: parseFloat(style.strokeWidth) || 0,
        lineCap: style.strokeLinecap, lineJoin: style.strokeLinejoin,
        dash: (style.strokeDasharray.match(/[\d.]+/g) || []).map(Number)
      };
    }).filter((path) => path?.d);
  }

  function drawMapPaths(canvas, paths, scale) {
    const context = canvas.getContext("2d");
    context.save();
    for (const path of paths) {
      // Paint complete path data, including drops outside a short viewport's
      // SVG clip rectangle, using the browser's exact SVG-to-screen matrix.
      context.setTransform(...path.transform.map((value) => value * scale));
      const shape = new Path2D(path.d);
      if (path.fill !== "none") {
        context.globalAlpha = path.opacity * path.fillOpacity;
        context.fillStyle = path.fill;
        context.fill(shape, path.fillRule === "evenodd" ? "evenodd" : "nonzero");
      }
      if (path.stroke !== "none" && path.width > 0) {
        context.globalAlpha = path.opacity * path.strokeOpacity;
        context.strokeStyle = path.stroke;
        context.lineWidth = path.width;
        context.lineCap = path.lineCap;
        context.lineJoin = path.lineJoin;
        context.setLineDash(path.dash);
        context.stroke(shape);
      }
    }
    context.restore();
  }

  function loadMarkerImages(markers) {
    const sources = Array.from(new Set(markers.map((marker) => marker.source)));
    return Promise.all(sources.map((source) => new Promise((resolve) => {
      const image = new Image();
      const done = (value) => {
        clearTimeout(timer);
        image.onload = image.onerror = null;
        resolve([source, value]);
      };
      const timer = setTimeout(() => done(null), 2_500);
      image.crossOrigin = "anonymous";
      image.onload = () => done(image);
      image.onerror = () => done(null);
      image.src = source;
    }))).then((entries) => new Map(entries));
  }

  function drawMapMarkers(canvas, markers, images, scale) {
    const context = canvas.getContext("2d");
    if (!context) throw new Error("Map marker canvas is unavailable");
    context.save();
    // html2canvas leaves its own scaled/translated context in place. Reset
    // that transform rather than scaling a second time or reusing page offsets.
    context.setTransform(scale, 0, 0, scale, 0, 0);
    context.globalAlpha = 1;
    context.beginPath();
    context.rect(0, 0, canvas.width / scale, canvas.height / scale);
    context.clip();
    for (const marker of markers) {
      const {x, y, width, height, border, centerX} = marker;
      const centerY = y + height / 2;
      context.save();
      context.beginPath();
      context.ellipse(centerX, centerY, width / 2, height / 2, 0, 0, Math.PI * 2);
      context.fillStyle = marker.borderColor;
      context.fill();
      context.beginPath();
      context.ellipse(centerX, centerY, Math.max(0, width / 2 - border), Math.max(0, height / 2 - border), 0, 0, Math.PI * 2);
      context.clip();
      context.fillStyle = "#182734";
      context.fillRect(x, y, width, height);
      const image = images.get(marker.source);
      if (image) context.drawImage(image, x + border, y + border, width - border * 2, height - border * 2);
      context.restore();

      context.save();
      context.font = marker.font;
      context.direction = marker.direction;
      if ("letterSpacing" in context) context.letterSpacing = marker.letterSpacing === "normal" ? "0px" : marker.letterSpacing;
      context.textAlign = "center";
      context.textBaseline = "alphabetic";
      const metrics = context.measureText(marker.text);
      const baseline = marker.textTop + (metrics.fontBoundingBoxAscent ?? marker.fontSize);
      if (marker.outlined) {
        context.lineJoin = "round";
        context.lineWidth = 2;
        context.strokeStyle = "#000";
        context.strokeText(marker.text, centerX, baseline);
      }
      context.fillStyle = marker.color;
      context.fillText(marker.text, centerX, baseline);
      context.restore();
    }
    context.restore();
  }

  async function captureInitialSnapshot(state, isRefresh = false) {
    if (!stateIsCurrent(state) || state.capturePromise) return state?.capturePromise;
    state.status = isRefresh && state.blob ? "refreshing" : "preparing";
    updateButton();

    state.capturePromise = (async () => {
      const expectedContent = await waitForInitialMap(state);
      if (document.fonts?.ready) await Promise.race([document.fonts.ready, wait(150)]);
      if (!stateIsCurrent(state) || state.userInteracted) throw new Error("Initial map view changed");

      const expectedView = viewSignature(state.mapElement);
      const captureSurface = captureSurfaceForMap(state.mapElement);
      const captureRect = fullMapCaptureRect(captureSurface, state.mapElement);
      const scale = Math.min(captureScale(state.mapElement), Math.sqrt(MAX_CANVAS_PIXELS / (captureRect.width * captureRect.height)));
      const markers = measureMapMarkers(state.mapElement, captureRect);
      const paths = measureMapPaths(state.mapElement, captureRect);
      const markerImages = loadMarkerImages(markers);
      const canvas = await window.html2canvas(captureSurface, {
        backgroundColor: captureBackground(captureSurface),
        scale,
        width: Math.round(captureRect.width),
        height: Math.round(captureRect.height),
        windowWidth: document.documentElement.clientWidth,
        windowHeight: document.documentElement.clientHeight,
        scrollX: window.scrollX,
        scrollY: window.scrollY,
        useCORS: true,
        allowTaint: false,
        logging: false,
        imageTimeout: 2500,
        onclone: (clonedDocument) => freezeClonedMap(clonedDocument, state.mapElement, captureRect, captureSurface),
        ignoreElements: (element) =>
          element.classList?.contains("leaflet-control-container") ||
          element.classList?.contains("leaflet-marker-pane") ||
          element.classList?.contains("leaflet-shadow-pane") ||
          (element.tagName?.toLowerCase() === "svg" && Boolean(element.closest(".leaflet-overlay-pane"))) ||
          element.id === TOAST_ID ||
          element.id === BTN_ID ||
          element.id === WRAP_ID
      });
      // All overlays share the same measured coordinate system. html2canvas
      // now renders only the map image and branded background.
      drawMapPaths(canvas, paths, scale);
      drawMapMarkers(canvas, markers, await markerImages, scale);

      if (
        !stateIsCurrent(state) ||
        state.userInteracted ||
        viewSignature(state.mapElement) !== expectedView ||
        contentSignature(state.mapElement) !== expectedContent
      ) {
        throw new Error("Map changed while the snapshot was being created");
      }

      if (!canvasLooksUsable(canvas)) throw new Error("Snapshot canvas was blank or incomplete");

      const framedCanvas = frameMapAsSquare(canvas);
      if (!canvasLooksUsable(framedCanvas)) throw new Error("Square map frame was blank or incomplete");
      const blob = await canvasToBlob(framedCanvas);
      if (!blob) throw new Error("PNG encoding failed");
      state.blob = blob;
      state.fullViewSignature = expectedView;
      state.status = "ready";
      state.error = null;
    })()
      .catch((error) => {
        state.error = error;
        const mayRetry =
          !state.blob &&
          /changed while|blank|incomplete/i.test(error.message) &&
          stateIsCurrent(state) &&
          !state.userInteracted &&
          state.retryCount < 3;

        if (mayRetry) {
          state.retryCount++;
          state.status = "waiting";
          setTimeout(() => {
            if (stateIsCurrent(state) && !state.capturePromise) captureInitialSnapshot(state);
          }, 280);
          return;
        }
        if (!state.blob) {
          state.status = /changed|missed/i.test(error.message) ? "missed" : "failed";
          console.warn("[Noble Toolkit] Initial map snapshot unavailable", error);
        } else {
          state.status = "ready";
          console.debug("[Noble Toolkit] Kept previous map snapshot after refresh failed", error);
        }
      })
      .finally(() => {
        state.capturePromise = null;
        updateButton();
      });

    return state.capturePromise;
  }

  function mutationAffectsMapContent(mutation) {
    const target = mutation.target instanceof Element ? mutation.target : mutation.target?.parentElement;
    if (!target) return false;
    return Boolean(target.closest(".leaflet-overlay-pane, .leaflet-marker-pane, .leaflet-shadow-pane"));
  }

  function observeState(state) {
    const markInteraction = (event) => {
      if (event.target instanceof Element && event.target.closest(`#${MAP_CORNER_TOOLS_ID}`)) return;
      state.userInteracted = true;
    };
    for (const type of ["pointerdown", "wheel", "touchstart", "keydown"]) {
      state.mapElement.addEventListener(type, markInteraction, { capture: true, passive: true });
    }

    state.observer = new MutationObserver((mutations) => {
      if (!stateIsCurrent(state) || state.userInteracted || !state.blob || fullscreenMap) return;
      if (!mutations.some(mutationAffectsMapContent)) return;
      clearTimeout(state.refreshTimer);
      state.refreshTimer = setTimeout(() => {
        if (stateIsCurrent(state) && !state.userInteracted) {
          captureInitialSnapshot(state, true);
        }
      }, 320);
    });
    state.observer.observe(state.mapElement, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true,
      attributeFilter: ["src", "d", "style"]
    });

    state.resizeObserver = typeof ResizeObserver === "function"
      ? new ResizeObserver(() => {
          if (!stateIsCurrent(state) || state.userInteracted || !state.blob || fullscreenMap) return;
          clearTimeout(state.refreshTimer);
          state.refreshTimer = setTimeout(() => {
            if (stateIsCurrent(state) && !state.userInteracted) captureInitialSnapshot(state, true);
          }, 420);
        })
      : null;
    state.resizeObserver?.observe(state.mapElement);

    state.cleanup = () => {
      state.observer?.disconnect();
      state.resizeObserver?.disconnect();
      clearTimeout(state.refreshTimer);
      for (const type of ["pointerdown", "wheel", "touchstart", "keydown"]) {
        state.mapElement.removeEventListener(type, markInteraction, { capture: true });
      }
    };
  }

  function resetSnapshot() {
    generation++;
    activeState?.cleanup?.();
    activeState = null;
    cachedBadgeRow = null;
    updateButton();
  }

  function ensureInitialSnapshot() {
    if (!settings.mapCopy || !isSessionMapPage() || typeof window.html2canvas !== "function") return;
    const mapElement = findMapElement();
    if (!mapElement) return;
    const key = sessionKey();
    lastRoute = key;
    if (activeState && activeState.key === key && activeState.mapElement === mapElement) return;

    resetSnapshot();
    const state = {
      key,
      mapElement,
      generation,
      status: "waiting",
      blob: null,
      error: null,
      userInteracted: false,
      capturePromise: null,
      retryCount: 0,
      observer: null,
      resizeObserver: null,
      refreshTimer: null,
      cleanup: null
    };
    activeState = state;
    observeState(state);
    captureInitialSnapshot(state);
  }

  async function copyCachedMap(button) {
    if (copyInProgress) return;
    if (!activeState?.blob) {
      if (activeState?.status === "failed" || activeState?.status === "missed") {
        if (activeState.userInteracted) {
          toast("Full-map snapshot unavailable. Refresh before zooming.");
          return;
        }
        // A late avatar or transient render error should not force a page
        // refresh. Retry the untouched full view when the user clicks Copy.
        activeState.retryCount = 0;
        activeState.status = "waiting";
        void captureInitialSnapshot(activeState);
      }

      // On marker-heavy 24/7 sessions the user can click before the cached
      // PNG has finished encoding. Keep the click alive and copy as soon as
      // the initial untouched view is ready instead of making them retry.
      copyInProgress = true;
      button.disabled = true;
      button.textContent = "Preparing…";
      toast("Preparing the full map…");
      const deadline = Date.now() + READY_TIMEOUT + 2_500;
      while (!activeState?.blob && Date.now() < deadline) {
        if (!activeState || activeState.status === "failed" || activeState.status === "missed") break;
        await wait(90);
      }
      button.disabled = false;
      copyInProgress = false;
      updateButton();
      if (!activeState?.blob) {
        toast("Full-map snapshot unavailable. Refresh the session and try again.");
        return;
      }
    }
    if (activeState.key !== sessionKey()) {
      toast("Session changed. Waiting for a new map snapshot.");
      return;
    }

    copyInProgress = true;
    const original = button.innerHTML;
    button.disabled = true;
    button.classList.add("np-map-capture-busy");
    button.textContent = "Copying…";
    try {
      if (typeof ClipboardItem !== "function" || !navigator.clipboard?.write) throw new Error("Image clipboard is unavailable");
      await navigator.clipboard.write([new ClipboardItem({ "image/png": activeState.blob })]);
      toast("Full map copied ✓");
    } catch (error) {
      console.warn("[Noble Toolkit] Map clipboard copy failed", error);
      toast(`Copy failed: ${error?.message || "unknown error"}`);
    } finally {
      button.innerHTML = original;
      button.disabled = false;
      button.classList.remove("np-map-capture-busy");
      copyInProgress = false;
      updateButton();
    }
  }

  let scheduled = false;
  function scheduleBoot() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      placeButton();
      placeFullscreenButton();
      ensureInitialSnapshot();
    }, 20);
  }

  NPSettings.load().then((loaded) => {
    settings = loaded;
    scheduleBoot();
  }).catch(scheduleBoot);

  new MutationObserver(scheduleBoot).observe(document.documentElement, { childList: true, subtree: true });

  setInterval(() => {
    const route = sessionKey();
    if (route !== lastRoute) {
      lastRoute = route;
      exitMapFullscreen({ restoreFocus: false });
      resetSnapshot();
      scheduleBoot();
    }
  }, 500);

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && fullscreenMap) {
      event.preventDefault();
      event.stopPropagation();
      exitMapFullscreen();
    }
  }, true);

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[NPSettings.STORAGE_KEY]) {
        settings = NPSettings.sanitize(changes[NPSettings.STORAGE_KEY].newValue);
        if (!settings.mapCopy) resetSnapshot();
        scheduleBoot();
      }
    });
  } catch {}
})();
