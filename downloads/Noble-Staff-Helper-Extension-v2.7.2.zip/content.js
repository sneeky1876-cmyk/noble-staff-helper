"use strict";

let npSettings = NPSettings.cloneDefaults();

function applySharedSettings(settings) {
  npSettings = NPSettings.sanitize(settings);
  document.documentElement?.setAttribute("data-np-motion", npSettings.animations ? "on" : "off");
  if (!npSettings.playerCards) removePlayerCardUi();
  if (!npSettings.creatorCodes) removeCreatorUi();
  if (npSettings.playerCards || npSettings.creatorCodes) decorateAll();
}

NPSettings.load().then(applySharedSettings).catch(() => {});

// -------------------- Cache from WS --------------------
const state = {
  byIgnNorm: new Map(), // norm IGN -> { ign, userId, profilePicture, epicAccountId }
  ready: false
};

const HOST_BADGE_CLASS = "np-host-ready-badge";
const CREATOR_PROGRESS_ID = "np-creator-progress";
const HOST_SCAN_BUTTON_ID = "np-host-scan-btn";
const HOST_SCAN_WRAP_ID = "np-host-scan-wrap";
const CREATOR_CACHE_KEYS = ["np_creator_code_cache_v8", "np_creator_code_cache_v7"];
const CREATOR_CACHE_DISPLAY_TTL = 90 * 24 * 60 * 60 * 1000;
const CREATOR_CONCURRENCY = 48;
const CREATOR_PROGRESS_SETTLE_MS = 1200;
const CREATOR_SCAN_WATCHDOG_MS = 25_000;
const creatorStates = new Map();
const creatorQueue = [];
const creatorBatchKeys = new Set();
const creatorActiveByGeneration = new Map();
let creatorDecorateTimer = null;
let creatorBatchRunning = false;
let creatorProgressHideTimer = null;
let creatorProgressSettleTimer = null;
let creatorScanRequested = false;
let creatorScanPreparing = false;
let creatorScanCompleted = false;
let creatorScanWatchdogTimer = null;
let creatorLookupGeneration = 0;
let creatorPrepareToken = 0;
let creatorSessionRouteKey = "";
let creatorSessionMembers = new Set();
let creatorSessionPanel = null;
let creatorButtonFeedback = "";
let creatorButtonFeedbackTimer = null;

function norm(s) {
  return String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function normalizeEpicAccountId(value) {
  const clean = String(value || "").trim().toLowerCase();
  return /^[0-9a-f]{32}$/.test(clean) ? clean : "";
}

function findEpicAccountId(team) {
  if (!team || typeof team !== "object") return "";
  const candidates = [
    team.epicAccountId,
    team.epicAccountID,
    team.epicId,
    team.accountId,
    team.accountID,
    team.epic?.accountId,
    team.epic?.id,
    team.account?.accountId,
    team.account?.id,
    team.profile?.accountId,
    team.fortnite?.accountId
  ];
  for (const candidate of candidates) {
    const accountId = normalizeEpicAccountId(candidate);
    if (accountId) return accountId;
  }
  return "";
}

function ensureCreatorProgress() {
  let progress = document.getElementById(CREATOR_PROGRESS_ID);
  if (progress) return progress;

  progress = document.createElement("div");
  progress.id = CREATOR_PROGRESS_ID;
  progress.setAttribute("role", "status");
  progress.setAttribute("aria-live", "polite");
  progress.setAttribute("aria-hidden", "true");
  progress.innerHTML = `
    <span class="np-creator-progress-spinner" aria-hidden="true"></span>
    <span class="np-creator-progress-label">Checking host status</span>
    <span class="np-creator-progress-count"></span>
    <span class="np-creator-progress-track" aria-hidden="true"><span></span></span>
  `;
  (document.body || document.documentElement).appendChild(progress);
  return progress;
}

function hideCreatorProgress(immediate = false) {
  clearTimeout(creatorProgressHideTimer);
  clearTimeout(creatorProgressSettleTimer);
  creatorProgressHideTimer = null;
  creatorProgressSettleTimer = null;
  clearTimeout(creatorScanWatchdogTimer);
  creatorScanWatchdogTimer = null;
  creatorBatchRunning = false;
  if (immediate) {
    creatorScanRequested = false;
    creatorScanPreparing = false;
  }
  if (!creatorScanRequested) creatorBatchKeys.clear();
  const progress = document.getElementById(CREATOR_PROGRESS_ID);
  if (!progress) return;
  progress.classList.remove("is-visible", "is-done");
  progress.setAttribute("aria-hidden", "true");
  if (immediate) progress.remove();
}

function creatorBatchSummary() {
  let completed = 0;
  let ready = 0;
  let failed = 0;
  for (const key of creatorBatchKeys) {
    const item = creatorStates.get(key);
    if (item?.status === "done" || item?.status === "error") completed++;
    if (item?.status === "done" && item.hasCreatorCode && item.verified) ready++;
    if (item?.status === "error") failed++;
  }
  return {
    completed,
    ready,
    failed,
    total: creatorBatchKeys.size
  };
}

function updateCreatorProgress() {
  if (!npSettings.creatorCodes || !creatorBatchRunning || !creatorBatchKeys.size) {
    hideCreatorProgress();
    return;
  }

  const { completed, ready, failed, total } = creatorBatchSummary();
  const pending = Math.max(0, total - completed);
  const progress = ensureCreatorProgress();
  const label = progress.querySelector(".np-creator-progress-label");
  const count = progress.querySelector(".np-creator-progress-count");
  const fill = progress.querySelector(".np-creator-progress-track > span");
  clearTimeout(creatorProgressHideTimer);
  creatorProgressHideTimer = null;

  progress.classList.add("is-visible");
  progress.classList.remove("is-done");
  progress.setAttribute("aria-hidden", "false");
  const progressLabel = pending
    ? ready ? `Checking hosts · ${ready} found` : "Checking host status"
    : "Finishing host check";
  const progressCount = `${completed}/${total}`;
  const progressWidth = `${Math.round((completed / total) * 100)}%`;
  if (label.textContent !== progressLabel) label.textContent = progressLabel;
  if (count.textContent !== progressCount) count.textContent = progressCount;
  if (fill.style.width !== progressWidth) fill.style.width = progressWidth;

  if (pending) {
    clearTimeout(creatorProgressSettleTimer);
    creatorProgressSettleTimer = null;
    return;
  }

  // Noble can append the last member rows just after the current queue empties.
  // Wait for a quiet window so the indicator cannot announce completion and
  // disappear while a second wave of players is still being discovered.
  if (!creatorProgressSettleTimer) {
    creatorProgressSettleTimer = setTimeout(() => {
      creatorProgressSettleTimer = null;
      if (!creatorBatchRunning) return;
      const stillPending = [...creatorBatchKeys].some((key) => {
        const item = creatorStates.get(key);
        return item && item.status !== "done" && item.status !== "error";
      });
      if (stillPending) {
        updateCreatorProgress();
        return;
      }

      const summary = creatorBatchSummary();
      const doneProgress = document.getElementById(CREATOR_PROGRESS_ID);
      if (!doneProgress) {
        creatorScanRequested = false;
        creatorBatchRunning = false;
        creatorScanCompleted = true;
        clearTimeout(creatorScanWatchdogTimer);
        creatorScanWatchdogTimer = null;
        updateHostScanButton();
        return;
      }
      doneProgress.classList.add("is-done");
      const doneLabel = summary.ready
          ? `${summary.ready} host${summary.ready === 1 ? "" : "s"} ready`
          : summary.failed === summary.total
            ? "Host service unavailable"
            : "Host check complete";
      const doneLabelElement = doneProgress.querySelector(".np-creator-progress-label");
      const doneCountElement = doneProgress.querySelector(".np-creator-progress-count");
      if (doneLabelElement.textContent !== doneLabel) doneLabelElement.textContent = doneLabel;
      if (doneCountElement.textContent) doneCountElement.textContent = "";
      creatorScanRequested = false;
      creatorScanCompleted = true;
      clearTimeout(creatorScanWatchdogTimer);
      creatorScanWatchdogTimer = null;
      updateHostScanButton();
      creatorProgressHideTimer = setTimeout(() => hideCreatorProgress(), 900);
    }, CREATOR_PROGRESS_SETTLE_MS);
  }
}

function addCreatorProgressKey(key) {
  if (creatorBatchRunning && creatorBatchKeys.has(key)) return;
  if (!creatorBatchRunning) {
    creatorBatchKeys.clear();
    creatorBatchRunning = true;
  }
  clearTimeout(creatorProgressHideTimer);
  clearTimeout(creatorProgressSettleTimer);
  creatorProgressHideTimer = null;
  creatorProgressSettleTimer = null;
  creatorBatchKeys.add(key);
  updateCreatorProgress();
}


// For leaderboard tools we also persist an ID cache to chrome.storage.local.
// We store multiple normalized keys per name to make matching very tolerant.
function npNormalizeName(raw) {
  const s = String(raw || "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "") // invisibles
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

  // keep unicode letters/numbers/spaces
  const normKey = s.replace(/[^\p{L}\p{N}\s]+/gu, "").replace(/\s+/g, " ").trim();

  // remove spaces too
  const looseKey = normKey.replace(/\s+/g, "");

  return { normKey, looseKey };
}

function creatorKey(name) {
  return npNormalizeName(name).normKey;
}

function loadSavedCreatorHosts() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(CREATOR_CACHE_KEYS, (items) => {
        const cache = items?.[CREATOR_CACHE_KEYS[0]] || items?.[CREATOR_CACHE_KEYS[1]] || {};
        const now = Date.now();
        for (const [storageKey, entry] of Object.entries(cache)) {
          if (
            !entry?.hasCreatorCode ||
            !entry?.verified ||
            !entry?.code ||
            now - Number(entry.checkedAt || 0) > CREATOR_CACHE_DISPLAY_TTL
          ) {
            continue;
          }

          const savedName = storageKey.startsWith("name:")
            ? storageKey.slice(5)
            : entry.accountName;
          const key = creatorKey(savedName || entry.accountName);
          if (!key) continue;
          creatorStates.set(key, {
            status: "done",
            hasCreatorCode: true,
            code: entry.code,
            accountName: entry.accountName || savedName,
            accountId: normalizeEpicAccountId(entry.accountId),
            verified: true,
            source: entry.source || "local-cache",
            checkedAt: Number(entry.checkedAt || 0),
            cached: true
          });
        }
        resolve();
      });
    } catch {
      resolve();
    }
  });
}

function sendCreatorLookup(displayName, epicAccountId = "") {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(value);
    };
    const timer = setTimeout(() => finish({ ok: false, error: "Host service timed out" }), 20_000);

    try {
      chrome.runtime.sendMessage({
        type: "NP_CREATOR_CODE_LOOKUP",
        displayName,
        epicAccountId: normalizeEpicAccountId(epicAccountId)
      }, (response) => {
        const error = chrome.runtime.lastError;
        if (error) finish({ ok: false, error: error.message });
        else finish(response || { ok: false, error: "No creator lookup response" });
      });
    } catch (error) {
      finish({ ok: false, error: error?.message || "Creator lookup failed" });
    }
  });
}

function scheduleCreatorDecorate() {
  clearTimeout(creatorDecorateTimer);
  creatorDecorateTimer = setTimeout(decorateAll, 35);
}

function drainCreatorQueue() {
  const generation = creatorLookupGeneration;
  let active = creatorActiveByGeneration.get(generation) || 0;
  while (active < CREATOR_CONCURRENCY && creatorQueue.length) {
    const item = creatorQueue.shift();
    const current = creatorStates.get(item.key);
    if (!current || current.status !== "queued" || current.generation !== item.generation) continue;

    active++;
    creatorActiveByGeneration.set(item.generation, active);
    creatorStates.set(item.key, {
      status: "checking",
      requestedEpicId: item.epicAccountId || "",
      generation: item.generation
    });
    updateCreatorProgress();
    sendCreatorLookup(item.displayName, item.epicAccountId)
      .then((result) => {
        if (item.generation !== creatorLookupGeneration) return;
        if (result?.ok) {
          creatorStates.set(item.key, {
            status: "done",
            hasCreatorCode: Boolean(result.hasCreatorCode),
            code: result.code || "",
            accountName: result.accountName || item.displayName,
            accountId: normalizeEpicAccountId(result.accountId),
            verified: Boolean(result.verified),
            source: result.source || "",
            checkedAt: Number(result.checkedAt || Date.now()),
            cached: Boolean(result.cached),
            generation: item.generation
          });
        } else {
          creatorStates.set(item.key, {
            status: "error",
            retryAt: Date.now() + 10 * 60 * 1000,
            error: result?.error || "Creator lookup failed",
            requestedEpicId: item.epicAccountId || "",
            generation: item.generation
          });
        }
      })
      .finally(() => {
        const remaining = Math.max(0, (creatorActiveByGeneration.get(item.generation) || 1) - 1);
        if (remaining) creatorActiveByGeneration.set(item.generation, remaining);
        else creatorActiveByGeneration.delete(item.generation);
        if (item.generation !== creatorLookupGeneration) {
          drainCreatorQueue();
          return;
        }
        updateCreatorProgress();
        scheduleCreatorDecorate();
        setTimeout(drainCreatorQueue, 25);
      });
  }
}

function queueCreatorLookup(record, { manual = false } = {}) {
  if (!npSettings.creatorCodes || !record?.ign || (!manual && !creatorScanRequested)) return;
  const key = creatorKey(record.ign);
  const epicAccountId = normalizeEpicAccountId(record.epicAccountId);
  if (!key) return;
  const current = creatorStates.get(key);
  if (
    current &&
    ["queued", "checking"].includes(current.status) &&
    current.generation === creatorLookupGeneration
  ) {
    if (epicAccountId && !current.requestedEpicId) {
      current.requestedEpicId = epicAccountId;
      const queued = creatorQueue.find((item) => item.key === key);
      if (queued) queued.epicAccountId = epicAccountId;
    }
    return;
  }
  if (
    !manual &&
    current?.status === "done" &&
    (!epicAccountId || current.accountId === epicAccountId)
  ) {
    addCreatorProgressKey(key);
    return;
  }
  const hasBetterId = epicAccountId && current?.requestedEpicId !== epicAccountId;
  if (!manual && current?.retryAt && current.retryAt > Date.now() && !hasBetterId) return;

  creatorStates.set(key, {
    status: "queued",
    requestedEpicId: epicAccountId,
    generation: creatorLookupGeneration
  });
  creatorQueue.push({
    key,
    displayName: record.ign,
    epicAccountId,
    generation: creatorLookupGeneration
  });
  addCreatorProgressKey(key);
  drainCreatorQueue();
}

loadSavedCreatorHosts().then(scheduleCreatorDecorate).catch(() => {});

let __npPersistTimer = null;
function npPersistIdCacheSoon() {
  clearTimeout(__npPersistTimer);
  __npPersistTimer = setTimeout(npPersistIdCacheNow, 400);
}

function npPersistIdCacheNow() {
  try {
    if (!chrome?.storage?.local) return;

    const additions = {};
    for (const rec of state.byIgnNorm.values()) {
      if (!rec?.ign || !rec?.userId) continue;
      const { normKey, looseKey } = npNormalizeName(rec.ign);

      // store a few variants so the leaderboard scripts can resolve aggressively
      const plain = norm(rec.ign);

      if (normKey) additions[normKey] = rec.userId;
      if (looseKey) additions[looseKey] = rec.userId;
      if (plain) additions[plain] = rec.userId;
    }

    // Merge instead of replacing the cache. Replacing it made leaderboard IDs
    // disappear whenever the user opened a different session map.
    chrome.storage.local.get(["np_id_cache_v1"], (items) => {
      const merged = { ...(items?.np_id_cache_v1 || {}) };
      for (const [key, value] of Object.entries(additions)) {
        delete merged[key];
        merged[key] = value;
      }

      // Keep local storage bounded while retaining the most recently seen keys.
      const keys = Object.keys(merged);
      for (const key of keys.slice(0, Math.max(0, keys.length - 6000))) delete merged[key];

      chrome.storage.local.set({
        np_id_cache_v1: merged,
        np_id_cache_updated_at: Date.now()
      });
    });
  } catch (e) {
    console.warn("[NP] Failed to persist ID cache", e);
  }
}

function cacheTeams(teams) {
  let added = 0;
  for (const t of teams) {
    if (!t) continue;
    const ign = (t.username || "").trim();
    const userId = t.userId != null ? String(t.userId) : null;
    if (!ign || !userId) continue;

    const key = norm(ign);
    const previous = state.byIgnNorm.get(key);
    if (!previous) added++;

    const record = {
      ign,
      userId,
      profilePicture: t.profilePicture || t.profilePic || previous?.profilePicture || null,
      epicAccountId: findEpicAccountId(t) || previous?.epicAccountId || ""
    };
    state.byIgnNorm.set(key, record);
    queueCreatorLookup(record);
  }
  state.ready = state.byIgnNorm.size > 0;
  console.log(`[NP ShadowPopover] cached IGNs=${state.byIgnNorm.size} (+${added})`);

  // persist cache for leaderboard tools
  npPersistIdCacheSoon();
}

// The initial socket payload can arrive before this document-idle script is
// listening. Noble renders the same Epic name and Discord user ID on each
// member row, so use that DOM as a reliable second source for every feature
// that needs the name-to-ID cache.
function cacheVisibleMemberRows(panel) {
  if (!panel) return 0;
  let changed = 0;
  const rows = Array.from(panel.querySelectorAll("[userid], [user-id]"));

  for (const row of rows) {
    const userId = String(row.getAttribute("userid") || row.getAttribute("user-id") || "").trim();
    if (!/^\d{8,24}$/.test(userId)) continue;

    const identity = Array.from(row.children || []).find((child) => child.querySelector?.("img") && child.querySelector?.("span"));
    const scope = identity || row;
    const nameElement = Array.from(scope.querySelectorAll("span")).find((element) => {
      if (element.closest(`.${HOST_BADGE_CLASS}, .${WRAP_CLASS}`)) return false;
      const text = (element.textContent || "").replace(/\s+/g, " ").trim();
      return text.length >= 2 && text.length <= 64 && !/^\d+$/.test(text) && text.toLowerCase() !== "host ready";
    });
    const ign = (nameElement?.textContent || "").replace(/\s+/g, " ").trim();
    if (!ign) continue;

    const image = scope.querySelector("img");
    const key = norm(ign);
    const previous = state.byIgnNorm.get(key);
    const record = {
      ign,
      userId,
      profilePicture: image?.currentSrc || image?.src || previous?.profilePicture || null,
      epicAccountId: previous?.epicAccountId || ""
    };
    if (!previous || previous.userId !== userId || previous.ign !== ign) changed++;
    state.byIgnNorm.set(key, record);
    queueCreatorLookup(record);
  }

  if (state.byIgnNorm.size) state.ready = true;
  if (changed) npPersistIdCacheSoon();
  return rows.length;
}

function decorateVisibleCreatorRows(panel) {
  if (!panel || !npSettings.creatorCodes) return;
  const rows = Array.from(panel.querySelectorAll("[userid], [user-id]"));
  for (const row of rows) {
    const userId = String(row.getAttribute("userid") || row.getAttribute("user-id") || "").trim();
    if (!userId) continue;
    const record = Array.from(state.byIgnNorm.values()).find((item) => String(item?.userId || "") === userId);
    if (!record) continue;
    queueCreatorLookup(record);

    // Creator status is independent from the player-card clock button. This
    // keeps Host Ready working on completed, staff, mobile, and 24/7 rows even
    // when Noble changes or hides the row action controls.
    const actionButton = Array.from(row.querySelectorAll("button, a, [role='button']"))
      .find((element) => !element.classList?.contains(BTN_CLASS));
    applyCreatorStatus(row, record, actionButton || null);
  }
}

// Receive parsed WS JSON from page.js
window.addEventListener("message", (ev) => {
  if (ev.source !== window) return;
  if (ev.origin !== location.origin) return;
  const msg = ev.data;
  if (!msg || msg.__NP_HELPER__ !== true) return;
  if (!globalThis.__NP_HELPER_CHANNEL__ || msg.channel !== globalThis.__NP_HELPER_CHANNEL__) return;

  if (msg.type === "NP_WS_JSON") {
    const p = msg.payload;
    const teams = p?.teams || p?.data?.teams || p?.payload?.teams;
    if (Array.isArray(teams) && teams.length) {
      cacheTeams(teams);
      decorateAll();
    }
  }
});

// -------------------- ONE button per row (hard guards) --------------------
const ROW_MARK = "data-np-row-v3";
const BTN_CLASS = "np-ext-chevron-btn";
const WRAP_CLASS = "np-ext-wrap";

// -------------------- LEFT PLAYERS panel finder --------------------
let cachedPlayersPanel = null;
let cachedPlayersPanelAt = 0;

function currentCreatorSessionRoute() {
  return `${location.pathname}${location.search}${location.hash}`;
}

function visiblePanelMemberIds(panel) {
  if (!panel) return new Set();
  return new Set(
    Array.from(panel.querySelectorAll("[userid], [user-id]"))
      .map((row) => String(row.getAttribute("userid") || row.getAttribute("user-id") || "").trim())
      .filter(Boolean)
  );
}

function resetCreatorSession(nextRoute = currentCreatorSessionRoute()) {
  creatorLookupGeneration++;
  creatorPrepareToken++;
  creatorQueue.length = 0;
  creatorBatchKeys.clear();
  creatorBatchRunning = false;
  creatorScanRequested = false;
  creatorScanPreparing = false;
  creatorScanCompleted = false;
  creatorSessionRouteKey = nextRoute;
  creatorSessionMembers = new Set();
  creatorSessionPanel = null;
  creatorButtonFeedback = "";
  clearTimeout(creatorButtonFeedbackTimer);
  creatorButtonFeedbackTimer = null;
  clearTimeout(creatorScanWatchdogTimer);
  creatorScanWatchdogTimer = null;
  cachedPlayersPanel = null;
  cachedPlayersPanelAt = 0;
  hideCreatorProgress(true);
  const button = document.getElementById(HOST_SCAN_BUTTON_ID);
  button?.removeAttribute("data-scanned");
  updateHostScanButton();
}

function syncCreatorSession(panel = null) {
  const route = currentCreatorSessionRoute();
  if (!creatorSessionRouteKey) creatorSessionRouteKey = route;
  if (route !== creatorSessionRouteKey) {
    resetCreatorSession(route);
    return true;
  }

  const members = visiblePanelMemberIds(panel);
  if (!members.size) return false;
  if (!creatorScanRequested && !creatorScanPreparing && !creatorScanCompleted) {
    creatorSessionMembers = members;
    creatorSessionPanel = panel;
    return false;
  }
  if (!panel || panel === creatorSessionPanel) return false;

  const baselineSize = creatorSessionMembers.size;
  const comparisonSize = Math.min(baselineSize, members.size);
  if (comparisonSize < 2) return false;
  let overlap = 0;
  for (const member of members) {
    if (creatorSessionMembers.has(member)) overlap++;
  }
  if (overlap === 0 || (comparisonSize >= 5 && overlap / comparisonSize < 0.25)) {
    resetCreatorSession(route);
    creatorSessionMembers = members;
    creatorSessionPanel = panel;
    return true;
  }
  creatorSessionPanel = panel;
  return false;
}

function findPlayersPanelRoot() {
  const now = Date.now();
  if (cachedPlayersPanel && now - cachedPlayersPanelAt < 2000 && document.contains(cachedPlayersPanel)) {
    const rect = cachedPlayersPanel.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0 && cachedPlayersPanel.querySelector("[userid], [user-id]")) {
      return cachedPlayersPanel;
    }
  }

  cachedPlayersPanel = null;
  cachedPlayersPanelAt = now;

  const candidates = Array.from(document.querySelectorAll("div, section, aside"));
  let best = null;
  let smallestArea = Infinity;
  for (const el of candidates) {
    const t = (el.innerText || "").trim().toLowerCase();
    if (!t.includes("players")) continue;

    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) continue;
    const memberRows = el.querySelectorAll("[userid], [user-id]").length;
    if (!memberRows || !el.querySelector("img")) continue;

    // Noble switches the sidebar to a full-width block below 1110px. The old
    // half-viewport width guard discarded that valid responsive/24/7 panel.
    const area = r.width * r.height;
    if (area < smallestArea) {
      best = el;
      smallestArea = area;
    }
  }

  cachedPlayersPanel = best;

  return cachedPlayersPanel;
}

function hostScanButtonMarkup(label = "Check hosts") {
  return `
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="11" cy="11" r="6.5" stroke="currentColor" stroke-width="1.8"></circle>
      <path d="m16 16 4 4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
    </svg>
    <span>${label}</span>
  `;
}

function updateHostScanButton() {
  const button = document.getElementById(HOST_SCAN_BUTTON_ID);
  if (!button) return;
  const busy = creatorScanPreparing || creatorScanRequested;
  button.disabled = busy;
  button.setAttribute("aria-busy", busy ? "true" : "false");
  button.classList.toggle("is-busy", busy);
  const label = busy
    ? creatorScanPreparing ? "Loading players" : "Checking hosts"
    : creatorButtonFeedback || (creatorScanCompleted ? "Check again" : "Check hosts");
  if (button.dataset.npLabel !== label) {
    button.dataset.npLabel = label;
    button.innerHTML = hostScanButtonMarkup(label);
  }
  button.title = busy
    ? "Host check in progress"
    : "Check visible players for active creator codes";
}

function setHostScanButtonFeedback(label, duration = 1200) {
  creatorButtonFeedback = label;
  clearTimeout(creatorButtonFeedbackTimer);
  updateHostScanButton();
  creatorButtonFeedbackTimer = setTimeout(() => {
    creatorButtonFeedback = "";
    creatorButtonFeedbackTimer = null;
    updateHostScanButton();
  }, duration);
}

function findPlayersHeading(panel) {
  return Array.from(panel.querySelectorAll("h1, h2, h3, h4, p, span, div"))
    .filter((element) => {
      if (element.id === HOST_SCAN_WRAP_ID || element.closest(`#${HOST_SCAN_WRAP_ID}`)) return false;
      const directText = Array.from(element.childNodes)
        .filter((node) => node.nodeType === Node.TEXT_NODE)
        .map((node) => node.textContent || "")
        .join(" ")
        .replace(/\s+/g, " ")
        .trim();
      if (!/^players(?:\s*[·:()\-]?\s*[\d/]+)?$/i.test(directText)) return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && rect.height < 90;
    })
    .sort((a, b) => a.getBoundingClientRect().height - b.getBoundingClientRect().height)[0] || null;
}

function ensureHostScanButton(panel) {
  if (!npSettings.creatorCodes || !panel) {
    document.getElementById(HOST_SCAN_WRAP_ID)?.remove();
    return;
  }

  const existing = document.getElementById(HOST_SCAN_BUTTON_ID);
  if (existing && panel.contains(existing)) {
    updateHostScanButton();
    return;
  }
  document.getElementById(HOST_SCAN_WRAP_ID)?.remove();

  const heading = findPlayersHeading(panel);
  const container = heading?.matches("div") ? heading : heading?.parentElement;
  if (!container) return;

  const wrapper = document.createElement("span");
  wrapper.id = HOST_SCAN_WRAP_ID;
  const button = document.createElement("button");
  button.id = HOST_SCAN_BUTTON_ID;
  button.type = "button";
  button.dataset.npLabel = "Check hosts";
  button.innerHTML = hostScanButtonMarkup();
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    void startCreatorScan();
  });
  wrapper.appendChild(button);

  const layout = getComputedStyle(container);
  if (layout.display !== "flex" && layout.display !== "inline-flex" && layout.display !== "grid") {
    container.style.display = "flex";
  }
  container.style.alignItems ||= "center";
  container.appendChild(wrapper);
  updateHostScanButton();
}

function visibleCreatorRecords(panel) {
  const records = new Map();
  const byUserId = new Map(
    Array.from(state.byIgnNorm.values())
      .filter((record) => record?.userId)
      .map((record) => [String(record.userId), record])
  );

  for (const row of panel.querySelectorAll("[userid], [user-id]")) {
    const userId = String(row.getAttribute("userid") || row.getAttribute("user-id") || "").trim();
    const record = byUserId.get(userId) || findRecordInRowText(row.innerText || "");
    if (!record?.ign) continue;
    records.set(creatorKey(record.ign), record);
  }
  return [...records.values()];
}

function creatorScanDelay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function startCreatorScan() {
  if (!npSettings.creatorCodes) return;
  cachedPlayersPanel = null;
  cachedPlayersPanelAt = 0;
  let panel = findPlayersPanelRoot();
  syncCreatorSession(panel);
  if (creatorScanPreparing || creatorScanRequested) return;

  const prepareToken = ++creatorPrepareToken;
  const route = creatorSessionRouteKey || currentCreatorSessionRoute();
  creatorScanPreparing = true;
  creatorButtonFeedback = "";
  clearTimeout(creatorButtonFeedbackTimer);
  creatorButtonFeedbackTimer = null;
  updateHostScanButton();

  let records = [];
  for (let attempt = 0; attempt < 9; attempt++) {
    if (prepareToken !== creatorPrepareToken) return;
    if (route !== currentCreatorSessionRoute()) {
      resetCreatorSession(currentCreatorSessionRoute());
      return;
    }
    cachedPlayersPanel = null;
    cachedPlayersPanelAt = 0;
    panel = findPlayersPanelRoot();
    if (panel) {
      syncCreatorSession(panel);
      if (prepareToken !== creatorPrepareToken) return;
      cacheVisibleMemberRows(panel);
      records = visibleCreatorRecords(panel);
      if (records.length) break;
    }
    await creatorScanDelay(150);
  }

  if (prepareToken !== creatorPrepareToken) return;
  if (route !== currentCreatorSessionRoute()) {
    resetCreatorSession(currentCreatorSessionRoute());
    return;
  }
  creatorScanPreparing = false;
  if (!records.length) {
    setHostScanButtonFeedback(panel ? "No players found" : "Player list unavailable");
    return;
  }

  creatorLookupGeneration++;
  creatorQueue.length = 0;
  clearTimeout(creatorProgressHideTimer);
  clearTimeout(creatorProgressSettleTimer);
  clearTimeout(creatorScanWatchdogTimer);
  creatorProgressHideTimer = null;
  creatorProgressSettleTimer = null;
  creatorScanWatchdogTimer = null;
  creatorBatchKeys.clear();
  creatorBatchRunning = true;
  creatorScanRequested = true;
  creatorScanCompleted = false;
  creatorSessionMembers = visiblePanelMemberIds(panel);
  creatorSessionPanel = panel;
  updateHostScanButton();

  for (const record of records) queueCreatorLookup(record, { manual: true });
  if (!creatorBatchKeys.size) {
    creatorScanRequested = false;
    creatorBatchRunning = false;
    creatorScanCompleted = true;
    updateHostScanButton();
  } else {
    updateCreatorProgress();
    const generation = creatorLookupGeneration;
    creatorScanWatchdogTimer = setTimeout(() => {
      if (!creatorScanRequested || generation !== creatorLookupGeneration) return;
      for (const key of creatorBatchKeys) {
        const item = creatorStates.get(key);
        if (item && !["done", "error"].includes(item.status)) {
          creatorStates.set(key, {
            ...item,
            status: "error",
            error: "Host check timed out",
            retryAt: 0
          });
        }
      }
      updateCreatorProgress();
    }, CREATOR_SCAN_WATCHDOG_MS);
  }
}

// -------------------- Stable "row" selection (different approach) --------------------
// We pick the right-side clock icon, then treat its nearest "row" container as the row.
// This avoids guessing between map labels vs sidebar.
function findClockButtonsInPlayersPanel(panel) {
  if (!panel) return [];

  const buttons = Array.from(panel.querySelectorAll("button, a, [role='button']"));
  const iconButtons = buttons.filter((el) => {
    if (!el || el.nodeType !== 1) return false;
    if (!panel.contains(el)) return false;

    // Must look like icon (svg)
    const hasSvg = !!el.querySelector("svg");
    if (!hasSvg) return false;

    // Must be "small"
    const w = el.offsetWidth || 0;
    const h = el.offsetHeight || 0;
    if (w > 80 || h > 80) return false;

    // Skip our own
    if (el.classList?.contains(BTN_CLASS)) return false;
    if (el.closest?.(`.${WRAP_CLASS}`)) return false;
    if (el.id === HOST_SCAN_BUTTON_ID || el.closest?.(`#${HOST_SCAN_WRAP_ID}`)) return false;

    const cs = window.getComputedStyle(el);
    if (cs.display === "none" || cs.visibility === "hidden" || cs.opacity === "0") return false;

    return true;
  });

  return iconButtons;
}

// Choose a reasonable "row container" for a given clock button
function rowFromClockButton(clockBtn, panel) {
  if (!clockBtn) return null;

  // Prefer the closest element that also contains an avatar img + some text
  let cur = clockBtn.parentElement;
  for (let i = 0; i < 6 && cur; i++) {
    if (panel && !panel.contains(cur)) break;
    const hasImg = !!cur.querySelector("img");
    const txt = (cur.innerText || "").trim();
    if (hasImg && txt && txt.length < 120) return cur;
    cur = cur.parentElement;
  }

  // fallback
  return clockBtn.closest("div, li, button, a");
}

function findRecordInRowText(rowText) {
  const t = norm(rowText);
  if (!t) return null;

  const exact = state.byIgnNorm.get(t);
  if (exact) return exact;

  for (const [ignNorm, rec] of state.byIgnNorm.entries()) {
    if (t.includes(ignNorm)) return rec;
  }
  return null;
}

function rowAlreadyHasOurButton(row) {
  return !!row.querySelector(`.${WRAP_CLASS} .${BTN_CLASS}`);
}

function cleanupDuplicateOurButtons() {
  const rows = new Set();
  for (const wrap of document.querySelectorAll(`.${WRAP_CLASS}`)) {
    const row = wrap.closest(`[${ROW_MARK}]`) || wrap.parentElement;
    if (row) rows.add(row);
  }
  for (const row of rows) {
    const wraps = row.querySelectorAll(`.${WRAP_CLASS}`);
    for (let i = 1; i < wraps.length; i++) wraps[i].remove();
  }
}

function removePlayerCardUi() {
  document.querySelectorAll(`.${WRAP_CLASS}`).forEach((el) => el.remove());
  document.querySelectorAll(`[${ROW_MARK}]`).forEach((el) => el.removeAttribute(ROW_MARK));
  hidePopover();
}

function removeCreatorUi() {
  document.querySelectorAll(`.${HOST_BADGE_CLASS}`).forEach((el) => el.remove());
  document.querySelectorAll('[data-np-host-ready="true"]').forEach((el) => el.removeAttribute("data-np-host-ready"));
  document.querySelectorAll('[data-np-creator-status]').forEach((el) => el.removeAttribute("data-np-creator-status"));
  document.getElementById(HOST_SCAN_WRAP_ID)?.remove();
  hideCreatorProgress(true);
}

// -------------------- Shadow DOM Popover --------------------
let anchorBtn = null;
let host = null;
let pop = null;
let toastTimer = null;

function ensureShadowPopover() {
  if (host) return;

  host = document.createElement("div");
  host.style.position = "fixed";
  host.style.left = "0";
  host.style.top = "0";
  host.style.width = "0";
  host.style.height = "0";
  host.style.zIndex = "2147483647";
  document.body.appendChild(host);

  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `
    :host { all: initial; }
    .popover {
      position: fixed;
      width: 340px;
      border-radius: 10px;
      background: #0F1C25;
      border: 1px solid rgba(255,255,255,0.12);
      box-shadow: 0 14px 38px rgba(0,0,0,0.42);
      color: #fff;
      font: 13px/1.4 Gilroy, "Segoe UI", Arial, sans-serif;
      overflow: hidden;
      display: none;
    }
    .hdr {
      display: flex;
      gap: 12px;
      align-items: center;
      padding: 14px 14px 12px 14px;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .avatar {
      width: 44px;
      height: 44px;
      border-radius: 8px;
      object-fit: cover;
      border: 1px solid rgba(255,255,255,0.12);
      background: rgba(255,255,255,0.06);
      flex: 0 0 auto;
    }
    .headtext { min-width:0; flex: 1 1 auto; }
    .title {
      font-weight: 850;
      font-size: 14px;
      line-height: 1.2;
      margin: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 210px;
    }
    .sub {
      margin-top: 2px;
      font-size: 12px;
      opacity: 0.72;
    }
    .sub.host-ready {
      color: #68e0ae;
      font-weight: 700;
      opacity: 1;
    }
    .trackerBtn {
      flex: 0 0 auto;
      padding: 8px 10px;
      border-radius: 7px;
      border: 1px solid rgba(255,255,255,0.14);
      background: #1A2C38;
      color: inherit;
      cursor: pointer;
      user-select: none;
      font: 600 12px/1 Gilroy, "Segoe UI", Arial, sans-serif;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: background .12s ease, border-color .12s ease, transform .08s ease;
    }
    .trackerBtn:hover { background: rgba(255,191,64,0.10); border-color: rgba(255,191,64,0.40); color: #FFBF40; }
    .trackerBtn:active { transform: scale(0.98); }

    .body {
      padding: 12px 14px 14px 14px;
      display: grid;
      gap: 10px;
    }
    .field {
      padding: 10px;
      border-radius: 8px;
      border: 1px solid rgba(255,255,255,0.10);
      background: #0A1520;
    }
    .label {
      font-size: 11px;
      opacity: 0.72;
      margin-bottom: 6px;
      letter-spacing: 0.25px;
    }
    .row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .value {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono","Courier New", monospace;
      font-size: 12px;
      opacity: 0.96;
      word-break: break-all;
    }
    .copy {
      padding: 7px 10px;
      border-radius: 6px;
      border: 1px solid rgba(255,255,255,0.14);
      background: #1A2C38;
      color: inherit;
      cursor: pointer;
      user-select: none;
      font: 600 12px/1 Gilroy, "Segoe UI", Arial, sans-serif;
      transition: background .12s ease, border-color .12s ease, transform .08s ease;
      flex: 0 0 auto;
    }
    .copy:hover { background: rgba(255,191,64,0.10); border-color: rgba(255,191,64,0.40); color: #FFBF40; }
    .copy:active { transform: scale(0.98); }

    .toast {
      position: fixed;
      left: 50%;
      bottom: 22px;
      transform: translateX(-50%);
      background: #0A1520;
      color: white;
      padding: 10px 12px;
      border: 1px solid rgba(255,191,64,.28);
      border-radius: 8px;
      font: 600 12px/1.4 Gilroy, "Segoe UI", Arial, sans-serif;
      box-shadow: 0 12px 30px rgba(0,0,0,0.25);
      display: none;
    }

    .arrow {
      position: fixed;
      width: 12px;
      height: 12px;
      transform: rotate(45deg);
      background: #0F1C25;
      border-left: 1px solid rgba(255,255,255,0.12);
      border-top: 1px solid rgba(255,255,255,0.12);
      display: none;
      z-index: 2147483647;
    }
  `;

  const arrow = document.createElement("div");
  arrow.className = "arrow";

  pop = document.createElement("div");
  pop.className = "popover";
  pop.innerHTML = `
    <div class="hdr">
      <img class="avatar" id="av" />
      <div class="headtext">
        <div class="title" id="t"></div>
        <div class="sub" id="sub">Noble player</div>
      </div>
      <button class="trackerBtn" id="trk" title="Open FortniteTracker profile">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M14 3h7v7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M10 14 21 3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M21 14v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Tracker
      </button>
    </div>
    <div class="body">
      <div class="field">
        <div class="label">EPIC NAME</div>
        <div class="row">
          <div class="value" id="ep"></div>
          <button class="copy" id="c1">Copy</button>
        </div>
      </div>
      <div class="field">
        <div class="label">DISCORD ID</div>
        <div class="row">
          <div class="value" id="dc"></div>
          <button class="copy" id="c2">Copy</button>
        </div>
      </div>
    </div>
  `;

  const toastEl = document.createElement("div");
  toastEl.className = "toast";

  shadow.appendChild(style);
  shadow.appendChild(arrow);
  shadow.appendChild(pop);
  shadow.appendChild(toastEl);

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") hidePopover();
  });

  document.addEventListener("mousedown", (e) => {
    if (!pop || pop.style.display === "none") return;
    const path = e.composedPath ? e.composedPath() : [];
    if (anchorBtn && (e.target === anchorBtn || anchorBtn.contains(e.target))) return;
    if (path.includes(pop)) return;
    hidePopover();
  });

  host.__npShadow = { shadow, pop, arrow, toastEl };
}

function showToast(text) {
  const { toastEl } = host.__npShadow;
  toastEl.textContent = text;
  toastEl.style.display = "block";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (toastEl.style.display = "none"), 1100);
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function showPopover(btn, record) {
  ensureShadowPopover();
  anchorBtn = btn;

  const { pop, arrow } = host.__npShadow;

  pop.querySelector("#t").textContent = record.ign;
  pop.querySelector("#ep").textContent = record.ign;
  pop.querySelector("#dc").textContent = record.userId;
  const creator = creatorStates.get(creatorKey(record.ign));
  const sub = pop.querySelector("#sub");
  const epicAccountId = normalizeEpicAccountId(record.epicAccountId);
  const hostReady =
    creator?.status === "done" &&
    creator.hasCreatorCode &&
    creator.verified &&
    (!epicAccountId || !creator.accountId || creator.accountId === epicAccountId);
  if (hostReady) sub.textContent = `Host ready · ${creator.code}`;
  else if (npSettings.creatorCodes && creator?.status === "done") sub.textContent = "No verified creator code found";
  else if (npSettings.creatorCodes && ["queued", "checking"].includes(creator?.status)) sub.textContent = "Checking creator code…";
  else if (npSettings.creatorCodes && creator?.status === "error") sub.textContent = "Creator check unavailable";
  else sub.textContent = "Noble player";
  sub.classList.toggle("host-ready", hostReady);

  const av = pop.querySelector("#av");
  if (record.profilePicture) {
    av.src = record.profilePicture;
    av.style.display = "block";
  } else {
    av.removeAttribute("src");
    av.style.display = "none";
  }

  pop.querySelector("#trk").onclick = () => {
    const url = `https://fortnitetracker.com/profile/all/${encodeURIComponent(record.ign)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  pop.querySelector("#c1").onclick = async () => {
    try {
      await navigator.clipboard.writeText(record.ign);
      showToast("Copied Epic name");
    } catch {
      window.prompt("Copy Epic name:", record.ign);
    }
  };
  pop.querySelector("#c2").onclick = async () => {
    try {
      await navigator.clipboard.writeText(record.userId);
      showToast("Copied Discord ID");
    } catch {
      window.prompt("Copy Discord ID:", record.userId);
    }
  };

  const rect = btn.getBoundingClientRect();
  const popW = 340;
  const popH = 220;

  let left = rect.right + 14;
  let top = rect.top - 20;

  if (left + popW + 8 > window.innerWidth) left = rect.left - popW - 14;

  left = clamp(left, 8, window.innerWidth - popW - 8);
  top = clamp(top, 8, window.innerHeight - popH - 8);

  pop.style.left = `${left}px`;
  pop.style.top = `${top}px`;
  pop.style.display = "block";

  const arrowSize = 12;
  const arrowLeft = left > rect.right ? rect.right + 6 : rect.left - arrowSize - 6;
  const arrowTop = clamp(rect.top + rect.height / 2 - arrowSize / 2, 8, window.innerHeight - arrowSize - 8);

  arrow.style.left = `${arrowLeft}px`;
  arrow.style.top = `${arrowTop}px`;
  arrow.style.display = "block";
}

function hidePopover() {
  if (!host) return;
  const { pop, arrow } = host.__npShadow || {};
  if (pop) pop.style.display = "none";
  if (arrow) arrow.style.display = "none";
  anchorBtn = null;
}

// -------------------- Inject chevron button --------------------
function createChevronButton() {
  const wrap = document.createElement("span");
  wrap.className = WRAP_CLASS;
  wrap.style.display = "inline-flex";
  wrap.style.alignItems = "center";
  wrap.style.flex = "0 0 auto";
  wrap.style.marginRight = "6px";
  wrap.style.marginLeft = "0px";

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = BTN_CLASS;
  btn.setAttribute("aria-label", "Open user info");
  btn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  `;

  Object.assign(btn.style, {
    width: "30px",
    height: "30px",
    borderRadius: "12px",
    border: "1px solid rgba(255,255,255,0.14)",
    background: "rgba(255,255,255,0.06)",
    color: "rgba(230,237,245,0.92)",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    userSelect: "none",
    transition: "transform .08s ease, background .12s ease, border-color .12s ease"
  });

  btn.addEventListener("mouseenter", () => {
    btn.style.background = "rgba(255,255,255,0.10)";
    btn.style.borderColor = "rgba(255,255,255,0.20)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "rgba(255,255,255,0.06)";
    btn.style.borderColor = "rgba(255,255,255,0.14)";
  });
  btn.addEventListener("mousedown", () => (btn.style.transform = "scale(0.98)"));
  btn.addEventListener("mouseup", () => (btn.style.transform = "scale(1)"));

  wrap.appendChild(btn);
  return { wrap, btn };
}

function applyCreatorStatus(row, record, clockBtn) {
  const key = creatorKey(record?.ign);
  const result = key ? creatorStates.get(key) : null;
  const recordAccountId = normalizeEpicAccountId(record?.epicAccountId);
  const accountMatches = !recordAccountId || !result?.accountId || result.accountId === recordAccountId;
  const hostReady =
    npSettings.creatorCodes &&
    result?.status === "done" &&
    result.hasCreatorCode &&
    result.verified &&
    accountMatches;
  let badge = row.querySelector(`.${HOST_BADGE_CLASS}`);
  row.setAttribute("data-np-creator-status", result?.status || "waiting");

  if (!hostReady) {
    badge?.remove();
    row.removeAttribute("data-np-host-ready");
    return;
  }

  if (!badge) {
    badge = document.createElement("span");
    badge.className = HOST_BADGE_CLASS;
    const parent = clockBtn?.parentElement;
    if (parent) {
      const actions = parent.querySelector(`:scope > .${WRAP_CLASS}`);
      parent.insertBefore(badge, actions || clockBtn);
    } else {
      row.appendChild(badge);
    }
  }

  const badgeText = `Host · ${result.code}`;
  if (badge.textContent !== badgeText) badge.textContent = badgeText;
  const title = `Active creator code: ${result.code}`;
  if (badge.title !== title) badge.title = title;
  row.setAttribute("data-np-host-ready", "true");
}

function injectButtonIntoRow(row, rec, clockBtn) {
  if (rowAlreadyHasOurButton(row)) {
    const existing = row.querySelector(`.${BTN_CLASS}`);
    if (existing) existing.__npRecord = rec;
    row.setAttribute(ROW_MARK, String(rec.userId));
    return;
  }

  if (!clockBtn || !clockBtn.parentElement) return;

  const { wrap, btn } = createChevronButton();
  btn.__npRecord = rec;

  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    e.preventDefault();

    if (anchorBtn === btn && host?.__npShadow?.pop?.style.display !== "none") {
      hidePopover();
      return;
    }
    if (btn.__npRecord) showPopover(btn, btn.__npRecord);
  });

  // ✅ Always insert in same parent, right before the clock button
  clockBtn.parentElement.insertBefore(wrap, clockBtn);

  row.setAttribute(ROW_MARK, String(rec.userId));
}

function decorateAll() {
  syncCreatorSession();
  const panel = findPlayersPanelRoot();
  if (!panel) return;
  syncCreatorSession(panel);
  ensureHostScanButton(panel);
  cacheVisibleMemberRows(panel);
  if (!state.ready) return;
  if (!npSettings.playerCards && !npSettings.creatorCodes) return;

  decorateVisibleCreatorRows(panel);

  // We iterate by clock buttons (one per row), so we will inject for ALL rows.
  const clockButtons = findClockButtonsInPlayersPanel(panel);
  if (!clockButtons.length) return;

  for (const clockBtn of clockButtons) {
    const row = rowFromClockButton(clockBtn, panel);
    if (!row) continue;

    const rowText = (row.innerText || "").trim();
    const rec = findRecordInRowText(rowText);
    if (!rec) continue;

    if (npSettings.creatorCodes) {
      queueCreatorLookup(rec);
      applyCreatorStatus(row, rec, clockBtn);
    }

    if (!npSettings.playerCards) continue;

    const existing = row.querySelector(`.${BTN_CLASS}`);
    if (existing) {
      existing.__npRecord = rec;
      row.setAttribute(ROW_MARK, String(rec.userId));
      continue;
    }

    try {
      injectButtonIntoRow(row, rec, clockBtn);
    } catch (err) {
      console.warn("[NP ShadowPopover] inject error:", err);
      continue;
    }

    row.setAttribute(ROW_MARK, String(rec.userId));
  }

  if (npSettings.playerCards) cleanupDuplicateOurButtons();
}

// Observe React DOM changes
let decorateTimer = null;
const scheduleDecorate = (delay = 45) => {
  clearTimeout(decorateTimer);
  decorateTimer = setTimeout(decorateAll, delay);
};
const obs = new MutationObserver(() => scheduleDecorate());
obs.observe(document.documentElement, { childList: true, subtree: true });

// Noble uses client-side navigation, which does not always emit popstate.
// A lightweight route check makes session changes reset the host UI even when
// React reuses the existing players panel.
setInterval(() => {
  const route = currentCreatorSessionRoute();
  if (creatorSessionRouteKey && route !== creatorSessionRouteKey) {
    resetCreatorSession(route);
    scheduleDecorate(80);
  }
}, 500);

// initial pass
scheduleDecorate(250);

try {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[NPSettings.STORAGE_KEY]) {
      applySharedSettings(changes[NPSettings.STORAGE_KEY].newValue);
    }
  });
} catch {}
