(() => {
  "use strict";

  const stateEl = document.getElementById("save-state");
  const ruleList = document.getElementById("rule-list");
  const cacheStatus = document.getElementById("cache-status");
  const serviceStatus = document.getElementById("host-service-status");
  const serviceDot = document.getElementById("host-service-dot");
  const serviceButton = document.getElementById("host-service-refresh");
  let settings = NPSettings.cloneDefaults();
  let saveRevision = 0;

  function renderRules() {
    ruleList.replaceChildren();
    for (const mode of NPSettings.MODES) {
      const row = document.createElement("div");
      row.className = "rule-row";
      row.innerHTML = `
        <span class="mode-name">${NPSettings.MODE_LABELS[mode]}</span>
        <label class="number-field"><span class="sr-only">${NPSettings.MODE_LABELS[mode]} bottom count</span><input type="number" min="1" max="25" inputmode="numeric" data-rule="bottomCounts" data-mode="${mode}" value="${settings.bottomCounts[mode]}"></label>
        <label class="number-field"><span class="sr-only">${NPSettings.MODE_LABELS[mode]} minimum games</span><input type="number" min="0" max="20" inputmode="numeric" data-rule="minMatches" data-mode="${mode}" value="${settings.minMatches[mode]}"></label>
      `;
      ruleList.appendChild(row);
    }
  }

  function renderToggles() {
    document.querySelectorAll("[data-setting]").forEach((input) => {
      input.checked = Boolean(settings[input.dataset.setting]);
    });
  }

  function showSaveState(text, className = "visible") {
    stateEl.textContent = text;
    stateEl.className = `save-state ${className}`;
    clearTimeout(showSaveState.timer);
    showSaveState.timer = setTimeout(() => {
      if (!stateEl.classList.contains("error")) stateEl.className = "save-state";
    }, 1300);
  }

  function queueSave() {
    showSaveState("Saving…", "saving visible");
    const snapshot = NPSettings.sanitize(settings);
    const revision = ++saveRevision;
    // Submit immediately. Timers and queued writes can be cancelled when the
    // user closes Chrome's popup right after changing a value.
    NPSettings.save(snapshot)
      .then((saved) => {
        if (revision !== saveRevision) return;
        settings = saved;
        showSaveState("Saved");
      })
      .catch((error) => {
        if (revision !== saveRevision) return;
        console.warn("[Noble Toolkit] Failed to save settings", error);
        showSaveState("Save failed", "error");
      });
  }

  function cacheGet() {
    return new Promise((resolve) => chrome.storage.local.get([
      "np_id_cache_v1",
      "np_id_cache_updated_at",
      "np_creator_code_cache_v1",
      "np_creator_code_cache_v2",
      "np_creator_code_cache_v3",
      "np_creator_code_cache_v4",
      "np_creator_code_cache_v5",
      "np_creator_code_cache_v6",
      "np_creator_code_cache_v7",
      "np_creator_code_cache_v8"
    ], resolve));
  }

  function sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
        else resolve(response || { ok: false, error: "No response" });
      });
    });
  }

  function renderServiceStatus(status) {
    const ready = Boolean(status?.configured && status?.online && status?.ready);
    serviceDot.className = `epic-dot${ready ? " connected" : status?.online ? " pending" : ""}`;
    serviceButton.disabled = false;
    serviceButton.textContent = "Check";

    if (ready) {
      serviceStatus.textContent = "Online — exact host checks ready";
    } else if (!status?.configured) {
      serviceStatus.textContent = "Waiting for service deployment";
    } else if (status?.online) {
      serviceStatus.textContent = "Online, but Epic service account is not configured";
    } else {
      serviceStatus.textContent = status?.error || "Host service unavailable";
    }
  }

  async function refreshServiceStatus() {
    try {
      renderServiceStatus(await sendMessage({ type: "NP_HOST_SERVICE_STATUS" }));
    } catch {
      renderServiceStatus({ configured: true, online: false, error: "Service status unavailable" });
    }
  }

  async function refreshCacheStatus() {
    try {
      const items = await cacheGet();
      const ids = new Set(Object.values(items.np_id_cache_v1 || {}).map(String));
      const creatorEntries = Object.values(
        items.np_creator_code_cache_v8 ||
        items.np_creator_code_cache_v7 ||
        items.np_creator_code_cache_v6 ||
        items.np_creator_code_cache_v5 ||
        {}
      );
      const creatorChecks = new Set(creatorEntries.map((entry, index) => entry?.accountId || `entry:${index}`)).size;
      if (!ids.size && !creatorChecks) {
        cacheStatus.textContent = "No cached data yet";
        return;
      }
      const updated = Number(items.np_id_cache_updated_at || 0);
      const age = updated ? ` • updated ${new Date(updated).toLocaleDateString()}` : "";
      const parts = [];
      if (ids.size) parts.push(`${ids.size.toLocaleString()} player ID${ids.size === 1 ? "" : "s"}`);
      if (creatorChecks) parts.push(`${creatorChecks.toLocaleString()} creator check${creatorChecks === 1 ? "" : "s"}`);
      cacheStatus.textContent = `${parts.join(" · ")}${age}`;
    } catch {
      cacheStatus.textContent = "Cache status unavailable";
    }
  }

  document.addEventListener("change", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement)) return;

    if (target.dataset.setting) {
      settings[target.dataset.setting] = target.checked;
      queueSave();
    }
  });

  document.addEventListener("input", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLInputElement)) return;
    if (target.dataset.rule && target.dataset.mode) {
      const group = target.dataset.rule;
      const mode = target.dataset.mode;
      const min = group === "bottomCounts" ? 1 : 0;
      const max = group === "bottomCounts" ? 25 : 20;
      const parsed = Number.parseInt(target.value, 10);
      if (!Number.isFinite(parsed)) return;
      const value = Math.max(min, Math.min(max, parsed));
      target.value = String(value);
      settings[group][mode] = value;
      queueSave();
    }
  });

  document.getElementById("reset-rules").addEventListener("click", () => {
    settings.bottomCounts = { ...NPSettings.DEFAULTS.bottomCounts };
    settings.minMatches = { ...NPSettings.DEFAULTS.minMatches };
    renderRules();
    queueSave();
  });

  document.getElementById("clear-cache").addEventListener("click", async (event) => {
    const button = event.currentTarget;
    button.disabled = true;
    button.textContent = "Clearing…";
    await new Promise((resolve) => chrome.storage.local.remove([
      "np_id_cache_v1",
      "np_id_cache_updated_at",
      "np_creator_code_cache_v1",
      "np_creator_code_cache_v2",
      "np_creator_code_cache_v3",
      "np_creator_code_cache_v4",
      "np_creator_code_cache_v5",
      "np_creator_code_cache_v6",
      "np_creator_code_cache_v7",
      "np_creator_code_cache_v8"
    ], resolve));
    await refreshCacheStatus();
    button.textContent = "Cleared";
    setTimeout(() => {
      button.disabled = false;
      button.textContent = "Clear";
    }, 900);
  });

  serviceButton.addEventListener("click", () => {
    serviceButton.disabled = true;
    serviceButton.textContent = "Checking…";
    refreshServiceStatus();
  });

  async function boot() {
    const manifest = chrome.runtime.getManifest();
    document.getElementById("version").textContent = `v${manifest.version}`;
    settings = await NPSettings.load();
    renderToggles();
    renderRules();
    refreshCacheStatus();
    refreshServiceStatus();
  }

  boot().catch((error) => {
    console.warn("[Noble Toolkit] Popup failed to initialize", error);
    showSaveState("Settings unavailable", "error");
  });
})();
