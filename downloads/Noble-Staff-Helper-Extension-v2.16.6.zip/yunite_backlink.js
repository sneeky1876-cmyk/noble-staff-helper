// Adds an isolated return link on Yunite leaderboards without touching Yunite's app DOM.
(() => {
  "use strict";

  const HOST_ID = "np-yunite-noble-backlink";

  function leaderboardId() {
    const match = String(location.pathname || "").match(/^\/leaderboard\/([^/?#]+)/i);
    if (!match) return "";
    try {
      return decodeURIComponent(match[1]).trim();
    } catch {
      return "";
    }
  }

  function createButton(id) {
    const host = document.createElement("div");
    host.id = HOST_ID;
    host.setAttribute("data-np-extension-ui", "true");
    const shadow = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = `
      :host {
        display: block;
        width: min(340px, calc(100% - 24px));
        margin: 12px 0 18px;
        font-family: Gilroy, Inter, system-ui, -apple-system, "Segoe UI", sans-serif;
      }
      :host([data-floating="true"]) {
        position: fixed;
        top: 18px;
        left: 18px;
        z-index: 2147483647;
        width: 340px;
        max-width: calc(100vw - 36px);
        margin: 0;
      }
      a {
        box-sizing: border-box;
        display: flex;
        width: 100%;
        min-height: 40px;
        align-items: center;
        justify-content: space-between;
        gap: 10px;
        padding: 8px 12px;
        border: 0;
        border-radius: 4px;
        color: #fff;
        background: #242628;
        font-size: 14px;
        font-weight: 600;
        line-height: 1;
        text-decoration: none;
        white-space: nowrap;
        transition: background 300ms ease;
      }
      a:hover {
        background: #303336;
      }
      a:focus-visible {
        outline: 2px solid #ffbf40;
        outline-offset: 2px;
      }
      .label {
        display: inline-flex;
        min-width: 0;
        height: 24px;
        align-items: center;
        gap: 8px;
      }
      .crown {
        width: 28px;
        height: 24px;
        flex: 0 0 28px;
        object-fit: contain;
      }
      .external {
        display: inline-flex;
        width: 16px;
        height: 16px;
        flex: 0 0 16px;
        align-items: center;
        justify-content: center;
        color: rgba(255, 255, 255, .7);
      }
      .external svg { width: 16px; height: 16px; }
      @media (prefers-reduced-motion: reduce) {
        a { transition: none; }
      }
    `;

    const link = document.createElement("a");
    link.href = `https://nobleprac.com/leaderboards/${encodeURIComponent(id)}`;
    link.setAttribute("aria-label", "Back to Noble leaderboard");
    link.title = "Open the matching Noble leaderboard";
    const label = document.createElement("span");
    label.className = "label";
    const crown = document.createElement("img");
    crown.className = "crown";
    crown.src = chrome.runtime.getURL("noble-crown.png");
    crown.alt = "";
    label.append(crown);
    const text = document.createElement("span");
    text.textContent = "Noble Leaderboard";
    label.append(text);

    const external = document.createElement("span");
    external.className = "external";
    external.setAttribute("aria-hidden", "true");
    external.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none">
        <path d="M14 3h7v7M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"
          stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
      </svg>`;
    link.append(label, external);

    shadow.append(style, link);
    host.__npLink = link;
    return host;
  }

  function titleRow() {
    const headings = Array.from(document.querySelectorAll("h1"));
    const visible = headings.filter((heading) => {
      const rect = heading.getBoundingClientRect();
      return (heading.textContent || "").trim() && rect.width > 0 && rect.height > 0;
    });
    const heading = visible.find((candidate) => /practice|session|leaderboard/i.test(candidate.textContent || ""))
      || visible[0]
      || null;
    return heading?.parentElement || heading;
  }

  function syncButton() {
    const id = leaderboardId();
    let host = document.getElementById(HOST_ID);
    if (!id) {
      host?.remove();
      return;
    }

    if (!host) {
      host = createButton(id);
    }
    if (host?.__npLink) {
      host.__npLink.href = `https://nobleprac.com/leaderboards/${encodeURIComponent(id)}`;
    }

    const anchor = titleRow();
    if (anchor) {
      host.dataset.floating = "false";
      if (host.previousElementSibling !== anchor) anchor.insertAdjacentElement("afterend", host);
    } else {
      host.dataset.floating = "true";
      if (host.parentElement !== document.body) document.body?.appendChild(host);
    }
  }

  syncButton();
  window.addEventListener("popstate", syncButton);
  window.addEventListener("hashchange", syncButton);
  setInterval(syncButton, 750);
})();
