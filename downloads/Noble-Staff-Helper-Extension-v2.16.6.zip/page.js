// Page-world bridge: observes NoblePrac WebSocket JSON and forwards relevant payloads.
(() => {
  "use strict";

  const TAG = "__NP_HELPER__";
  const channel = document.currentScript?.dataset?.npChannel || "";
  if (!channel || window.__np_ws_patched) return;
  window.__np_ws_patched = true;

  const NativeWebSocket = window.WebSocket;
  if (typeof NativeWebSocket !== "function") return;

  function post(payload) {
    window.postMessage({
      [TAG]: true,
      channel,
      type: "NP_WS_JSON",
      payload
    }, location.origin);
  }

  function isRelevant(payload) {
    if (!payload || typeof payload !== "object") return false;
    const event = String(payload.event || "").toLowerCase();
    return Boolean(
      Array.isArray(payload.teams) ||
      Array.isArray(payload.drops) ||
      Array.isArray(payload.data?.teams) ||
      Array.isArray(payload.data?.drops) ||
      Array.isArray(payload.payload?.teams) ||
      Array.isArray(payload.payload?.drops) ||
      [
        "connection-confirmed",
        "add-team",
        "remove-team",
        "drop-claimed",
        "drop-unclaimed",
        "new-drop",
        "delete-drop"
      ].includes(event)
    );
  }

  function parseText(text) {
    try {
      const parsed = JSON.parse(text);
      if (isRelevant(parsed)) post(parsed);
    } catch {
      // NoblePrac also sends non-JSON socket frames; ignore those.
    }
  }

  function handleMessage(event) {
    const data = event.data;
    if (typeof data === "string") {
      parseText(data);
      return;
    }

    if (data instanceof ArrayBuffer) {
      try {
        parseText(new TextDecoder("utf-8").decode(new Uint8Array(data)));
      } catch {}
      return;
    }

    if (data instanceof Blob) {
      data.text().then(parseText).catch(() => {});
    }
  }

  function observeSocket(socket) {
    // One independent listener avoids duplicate forwarding and does not interfere
    // with the page's add/removeEventListener or onmessage behavior.
    NativeWebSocket.prototype.addEventListener.call(socket, "message", handleMessage);
    return socket;
  }

  function findLeafletMap() {
    try {
      const leaflet = window.L;
      const container = document.querySelector(".leaflet-container, [class*='leaflet-container']");
      if (!leaflet || !container) return null;
      const targets = leaflet.DomEvent?._targets || {};
      const direct = targets[container._leaflet_id];
      if (direct?.eachLayer) return direct;
      return Object.values(targets).find((candidate) =>
        candidate?.eachLayer && candidate?._container === container
      ) || null;
    } catch {
      return null;
    }
  }

  function polygonCoordinateKey(layer) {
    try {
      const latLngs = layer?.getLatLngs?.();
      const ring = Array.isArray(latLngs?.[0]) ? latLngs[0] : [];
      if (!ring.length) return "";
      return JSON.stringify(ring.map((point) => [point.lat, point.lng]));
    } catch {
      return "";
    }
  }

  function applyDropFilter(visibleKeys) {
    const map = findLeafletMap();
    if (!map) return false;
    const filterActive = Array.isArray(visibleKeys);
    const keys = new Set(filterActive ? visibleKeys : []);
    map.eachLayer((layer) => {
      if (typeof layer?.getLatLngs !== "function" || typeof layer?.setStyle !== "function") return;
      const shouldShow = !filterActive || keys.has(polygonCoordinateKey(layer));
      if (!layer.__npOriginalFilterStyle) {
        layer.__npOriginalFilterStyle = {
          opacity: Number.isFinite(layer.options?.opacity) ? layer.options.opacity : 1,
          fillOpacity: Number.isFinite(layer.options?.fillOpacity) ? layer.options.fillOpacity : 0.4
        };
      }
      if (!shouldShow) {
        layer.setStyle({ opacity: 0, fillOpacity: 0 });
        layer.__npFilterHidden = true;
      } else if (layer.__npFilterHidden) {
        layer.setStyle(layer.__npOriginalFilterStyle);
        layer.__npFilterHidden = false;
      }
    });
    return true;
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window || event.origin !== location.origin) return;
    const message = event.data;
    if (
      !message ||
      message.__NP_TOOLKIT_COMMAND__ !== true ||
      message.channel !== channel ||
      message.type !== "NP_MAP_DROP_FILTER"
    ) return;
    applyDropFilter(message.visibleKeys);
  });

  const WebSocketProxy = new Proxy(NativeWebSocket, {
    construct(target, args, newTarget) {
      const constructor = newTarget === WebSocketProxy ? target : newTarget;
      return observeSocket(Reflect.construct(target, args, constructor));
    },
    apply(target, thisArg, args) {
      // Preserve the native error when WebSocket is called without `new`.
      return Reflect.apply(target, thisArg, args);
    }
  });

  window.WebSocket = WebSocketProxy;
  console.debug("[Noble Toolkit] WebSocket bridge active");
})();
