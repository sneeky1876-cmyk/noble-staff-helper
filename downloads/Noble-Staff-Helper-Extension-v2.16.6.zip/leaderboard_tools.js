// Per-row leaderboard actions. Uses the shared Bottom-N mode settings.
(() => {
  "use strict";

  const ROW_WRAP_CLASS = "np-lb-row-actions-v1";
  const TOAST_ID = "np-lb-toast-v1";
  const MATCH_BADGE_CLASS = "np-lb-match-attendance";
  const MATCH_DOT_CLASS = "np-lb-incomplete-dot";
  const MISSING_ID_DOT_CLASS = "np-lb-missing-id-dot";
  const MATCH_CACHE_KEY = "np_lb_match_cache_v1";
  let settings = NPSettings.cloneDefaults();
  let idCache = {};
  let idCacheLoadedAt = 0;
  let lastAttendanceSignature = "";
  let attendanceSaveTimer = null;

  const isLeaderboardPage = () => /^\/leaderboards\/[^/]+/i.test(location.pathname);
  const currentRule = () => NPSettings.modeConfig(settings, NPSettings.detectMode());

  function normalizeName(raw) {
    const normalized = String(raw || "")
      .normalize("NFKC")
      .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
    const normKey = normalized.replace(/[^\p{L}\p{N}\s]+/gu, "").replace(/\s+/g, " ").trim();
    return { normKey, looseKey: normKey.replace(/\s+/g, "") };
  }

  function resolveDiscordId(name, cache) {
    const { normKey, looseKey } = normalizeName(name);
    if (!normKey || !looseKey) return null;
    if (cache[normKey]) return cache[normKey];
    if (cache[looseKey]) return cache[looseKey];
    for (const [key, id] of Object.entries(cache)) {
      const candidate = normalizeName(key).looseKey;
      if (candidate === looseKey) return id;
    }
    return null;
  }

  function storageGet(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(keys, (items) => resolve(items || {}));
      } catch {
        resolve({});
      }
    });
  }

  function storageSet(items) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.set(items, () => resolve());
      } catch {
        resolve();
      }
    });
  }

  async function refreshCache(force = false) {
    if (!force && Date.now() - idCacheLoadedAt < 8000) return idCache;
    const stored = await storageGet(["np_id_cache_v1"]);
    idCache = stored.np_id_cache_v1 || {};
    idCacheLoadedAt = Date.now();
    return idCache;
  }

  function parseLeaderboardRow(element) {
    if (!element || element.tagName !== "TR") return null;
    const cell = Array.from(element.children || []).find((child) => child.tagName === "TD");
    const shell = cell?.firstElementChild;
    const columns = Array.from(shell?.children || []);
    if (columns.length < 6) return null;

    const rank = Number.parseInt((columns[0].textContent || "").trim(), 10);
    const matches = Number.parseInt((columns[3].textContent || "").trim(), 10);
    if (!Number.isFinite(rank) || rank < 1 || rank > 500 || !Number.isFinite(matches)) return null;

    let elements = Array.from(columns[1].querySelectorAll("span")).filter((span) =>
      String(span.className || "").includes("text-[var(--yellow)]")
    );
    if (!elements.length) {
      elements = Array.from(columns[1].querySelectorAll("span")).filter((span) => {
        if (span.closest(`.${ROW_WRAP_CLASS}, .${MATCH_BADGE_CLASS}`)) return false;
        const text = (span.textContent || "").trim();
        return text.length >= 2 && text.length <= 64 && text !== "+" && !/^\d+(?:\.\d+)?$/.test(text);
      });
    }
    const players = elements
      .map((el) => ({ el, text: (el.textContent || "").replace(/\s+/g, " ").trim() }))
      .filter(({ text }) => Boolean(text));
    // Noble's left-most name is the registered player. Names to its right are
    // teammates entered by that registrant and are intentionally ignored by
    // ID, Bottom-N, and role tooling.
    return players.length ? { rank, matches, players: players.slice(0, 1), leftPlayer: players[0], shell } : null;
  }

  function toast(message) {
    let element = document.getElementById(TOAST_ID);
    if (!element) {
      element = document.createElement("div");
      element.id = TOAST_ID;
      Object.assign(element.style, {
        position: "fixed", left: "50%", top: "18px", transform: "translateX(-50%)", zIndex: "2147483647",
        maxWidth: "84vw", padding: "9px 12px", border: "1px solid rgba(255,191,64,.28)", borderRadius: "8px",
        color: "#fff", background: "#0f1c25",
        boxShadow: "0 12px 34px rgba(0,0,0,.4)",
        font: "600 12px/1.35 Gilroy,Segoe UI,Arial,sans-serif", display: "none"
      });
      document.body.appendChild(element);
    }
    element.textContent = message;
    element.style.display = "block";
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { element.style.display = "none"; }, 1500);
  }

  function looksLikeRow(element) {
    if (!parseLeaderboardRow(element)) return false;
    const rect = element.getBoundingClientRect();
    return rect.height >= 18 && rect.height <= 220 && rect.width >= 180;
  }

  function findRows() {
    const elements = Array.from(document.querySelectorAll("tbody > tr, tr")).filter(looksLikeRow);
    const byRank = new Map();
    for (const element of elements) {
      if (element.closest(`.${ROW_WRAP_CLASS}`)) continue;
      const parsed = parseLeaderboardRow(element);
      if (!parsed) continue;
      const { rank } = parsed;
      const previous = byRank.get(rank);
      if (!previous || element.getBoundingClientRect().height < previous.el.getBoundingClientRect().height) {
        byRank.set(rank, { el: element, rank, parsed });
      }
    }
    return Array.from(byRank.values()).sort((a, b) => a.rank - b.rank);
  }

  function extractMatchesPlayed(rowElement) {
    return parseLeaderboardRow(rowElement)?.matches ?? null;
  }

  function nameCandidates(rowElement) {
    return parseLeaderboardRow(rowElement)?.players || [];
  }

  function extractLeftName(rowElement) {
    return nameCandidates(rowElement)[0]?.text || null;
  }

  async function syncMissingIdDots(rows) {
    const cache = await refreshCache();
    const liveDots = new Set();

    for (const row of rows) {
      const parsed = row.parsed || parseLeaderboardRow(row.el);
      const player = parsed?.leftPlayer;
      if (!player?.el || !player.text) continue;
      const missing = !resolveDiscordId(player.text, cache);
      let dot = player.el.nextElementSibling?.classList?.contains(MISSING_ID_DOT_CLASS)
        ? player.el.nextElementSibling
        : null;

      if (!missing) {
        dot?.remove();
        continue;
      }
      if (!dot) {
        dot = document.createElement("span");
        dot.className = MISSING_ID_DOT_CLASS;
        dot.setAttribute("role", "img");
        dot.setAttribute("aria-label", "Missing Discord ID");
        dot.title = "Missing Discord ID for this registered player";
        player.el.insertAdjacentElement("afterend", dot);
      }
      liveDots.add(dot);
    }

    document.querySelectorAll(`.${MISSING_ID_DOT_CLASS}`).forEach((dot) => {
      if (!liveDots.has(dot)) dot.remove();
    });
  }

  function bottomRanks(rows, minMatches, count) {
    const ranks = new Set();
    for (let index = rows.length - 1; index >= 0 && ranks.size < count; index--) {
      const matches = extractMatchesPlayed(rows[index].el);
      if (matches != null && matches >= minMatches) ranks.add(rows[index].rank);
    }
    return ranks;
  }

  function leaderboardRouteKey() {
    return String(location.pathname || "").replace(/\/+$/, "").toLowerCase();
  }

  function buildAttendanceSnapshot(rows) {
    const expectedMatches = rows.reduce((maximum, row) => {
      const matches = Number(row.parsed?.matches ?? extractMatchesPlayed(row.el));
      return Number.isFinite(matches) ? Math.max(maximum, matches) : maximum;
    }, 0);
    const players = {};
    for (const row of rows) {
      const parsed = row.parsed || parseLeaderboardRow(row.el);
      const player = parsed?.players?.[0];
      const key = normalizeName(player?.text).looseKey;
      if (!key || !Number.isFinite(parsed?.matches)) continue;
      players[key] = {
        name: player.text,
        matches: parsed.matches
      };
    }
    return {
      routeKey: leaderboardRouteKey(),
      expectedMatches,
      players
    };
  }

  function persistAttendanceSnapshot(snapshot) {
    if (!snapshot.routeKey || !Object.keys(snapshot.players).length) return;
    const signature = JSON.stringify(snapshot);
    if (signature === lastAttendanceSignature) return;
    lastAttendanceSignature = signature;
    clearTimeout(attendanceSaveTimer);
    attendanceSaveTimer = setTimeout(async () => {
      const stored = await storageGet([MATCH_CACHE_KEY]);
      const cache = stored[MATCH_CACHE_KEY] && typeof stored[MATCH_CACHE_KEY] === "object"
        ? stored[MATCH_CACHE_KEY]
        : {};
      const entries = cache.entries && typeof cache.entries === "object" ? { ...cache.entries } : {};
      const previous = entries[snapshot.routeKey] && typeof entries[snapshot.routeKey] === "object"
        ? entries[snapshot.routeKey]
        : {};
      entries[snapshot.routeKey] = {
        updatedAt: Date.now(),
        expectedMatches: Math.max(Number(previous.expectedMatches || 0), snapshot.expectedMatches),
        players: {
          ...(previous.players && typeof previous.players === "object" ? previous.players : {}),
          ...snapshot.players
        }
      };
      const ordered = Object.entries(entries)
        .sort(([, a], [, b]) => Number(b?.updatedAt || 0) - Number(a?.updatedAt || 0))
        .slice(0, 20);
      await storageSet({
        [MATCH_CACHE_KEY]: {
          version: 1,
          latestKey: snapshot.routeKey,
          entries: Object.fromEntries(ordered)
        }
      });
    }, 180);
  }

  function removeAttendanceUi() {
    document.querySelectorAll(`.${MATCH_BADGE_CLASS}`).forEach((element) => element.remove());
  }

  function syncAttendanceUi(rows) {
    if (!settings.matchAttendance) {
      removeAttendanceUi();
      return;
    }
    const snapshot = buildAttendanceSnapshot(rows);
    if (snapshot.expectedMatches <= 0) {
      removeAttendanceUi();
      return;
    }
    const liveBadges = new Set();
    for (const row of rows) {
      const parsed = row.parsed || parseLeaderboardRow(row.el);
      const player = parsed?.players?.[0];
      if (!player || !Number.isFinite(parsed.matches)) continue;
      let badge = Array.from(row.el.querySelectorAll(`.${MATCH_BADGE_CLASS}`))
        .find((element) => element.dataset.npPlayerKey === normalizeName(player.text).looseKey);
      if (!badge) {
        badge = document.createElement("span");
        badge.className = MATCH_BADGE_CLASS;
        badge.dataset.npPlayerKey = normalizeName(player.text).looseKey;
        const dot = document.createElement("i");
        dot.className = MATCH_DOT_CLASS;
        dot.setAttribute("aria-hidden", "true");
        const copy = document.createElement("span");
        copy.className = "np-lb-match-copy";
        badge.append(dot, copy);
        player.el.insertAdjacentElement("afterend", badge);
      }
      liveBadges.add(badge);
      const incomplete = snapshot.expectedMatches > 0 && parsed.matches < snapshot.expectedMatches;
      badge.classList.toggle("is-incomplete", incomplete);
      const copy = badge.querySelector(".np-lb-match-copy");
      const label = `${parsed.matches}/${snapshot.expectedMatches} game${snapshot.expectedMatches === 1 ? "" : "s"}`;
      if (copy && copy.textContent !== label) copy.textContent = label;
      badge.title = incomplete
        ? `Missed games · played ${parsed.matches} of ${snapshot.expectedMatches}`
        : `Played all ${snapshot.expectedMatches} game${snapshot.expectedMatches === 1 ? "" : "s"}`;
      badge.setAttribute("aria-label", badge.title);
    }
    document.querySelectorAll(`.${MATCH_BADGE_CLASS}`).forEach((badge) => {
      if (!liveBadges.has(badge)) badge.remove();
    });
    persistAttendanceSnapshot(snapshot);
  }

  function styleButton(button, role = false) {
    Object.assign(button.style, {
      padding: "4px 7px", borderRadius: "9px", border: `1px solid ${role ? "rgba(251,113,133,.28)" : "rgba(255,255,255,.14)"}`,
      background: role ? "rgba(244,63,94,.08)" : "rgba(255,255,255,.045)", color: role ? "#fecdd3" : "#e8eaeb",
      cursor: "pointer", font: "600 11px/1 Gilroy,Segoe UI,Arial,sans-serif", whiteSpace: "nowrap"
    });
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        window.prompt("Copy:", text);
        return true;
      } catch {
        return false;
      }
    }
  }

  function makeActionButton(playerName, kind) {
    const button = document.createElement("button");
    button.type = "button";
    button.dataset.kind = kind;
    button.textContent = kind === "id" ? "Copy ID" : "*role bott";
    styleButton(button, kind === "role");
    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      // Always refresh here so buttons created before a new session cache update
      // never hold on to a stale cache object.
      const cache = await refreshCache(true);
      const id = resolveDiscordId(playerName, cache);
      if (!id) {
        toast(`Missing ID for ${playerName}. Refresh a session page once.`);
        return;
      }
      const output = kind === "role" ? `*role ${id} bott` : String(id);
      const copied = await copyText(output);
      toast(copied ? (kind === "role" ? "Role command copied" : `Copied ID ${id}`) : "Copy failed");
    });
    return button;
  }

  function ensureActions(rowElement, rank, isBottom) {
    const candidates = nameCandidates(rowElement);
    const wrappers = Array.from(rowElement.querySelectorAll(`.${ROW_WRAP_CLASS}`));
    const liveKeys = new Set();

    candidates.forEach(({ el, text }, index) => {
      const baseKey = normalizeName(text).looseKey || `player-${index}`;
      const playerKey = `${baseKey}:${index}`;
      liveKeys.add(playerKey);
      let wrapper = wrappers.find((item) => item.dataset.playerKey === playerKey);

      if (!wrapper) {
        wrapper = document.createElement("span");
        wrapper.className = ROW_WRAP_CLASS;
        wrapper.dataset.playerKey = playerKey;
        wrapper.dataset.playerName = text;
        Object.assign(wrapper.style, { display: "inline-flex", alignItems: "center", gap: "5px", marginLeft: "6px", marginRight: "2px", verticalAlign: "middle", flex: "0 0 auto" });
        wrapper.appendChild(makeActionButton(text, "id"));
        try {
          const dot = el.nextElementSibling?.classList?.contains(MISSING_ID_DOT_CLASS)
            ? el.nextElementSibling
            : null;
          (dot || el).insertAdjacentElement("afterend", wrapper);
        } catch {
          rowElement.appendChild(wrapper);
        }
      }

      wrapper.dataset.rank = String(rank);
      const roleButton = wrapper.querySelector('button[data-kind="role"]');
      if (isBottom && !roleButton) wrapper.appendChild(makeActionButton(text, "role"));
      if (!isBottom && roleButton) roleButton.remove();
    });

    wrappers.forEach((wrapper) => {
      if (!liveKeys.has(wrapper.dataset.playerKey || "")) wrapper.remove();
    });
  }

  function removeUi(includeMissingDots = false) {
    document.querySelectorAll(`.${ROW_WRAP_CLASS}`).forEach((element) => element.remove());
    if (includeMissingDots) {
      document.querySelectorAll(`.${MISSING_ID_DOT_CLASS}`).forEach((element) => element.remove());
    }
    document.getElementById(TOAST_ID)?.remove();
  }

  let scheduled = false;
  async function tick() {
    scheduled = false;
    if (!isLeaderboardPage()) {
      removeUi(true);
      removeAttendanceUi();
      return;
    }

    const rows = findRows();
    if (!rows.length) {
      document.querySelectorAll(`.${MISSING_ID_DOT_CLASS}`).forEach((element) => element.remove());
      removeAttendanceUi();
      return;
    }
    syncAttendanceUi(rows);
    await syncMissingIdDots(rows);
    if (!settings.rowActions) {
      removeUi();
      return;
    }
    const rule = currentRule();
    const ranks = bottomRanks(rows, rule.minMatches, rule.bottomCount);
    for (const row of rows) ensureActions(row.el, row.rank, ranks.has(row.rank));

    // Remove actions from React-recycled elements no longer recognized as rows.
    const liveRows = new Set(rows.map(({ el }) => el));
    document.querySelectorAll(`.${ROW_WRAP_CLASS}`).forEach((wrapper) => {
      if (!Array.from(liveRows).some((element) => element.contains(wrapper))) wrapper.remove();
    });
  }

  function scheduleTick() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(tick, 180);
  }

  NPSettings.load().then((loaded) => {
    settings = loaded;
    scheduleTick();
  }).catch(scheduleTick);

  new MutationObserver(scheduleTick).observe(document.documentElement, { childList: true, subtree: true });

  let lastRoute = location.pathname + location.search;
  setInterval(() => {
    const route = location.pathname + location.search;
    if (route !== lastRoute) {
      lastRoute = route;
      scheduleTick();
    }
  }, 700);

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.np_id_cache_v1) idCacheLoadedAt = 0;
      if (changes[NPSettings.STORAGE_KEY]) settings = NPSettings.sanitize(changes[NPSettings.STORAGE_KEY].newValue);
      scheduleTick();
    });
  } catch {}
})();
