"use strict";

let npSettings = NPSettings.cloneDefaults();

function applySharedSettings(settings) {
  npSettings = NPSettings.sanitize(settings);
  document.documentElement?.setAttribute("data-np-motion", npSettings.animations ? "on" : "off");
  if (!npSettings.playerCards) removePlayerCardUi();
  if (!npSettings.creatorCodes) removeCreatorUi();
  if (!npSettings.matchAttendance) removeMatchAttendanceUi();
  if (npSettings.matchAttendance) {
    loadMatchAttendanceCache().then(() => decorateAll()).catch(() => {});
  }
  if (npSettings.playerCards || npSettings.creatorCodes || npSettings.matchAttendance) decorateAll();
}

NPSettings.load().then(applySharedSettings).catch(() => {});

// -------------------- Cache from WS --------------------
const state = {
  byIgnNorm: new Map(), // norm IGN -> { ign, userId, profilePicture, epicAccountId }
  rosterUserIds: new Set(),
  markedUserIds: new Set(),
  dropKeyByUserId: new Map(),
  ready: false
};

const HOST_BADGE_CLASS = "np-host-ready-badge";
const HOST_NAME_CLASS = "np-host-ready-name";
const HOST_INDICATOR_CLASS = "np-host-ready-indicator";
const HOST_MAP_NAME_CLASS = "np-host-ready-map-name";
const CREATOR_PROGRESS_ID = "np-creator-progress";
const HOST_SCAN_BUTTON_ID = "np-host-scan-btn";
const HOST_SCAN_WRAP_ID = "np-host-scan-wrap";
const PLAYER_SEARCH_FOCUS_CLASS = "np-player-search-focus";
const TEAMS_MARKED_CLASS = "np-teams-marked-copy";
const SITE_CREDIT_ID = "np-toolkit-site-credit";
const MAP_CORNER_TOOLS_ID = "np-map-corner-tools";
const MAP_LAYERS_BUTTON_ID = "np-map-layers-button";
const MAP_LAYERS_PANEL_ID = "np-map-layers-panel";
const MAP_NO_DROP_LAYER_ID = "np-map-no-drop-layer";
const MAP_FILTER_STORAGE_KEY = "np_map_filters_v3";
const MAP_FILTER_LEGACY_STORAGE_KEY = "np_map_filter_v2";
const MAP_CORNER_INSET_PX = 20;
const MATCH_ATTENDANCE_CACHE_KEY = "np_lb_match_cache_v1";
const SESSION_INCOMPLETE_DOT_CLASS = "np-session-incomplete-dot";
const YUNITE_SESSION_SLOT_ID = "np-yunite-session-slot";
const YUNITE_LEADERBOARD_SLOT_ID = "np-yunite-leaderboard-slot";
const PLAYER_LIST_ROW_SELECTOR = "[userid]";
const CREATOR_CACHE_KEYS = ["np_creator_code_cache_v8", "np_creator_code_cache_v7"];
const CREATOR_CACHE_DISPLAY_TTL = 90 * 24 * 60 * 60 * 1000;
const CREATOR_CONCURRENCY = 48;
const CREATOR_PROGRESS_SETTLE_MS = 1200;
const CREATOR_SCAN_WATCHDOG_MS = 25_000;
const creatorStates = new Map();
const creatorQueue = [];
const creatorBatchKeys = new Set();
const creatorActiveByGeneration = new Map();
let creatorDecorateTimer = null;
let creatorBatchRunning = false;
let creatorProgressHideTimer = null;
let creatorProgressSettleTimer = null;
let creatorScanRequested = false;
let creatorScanPreparing = false;
let creatorScanCompleted = false;
let creatorScanWatchdogTimer = null;
let creatorLookupGeneration = 0;
let creatorPrepareToken = 0;
let creatorSessionRouteKey = "";
let creatorSessionMembers = new Set();
let creatorSessionPanel = null;
let creatorButtonFeedback = "";
let creatorButtonFeedbackTimer = null;
let playerSearchTimer = null;
let playerSearchRevealTimer = null;
let playerSearchClearTimer = null;
let playerSearchFocusedRow = null;
let playerSearchRetryTimers = [];
let mapLayerSyncTimer = null;
let mapCornerPositionFrame = null;
let matchAttendanceCache = null;
let matchAttendanceLoadPromise = null;
let matchAttendanceFetchPromise = null;
let matchAttendanceFetchRoute = "";
let matchAttendanceFetchedAt = 0;
const MAP_FILTER_KEYS = Object.freeze(["hosts", "noDrops", "contested"]);
let mapFilterModes = new Set();

function norm(s) {
  return String(s || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function attendanceNameKey(raw) {
  return String(raw || "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, "");
}

function normalizeLeaderboardRoute(value) {
  try {
    return new URL(String(value || ""), location.href).pathname.replace(/\/+$/, "").toLowerCase();
  } catch {
    return "";
  }
}

function sessionLeaderboardRouteKey() {
  const links = Array.from(document.querySelectorAll('a[href*="/leaderboards/"]'));
  const preferred = links.find((link) => /session\s+leaderboard/i.test(link.textContent || "")) || links[0];
  return preferred ? normalizeLeaderboardRoute(preferred.href || preferred.getAttribute("href")) : "";
}

function leaderboardIdFromRoute(routeKey) {
  const match = String(routeKey || "").match(/^\/leaderboards\/([^/?#]+)/i);
  return match ? decodeURIComponent(match[1]) : "";
}

function nativeSessionLeaderboardLink() {
  return Array.from(document.querySelectorAll('a[href*="/leaderboards/"]')).find((link) => {
    try {
      const url = new URL(link.href || link.getAttribute("href"), location.href);
      return url.origin === location.origin && /session\s+leaderboard/i.test(link.textContent || "");
    } catch {
      return false;
    }
  }) || null;
}

function yuniteMark() {
  const mark = document.createElement("span");
  mark.className = "np-yunite-mark";
  mark.setAttribute("aria-hidden", "true");
  const image = document.createElement("img");
  image.src = chrome.runtime.getURL("yunite-logo.png");
  image.alt = "";
  image.decoding = "async";
  mark.appendChild(image);
  return mark;
}

function makeYuniteLink(id, compact = false) {
  const link = document.createElement("a");
  link.className = `np-yunite-option${compact ? " is-compact" : ""}`;
  link.href = `https://yunite.xyz/leaderboard/${encodeURIComponent(id)}`;
  link.target = "_blank";
  link.rel = "noopener noreferrer";
  link.title = "Open this session on Yunite";
  link.setAttribute("aria-label", "Open Yunite leaderboard in a new tab");

  const label = document.createElement("span");
  label.className = "np-yunite-option-label";
  label.append(yuniteMark());
  const text = document.createElement("span");
  text.className = "np-yunite-option-text font-semibold text-sm";
  text.textContent = compact ? "Yunite LB" : "Yunite Leaderboard";
  label.append(text);
  link.append(label);

  const external = document.createElement("span");
  external.className = "np-yunite-option-external";
  external.setAttribute("aria-hidden", "true");
  external.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none">
      <path d="M14 3h7v7M10 14 21 3M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"
        stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>`;
  link.append(external);
  return link;
}

function ensureYuniteLeaderboardOptions() {
  const sessionSlot = document.getElementById(YUNITE_SESSION_SLOT_ID);
  const leaderboardSlot = document.getElementById(YUNITE_LEADERBOARD_SLOT_ID);
  const onLeaderboard = /^\/leaderboards\/[^/?#]+/i.test(location.pathname);

  if (onLeaderboard) {
    sessionSlot?.remove();
    const id = leaderboardIdFromRoute(location.pathname);
    if (!id) {
      leaderboardSlot?.remove();
      return;
    }

    const waypointLink = Array.from(document.querySelectorAll("a"))
      .find((link) => /waypoint\s+dropmap/i.test(link.textContent || ""));
    const heading = Array.from(document.querySelectorAll("h1"))
      .find((candidate) => (candidate.textContent || "").trim());
    const headingRow = heading?.parentElement?.parentElement || null;
    let slot = leaderboardSlot;

    if (!slot) {
      slot = document.createElement("span");
      slot.id = YUNITE_LEADERBOARD_SLOT_ID;
      slot.className = "np-yunite-leaderboard-slot";
      slot.append(makeYuniteLink(id, true));
    }
    const link = slot.querySelector(".np-yunite-option");
    if (link) link.href = `https://yunite.xyz/leaderboard/${encodeURIComponent(id)}`;

    if (waypointLink?.parentElement) {
      if (slot.parentElement !== waypointLink.parentElement) waypointLink.parentElement.appendChild(slot);
    } else if (headingRow && slot.previousElementSibling !== headingRow) {
      headingRow.insertAdjacentElement("afterend", slot);
    }
    return;
  }

  leaderboardSlot?.remove();
  const nativeLink = nativeSessionLeaderboardLink();
  const nativeContainer = nativeLink?.parentElement || null;
  const id = nativeLink
    ? leaderboardIdFromRoute(normalizeLeaderboardRoute(nativeLink.href || nativeLink.getAttribute("href")))
    : "";
  if (!nativeContainer || !id) {
    sessionSlot?.remove();
    return;
  }

  let slot = sessionSlot;
  if (!slot) {
    slot = document.createElement("div");
    slot.id = YUNITE_SESSION_SLOT_ID;
    slot.className = "np-yunite-session-slot";
    slot.append(makeYuniteLink(id));
  }
  const link = slot.querySelector(".np-yunite-option");
  if (link) {
    link.href = `https://yunite.xyz/leaderboard/${encodeURIComponent(id)}`;
    // Reuse Noble's own classes so width, height, hover, and transition remain
    // identical when Noble adjusts its layout.
    link.className = `${nativeLink.className} np-yunite-option`;
  }
  if (slot.previousElementSibling !== nativeContainer) nativeContainer.insertAdjacentElement("afterend", slot);
}

function currentMatchAttendanceEntry() {
  const entries = matchAttendanceCache?.entries;
  if (!entries || typeof entries !== "object") return null;
  const routeKey = sessionLeaderboardRouteKey();
  if (!routeKey) return null;
  const entry = entries[routeKey];
  return entry && typeof entry === "object" ? entry : null;
}

function loadMatchAttendanceCache() {
  if (matchAttendanceLoadPromise) return matchAttendanceLoadPromise;
  matchAttendanceLoadPromise = new Promise((resolve) => {
    try {
      chrome.storage.local.get([MATCH_ATTENDANCE_CACHE_KEY], (items) => {
        matchAttendanceCache = items?.[MATCH_ATTENDANCE_CACHE_KEY] || null;
        resolve(matchAttendanceCache);
      });
    } catch {
      matchAttendanceCache = null;
      resolve(null);
    }
  }).finally(() => {
    matchAttendanceLoadPromise = null;
  });
  return matchAttendanceLoadPromise;
}

async function refreshMatchAttendanceFromApi() {
  if (!npSettings.matchAttendance || !/^\/sessions\/[^/?#]+/i.test(location.pathname)) return null;
  const routeKey = sessionLeaderboardRouteKey();
  const leaderboardId = leaderboardIdFromRoute(routeKey);
  if (!routeKey || !leaderboardId) return null;
  const now = Date.now();
  if (
    matchAttendanceFetchPromise ||
    (matchAttendanceFetchRoute === routeKey && now - matchAttendanceFetchedAt < 60_000)
  ) return matchAttendanceFetchPromise;

  matchAttendanceFetchRoute = routeKey;
  matchAttendanceFetchedAt = now;
  matchAttendanceFetchPromise = (async () => {
    const response = await fetch(
      `https://tournament.nobleprac.com/api/tournament?id=${encodeURIComponent(leaderboardId)}`,
      { credentials: "omit", cache: "no-store" }
    );
    if (!response.ok) throw new Error(`Leaderboard request failed (${response.status})`);
    const payload = await response.json();
    const leaderboard = Array.isArray(payload?.leaderboard) ? payload.leaderboard : [];
    const players = {};
    let expectedMatches = 0;
    for (const team of leaderboard) {
      const registeredPlayer = Array.isArray(team?.players) ? team.players[0] : null;
      const name = String(registeredPlayer?.name || "").trim();
      const key = attendanceNameKey(name);
      const matches = Array.isArray(team?.games)
        ? team.games.length
        : Number.parseInt(team?.matches, 10);
      if (!key || !Number.isFinite(matches)) continue;
      expectedMatches = Math.max(expectedMatches, matches);
      players[key] = { name, matches };
    }
    if (!Object.keys(players).length) return null;

    const stored = await new Promise((resolve) => {
      chrome.storage.local.get([MATCH_ATTENDANCE_CACHE_KEY], (items) => resolve(items || {}));
    });
    const previousCache = stored[MATCH_ATTENDANCE_CACHE_KEY] &&
      typeof stored[MATCH_ATTENDANCE_CACHE_KEY] === "object"
      ? stored[MATCH_ATTENDANCE_CACHE_KEY]
      : {};
    const entries = previousCache.entries && typeof previousCache.entries === "object"
      ? { ...previousCache.entries }
      : {};
    entries[routeKey] = {
      updatedAt: Date.now(),
      expectedMatches,
      players
    };
    const orderedEntries = Object.fromEntries(
      Object.entries(entries)
        .sort(([, a], [, b]) => Number(b?.updatedAt || 0) - Number(a?.updatedAt || 0))
        .slice(0, 20)
    );
    matchAttendanceCache = {
      version: 1,
      latestKey: routeKey,
      entries: orderedEntries
    };
    await new Promise((resolve) => {
      chrome.storage.local.set({ [MATCH_ATTENDANCE_CACHE_KEY]: matchAttendanceCache }, resolve);
    });
    scheduleDecorate(0);
    return entries[routeKey];
  })().catch((error) => {
    console.warn("[Noble Toolkit] Match attendance refresh failed", error);
    return null;
  }).finally(() => {
    matchAttendanceFetchPromise = null;
  });
  return matchAttendanceFetchPromise;
}

function removeMatchAttendanceUi() {
  document.querySelectorAll(`.${SESSION_INCOMPLETE_DOT_CLASS}`).forEach((element) => element.remove());
}

function playerRecordByUserId(userId) {
  if (!userId) return null;
  return Array.from(state.byIgnNorm.values()).find((record) =>
    String(record?.userId || "").trim() === userId
  ) || null;
}

function sessionRowNameElement(row, record = null) {
  return Array.from(row.querySelectorAll("span")).find((element) => {
    if (element.closest(`.${HOST_BADGE_CLASS}, .${WRAP_CLASS}`)) return false;
    const text = (element.textContent || "").replace(/\s+/g, " ").trim();
    if (record?.ign && norm(text) === norm(record.ign)) return true;
    return !record && text.length >= 2 && text.length <= 64 && !/^\d+$/.test(text) &&
      text.toLowerCase() !== "host ready";
  }) || null;
}

function decorateSessionMatchAttendance(panel) {
  if (!npSettings.matchAttendance || !panel) {
    removeMatchAttendanceUi();
    return;
  }
  void refreshMatchAttendanceFromApi();
  const entry = currentMatchAttendanceEntry();
  const expectedMatches = Number(entry?.expectedMatches || 0);
  const players = entry?.players;
  if (!expectedMatches || !players || typeof players !== "object") {
    removeMatchAttendanceUi();
    return;
  }

  const liveDots = new Set();
  for (const row of panel.querySelectorAll(PLAYER_LIST_ROW_SELECTOR)) {
    const userId = String(row.getAttribute("userid") || "").trim();
    const record = playerRecordByUserId(userId);
    const nameElement = sessionRowNameElement(row, record);
    const displayName = record?.ign || (nameElement?.textContent || "").trim();
    const attendance = players[attendanceNameKey(displayName)];
    const matches = Number(attendance?.matches);
    let dot = row.querySelector(`.${SESSION_INCOMPLETE_DOT_CLASS}`);
    if (!nameElement || !Number.isFinite(matches) || matches >= expectedMatches) {
      dot?.remove();
      continue;
    }
    if (!dot) {
      dot = document.createElement("span");
      dot.className = SESSION_INCOMPLETE_DOT_CLASS;
      nameElement.insertAdjacentElement("afterend", dot);
    }
    liveDots.add(dot);
    dot.setAttribute("role", "img");
    dot.setAttribute("aria-label", `Played ${matches} of ${expectedMatches} games`);
    dot.title = `Missed games · played ${matches} of ${expectedMatches}`;
  }
  document.querySelectorAll(`.${SESSION_INCOMPLETE_DOT_CLASS}`).forEach((dot) => {
    if (!liveDots.has(dot)) dot.remove();
  });
}

function normalizeEpicAccountId(value) {
  const clean = String(value || "").trim().toLowerCase();
  return /^[0-9a-f]{32}$/.test(clean) ? clean : "";
}

function sanitizeMapFilterModes(value) {
  const candidates = Array.isArray(value)
    ? value
    : Array.isArray(value?.modes)
      ? value.modes
      : [typeof value === "string" ? value : value?.mode];
  return new Set(candidates.filter((candidate) => MAP_FILTER_KEYS.includes(candidate)));
}

function loadMapFilterModes() {
  try {
    chrome.storage.local.get([MAP_FILTER_STORAGE_KEY, MAP_FILTER_LEGACY_STORAGE_KEY], (items) => {
      const stored = items?.[MAP_FILTER_STORAGE_KEY] ?? items?.[MAP_FILTER_LEGACY_STORAGE_KEY];
      mapFilterModes = sanitizeMapFilterModes(stored);
      scheduleMapLayerSync(0);
    });
  } catch {
    scheduleMapLayerSync(0);
  }
}

function saveMapFilterModes() {
  try {
    chrome.storage.local.set({
      [MAP_FILTER_STORAGE_KEY]: { modes: Array.from(mapFilterModes) }
    });
  } catch {}
}

function ensureSiteCredit() {
  let credit = document.getElementById(SITE_CREDIT_ID);
  if (credit) return credit;
  credit = document.createElement("div");
  credit.id = SITE_CREDIT_ID;
  const madeWith = document.createElement("span");
  madeWith.textContent = "Made with Noble Toolkit by Sneeky";
  const separator = document.createElement("span");
  separator.className = "np-toolkit-credit-separator";
  separator.textContent = "·";
  separator.setAttribute("aria-hidden", "true");
  const helperLink = document.createElement("a");
  helperLink.href = "https://sneeky1876-cmyk.github.io/noble-staff-helper/#builder";
  helperLink.target = "_blank";
  helperLink.rel = "noopener noreferrer";
  helperLink.textContent = "Announce sessions with Noble Staff Helper ↗";
  credit.append(madeWith, separator, helperLink);
  document.body?.appendChild(credit);
  return credit;
}

function visibleSessionMap() {
  return Array.from(document.querySelectorAll(".leaflet-container, [class*='leaflet-container']"))
    .filter((element) => {
      const rect = element.getBoundingClientRect();
      const style = getComputedStyle(element);
      return rect.width >= 280 && rect.height >= 240 && style.display !== "none" && style.visibility !== "hidden";
    })
    .sort((a, b) => {
      const aRect = a.getBoundingClientRect();
      const bRect = b.getBoundingClientRect();
      return bRect.width * bRect.height - aRect.width * aRect.height;
    })[0] || null;
}

function positionMapCornerTools(tools, mapElement) {
  const rect = mapElement.getBoundingClientRect();
  const offscreen =
    rect.bottom <= 0 ||
    rect.top >= window.innerHeight ||
    rect.right <= 0 ||
    rect.left >= window.innerWidth;
  tools.classList.toggle("np-map-tools-offscreen", offscreen);
  tools.style.setProperty(
    "--np-map-tools-right",
    `${Math.max(MAP_CORNER_INSET_PX, window.innerWidth - rect.right + MAP_CORNER_INSET_PX)}px`
  );
  tools.style.setProperty(
    "--np-map-tools-bottom",
    `${Math.max(MAP_CORNER_INSET_PX, window.innerHeight - rect.bottom + MAP_CORNER_INSET_PX)}px`
  );
}

function ensureMapCornerTools(mapElement) {
  let tools = document.getElementById(MAP_CORNER_TOOLS_ID);
  if (!tools) {
    tools = document.createElement("div");
    tools.id = MAP_CORNER_TOOLS_ID;
    tools.className = "leaflet-control np-map-corner-tools";
    document.body?.appendChild(tools);
  } else if (tools.parentElement !== document.body) {
    // Keep these controls outside Leaflet's hit-testing tree. Noble's map
    // interaction canvas can otherwise intercept pointer events until scroll
    // causes a stacking-context refresh.
    document.body?.appendChild(tools);
  }
  positionMapCornerTools(tools, mapElement);
  return tools;
}

function scheduleMapCornerPosition() {
  if (mapCornerPositionFrame !== null) return;
  mapCornerPositionFrame = requestAnimationFrame(() => {
    mapCornerPositionFrame = null;
    const tools = document.getElementById(MAP_CORNER_TOOLS_ID);
    if (!tools) return;
    const mapElement = visibleSessionMap();
    if (!mapElement) {
      tools.classList.add("np-map-tools-offscreen");
      return;
    }
    positionMapCornerTools(tools, mapElement);
  });
}

const MAP_LAYER_OPTIONS = Object.freeze([
  { key: "all", label: "All players" },
  { key: "hosts", label: "Hosts" },
  { key: "noDrops", label: "Players without drops" },
  { key: "contested", label: "Contested drops" }
]);

function layersIcon() {
  return `
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="m12 4-8 4 8 4 8-4-8-4Z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/>
      <path d="m5 12 7 3.5 7-3.5M5 16l7 3.5 7-3.5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  `;
}

function makeMapLayersPanel() {
  const panel = document.createElement("div");
  panel.id = MAP_LAYERS_PANEL_ID;
  panel.className = "np-map-layers-panel";
  panel.hidden = true;
  panel.setAttribute("role", "group");
  panel.setAttribute("aria-label", "Player filters");

  const heading = document.createElement("div");
  heading.className = "np-map-layers-heading";
  heading.textContent = "Show on map & player list";
  panel.appendChild(heading);

  const hint = document.createElement("div");
  hint.className = "np-map-layers-hint";
  hint.textContent = "Combine filters to narrow results";
  panel.appendChild(hint);

  for (const option of MAP_LAYER_OPTIONS) {
    const label = document.createElement("label");
    label.className = "np-map-layer-row";
    const copy = document.createElement("span");
    copy.className = "np-map-layer-label";
    copy.textContent = option.label;
    const count = document.createElement("span");
    count.className = "np-map-layer-count";
    count.dataset.npLayerCount = option.key;
    const input = document.createElement("input");
    input.type = "checkbox";
    input.value = option.key;
    input.dataset.npMapLayer = option.key;
    input.checked = option.key === "all" ? mapFilterModes.size === 0 : mapFilterModes.has(option.key);
    const toggle = document.createElement("i");
    toggle.setAttribute("aria-hidden", "true");
    label.append(copy, count, input, toggle);
    panel.appendChild(label);
  }

  panel.addEventListener("change", (event) => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement)) return;
    const key = input.dataset.npMapLayer;
    if (!key) return;
    if (key === "all") {
      mapFilterModes.clear();
    } else if (MAP_FILTER_KEYS.includes(key)) {
      if (input.checked) mapFilterModes.add(key);
      else mapFilterModes.delete(key);
    } else {
      return;
    }
    saveMapFilterModes();
    scheduleMapLayerSync(0);
  });
  panel.addEventListener("pointerdown", (event) => event.stopPropagation());
  return panel;
}

function ensureMapLayersControl(mapElement) {
  const tools = ensureMapCornerTools(mapElement);
  if (!tools) return null;
  let button = document.getElementById(MAP_LAYERS_BUTTON_ID);
  if (!button) {
    button = document.createElement("button");
    button.id = MAP_LAYERS_BUTTON_ID;
    button.type = "button";
    button.className = "np-map-round-button np-map-layers-button";
    button.innerHTML = layersIcon();
    button.title = "Filter players";
    button.setAttribute("aria-label", "Filter players");
    button.setAttribute("aria-expanded", "false");
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const panel = document.getElementById(MAP_LAYERS_PANEL_ID);
      if (!panel) return;
      const open = panel.hidden;
      panel.hidden = !open;
      button.classList.toggle("is-active", open);
      button.setAttribute("aria-expanded", String(open));
    });
    tools.prepend(button);
  } else if (button.parentElement !== tools) {
    tools.prepend(button);
  }

  let panel = document.getElementById(MAP_LAYERS_PANEL_ID);
  if (!panel) {
    panel = makeMapLayersPanel();
    tools.appendChild(panel);
  } else if (panel.parentElement !== tools) {
    tools.appendChild(panel);
  }
  return panel;
}

function markerUserId(marker) {
  return String(marker.querySelector("[user-id]")?.getAttribute("user-id") || "").trim();
}

function dropKey(value) {
  if (!Array.isArray(value) || !value.length) return "";
  try {
    return JSON.stringify(value);
  } catch {
    return "";
  }
}

function contestedDropState() {
  const counts = new Map();
  for (const key of state.dropKeyByUserId.values()) {
    if (key) counts.set(key, (counts.get(key) || 0) + 1);
  }
  const keys = new Set(Array.from(counts).filter(([, count]) => count > 1).map(([key]) => key));
  const userIds = new Set(
    Array.from(state.dropKeyByUserId)
      .filter(([, key]) => keys.has(key))
      .map(([userId]) => userId)
  );
  return { keys, userIds };
}

function noDropRecords() {
  const records = [];
  const seen = new Set();
  for (const record of state.byIgnNorm.values()) {
    const userId = String(record?.userId || "").trim();
    if (!userId || seen.has(userId) || state.dropKeyByUserId.has(userId) || state.markedUserIds.has(userId)) continue;
    if (state.rosterUserIds.size && !state.rosterUserIds.has(userId)) continue;
    seen.add(userId);
    records.push(record);
  }
  return records.sort((a, b) => String(a.ign).localeCompare(String(b.ign)));
}

function syncNoDropLayer(mapElement, records) {
  let layer = document.getElementById(MAP_NO_DROP_LAYER_ID);
  if (!mapFilterModes.has("noDrops") || !records.length) {
    layer?.remove();
    return;
  }
  const corner = mapElement.querySelector(".leaflet-control-container .leaflet-bottom.leaflet-left");
  if (!corner) return;
  if (!layer) {
    layer = document.createElement("div");
    layer.id = MAP_NO_DROP_LAYER_ID;
    layer.className = "leaflet-control np-map-no-drop-layer";
    const icon = document.createElement("span");
    icon.className = "np-map-no-drop-icon";
    icon.innerHTML = `
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" stroke="currentColor" stroke-width="1.8"/>
        <path d="m8 8 8 8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>
      </svg>
    `;
    const text = document.createElement("span");
    text.className = "np-map-no-drop-text";
    layer.append(icon, text);
    corner.appendChild(layer);
  }
  const label = `${records.length} without drops`;
  const text = layer.querySelector(".np-map-no-drop-text");
  if (text.textContent !== label) text.textContent = label;
  const title = records.slice(0, 20).map((record) => record.ign).join(", ") +
    (records.length > 20 ? ` +${records.length - 20} more` : "");
  if (layer.title !== title) layer.title = title;
}

function syncMapLayerCounts(panel, counts) {
  const isFiltering = mapFilterModes.size > 0;
  for (const [key, value] of Object.entries(counts)) {
    const count = panel.querySelector(`[data-np-layer-count="${key}"]`);
    const label = Number(value || 0).toLocaleString("en-US");
    if (count && count.textContent !== label) count.textContent = label;
    const input = panel.querySelector(`[data-np-map-layer="${key}"]`);
    if (input instanceof HTMLInputElement) {
      input.checked = key === "all" ? !isFiltering : mapFilterModes.has(key);
    }
  }
  const button = document.getElementById(MAP_LAYERS_BUTTON_ID);
  button?.classList.toggle("has-filters", isFiltering);
  const activeCount = mapFilterModes.size;
  const label = activeCount
    ? `Filter players, ${activeCount} active`
    : "Filter players";
  if (button) {
    button.title = label;
    button.setAttribute("aria-label", label);
  }
}

function syncDropCanvasFilter(visibleKeys) {
  if (!globalThis.__NP_HELPER_CHANNEL__) return;
  window.postMessage({
    __NP_TOOLKIT_COMMAND__: true,
    channel: globalThis.__NP_HELPER_CHANNEL__,
    type: "NP_MAP_DROP_FILTER",
    visibleKeys: visibleKeys === null ? null : Array.from(visibleKeys)
  }, location.origin);
}

function hostReadyUserIds(markers) {
  const ids = new Set();
  for (const marker of markers) {
    const userId = markerUserId(marker);
    if (userId && marker.querySelector(`.${HOST_MAP_NAME_CLASS}`)) ids.add(userId);
  }
  const panel = findPlayersPanelRoot();
  for (const row of panel?.querySelectorAll(PLAYER_LIST_ROW_SELECTOR) || []) {
    const userId = String(row.getAttribute("userid") || "").trim();
    if (
      userId &&
      (row.getAttribute("data-np-host-ready") === "true" || row.querySelector(`.${HOST_INDICATOR_CLASS}`))
    ) ids.add(userId);
  }
  return ids;
}

function dropKeysForUsers(userIds) {
  const keys = new Set();
  for (const userId of userIds) {
    const key = state.dropKeyByUserId.get(userId);
    if (key) keys.add(key);
  }
  return keys;
}

function syncPlayerListFilter(activeUserIds) {
  const panel = findPlayersPanelRoot();
  if (!panel) return;
  const isFiltering = mapFilterModes.size > 0;
  for (const row of panel.querySelectorAll(PLAYER_LIST_ROW_SELECTOR)) {
    const userId = String(row.getAttribute("userid") || "").trim();
    const visible = !isFiltering || activeUserIds.has(userId);
    row.classList.toggle("np-player-layer-hidden", !visible);
  }
}

function clearPlayerListFilter() {
  document.querySelectorAll(".np-player-layer-hidden").forEach((row) =>
    row.classList.remove("np-player-layer-hidden")
  );
}

function syncMapLayers() {
  ensureSiteCredit();
  if (!/^\/sessions\/[^/?#]+/i.test(location.pathname)) {
    document.getElementById(MAP_LAYERS_BUTTON_ID)?.remove();
    document.getElementById(MAP_LAYERS_PANEL_ID)?.remove();
    document.getElementById(MAP_NO_DROP_LAYER_ID)?.remove();
    clearPlayerListFilter();
    syncDropCanvasFilter(null);
    return;
  }
  const mapElement = visibleSessionMap();
  if (!mapElement) return;
  const panel = ensureMapLayersControl(mapElement);
  if (!panel) return;

  const markers = Array.from(mapElement.querySelectorAll(".leaflet-marker-pane .leaflet-marker-icon"))
    .filter((marker) => markerUserId(marker));
  const contested = contestedDropState();
  const hostIds = hostReadyUserIds(markers);
  const withoutDrops = noDropRecords();
  const noDropIds = new Set(withoutDrops.map((record) => String(record.userId || "").trim()).filter(Boolean));
  const allIds = new Set([
    ...state.rosterUserIds,
    ...Array.from(markers, markerUserId)
  ]);
  const activeIdsByMode = {
    hosts: hostIds,
    noDrops: noDropIds,
    contested: contested.userIds
  };
  let activeUserIds = new Set(allIds);
  for (const key of mapFilterModes) {
    const matchingIds = activeIdsByMode[key];
    if (!matchingIds) continue;
    activeUserIds = new Set(Array.from(activeUserIds).filter((userId) => matchingIds.has(userId)));
  }
  const isFiltering = mapFilterModes.size > 0;

  for (const marker of markers) {
    const userId = markerUserId(marker);
    const isHost = hostIds.has(userId);
    marker.dataset.npMapHost = String(isHost);
    marker.dataset.npMapContested = String(contested.userIds.has(userId));
    const visible = !isFiltering || activeUserIds.has(userId);
    marker.classList.toggle("np-map-layer-hidden", !visible);
  }

  syncPlayerListFilter(activeUserIds);
  const visibleNoDropRecords = mapFilterModes.has("noDrops")
    ? withoutDrops.filter((record) => activeUserIds.has(String(record.userId || "").trim()))
    : withoutDrops;
  syncNoDropLayer(mapElement, visibleNoDropRecords);
  const visibleDropKeys = !isFiltering
    ? null
    : mapFilterModes.has("noDrops")
      ? new Set()
      : dropKeysForUsers(activeUserIds);
  syncDropCanvasFilter(visibleDropKeys);
  syncMapLayerCounts(panel, {
    all: allIds.size || markers.length,
    hosts: hostIds.size,
    noDrops: withoutDrops.length,
    contested: contested.keys.size
  });
}

function scheduleMapLayerSync(delay = 65) {
  clearTimeout(mapLayerSyncTimer);
  mapLayerSyncTimer = setTimeout(syncMapLayers, delay);
}

window.addEventListener("resize", () => {
  scheduleMapCornerPosition();
  scheduleMapLayerSync(30);
}, { passive: true });
window.addEventListener("scroll", scheduleMapCornerPosition, { passive: true });

document.addEventListener("pointerdown", (event) => {
  const panel = document.getElementById(MAP_LAYERS_PANEL_ID);
  const button = document.getElementById(MAP_LAYERS_BUTTON_ID);
  if (
    !panel ||
    panel.hidden ||
    (event.target instanceof Node && (panel.contains(event.target) || button?.contains(event.target)))
  ) return;
  panel.hidden = true;
  button?.classList.remove("is-active");
  button?.setAttribute("aria-expanded", "false");
}, true);

document.addEventListener("keydown", (event) => {
  if (event.key !== "Escape") return;
  const panel = document.getElementById(MAP_LAYERS_PANEL_ID);
  if (!panel || panel.hidden) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  panel.hidden = true;
  const button = document.getElementById(MAP_LAYERS_BUTTON_ID);
  button?.classList.remove("is-active");
  button?.setAttribute("aria-expanded", "false");
  button?.focus({ preventScroll: true });
}, true);

function findEpicAccountId(team) {
  if (!team || typeof team !== "object") return "";
  const candidates = [
    team.epicAccountId,
    team.epicAccountID,
    team.epicId,
    team.accountId,
    team.accountID,
    team.epic?.accountId,
    team.epic?.id,
    team.account?.accountId,
    team.account?.id,
    team.profile?.accountId,
    team.fortnite?.accountId
  ];
  for (const candidate of candidates) {
    const accountId = normalizeEpicAccountId(candidate);
    if (accountId) return accountId;
  }
  return "";
}

function ensureCreatorProgress() {
  let progress = document.getElementById(CREATOR_PROGRESS_ID);
  if (progress) return progress;

  progress = document.createElement("div");
  progress.id = CREATOR_PROGRESS_ID;
  progress.setAttribute("role", "status");
  progress.setAttribute("aria-live", "polite");
  progress.setAttribute("aria-hidden", "true");
  progress.innerHTML = `
    <span class="np-creator-progress-spinner" aria-hidden="true"></span>
    <span class="np-creator-progress-label">Checking host status</span>
    <span class="np-creator-progress-count"></span>
    <span class="np-creator-progress-track" aria-hidden="true"><span></span></span>
  `;
  (document.body || document.documentElement).appendChild(progress);
  return progress;
}

function hideCreatorProgress(immediate = false) {
  clearTimeout(creatorProgressHideTimer);
  clearTimeout(creatorProgressSettleTimer);
  creatorProgressHideTimer = null;
  creatorProgressSettleTimer = null;
  clearTimeout(creatorScanWatchdogTimer);
  creatorScanWatchdogTimer = null;
  creatorBatchRunning = false;
  if (immediate) {
    creatorScanRequested = false;
    creatorScanPreparing = false;
  }
  if (!creatorScanRequested) creatorBatchKeys.clear();
  const progress = document.getElementById(CREATOR_PROGRESS_ID);
  if (!progress) return;
  progress.classList.remove("is-visible", "is-done");
  progress.setAttribute("aria-hidden", "true");
  if (immediate) progress.remove();
}

function creatorBatchSummary() {
  let completed = 0;
  let ready = 0;
  let failed = 0;
  for (const key of creatorBatchKeys) {
    const item = creatorStates.get(key);
    if (item?.status === "done" || item?.status === "error") completed++;
    if (item?.status === "done" && item.hasCreatorCode && item.verified) ready++;
    if (item?.status === "error") failed++;
  }
  return {
    completed,
    ready,
    failed,
    total: creatorBatchKeys.size
  };
}

function updateCreatorProgress() {
  if (!npSettings.creatorCodes || !creatorBatchRunning || !creatorBatchKeys.size) {
    hideCreatorProgress();
    return;
  }

  const { completed, ready, failed, total } = creatorBatchSummary();
  const pending = Math.max(0, total - completed);
  const progress = ensureCreatorProgress();
  const label = progress.querySelector(".np-creator-progress-label");
  const count = progress.querySelector(".np-creator-progress-count");
  const fill = progress.querySelector(".np-creator-progress-track > span");
  clearTimeout(creatorProgressHideTimer);
  creatorProgressHideTimer = null;

  progress.classList.add("is-visible");
  progress.classList.remove("is-done");
  progress.setAttribute("aria-hidden", "false");
  const progressLabel = pending
    ? ready ? `Checking hosts · ${ready} found` : "Checking host status"
    : "Finishing host check";
  const progressCount = `${completed}/${total}`;
  const progressWidth = `${Math.round((completed / total) * 100)}%`;
  if (label.textContent !== progressLabel) label.textContent = progressLabel;
  if (count.textContent !== progressCount) count.textContent = progressCount;
  if (fill.style.width !== progressWidth) fill.style.width = progressWidth;

  if (pending) {
    clearTimeout(creatorProgressSettleTimer);
    creatorProgressSettleTimer = null;
    return;
  }

  // Noble can append the last member rows just after the current queue empties.
  // Wait for a quiet window so the indicator cannot announce completion and
  // disappear while a second wave of players is still being discovered.
  if (!creatorProgressSettleTimer) {
    creatorProgressSettleTimer = setTimeout(() => {
      creatorProgressSettleTimer = null;
      if (!creatorBatchRunning) return;
      const stillPending = [...creatorBatchKeys].some((key) => {
        const item = creatorStates.get(key);
        return item && item.status !== "done" && item.status !== "error";
      });
      if (stillPending) {
        updateCreatorProgress();
        return;
      }

      const summary = creatorBatchSummary();
      const doneProgress = document.getElementById(CREATOR_PROGRESS_ID);
      if (!doneProgress) {
        creatorScanRequested = false;
        creatorBatchRunning = false;
        creatorScanCompleted = true;
        clearTimeout(creatorScanWatchdogTimer);
        creatorScanWatchdogTimer = null;
        updateHostScanButton();
        return;
      }
      doneProgress.classList.add("is-done");
      const doneLabel = summary.ready
          ? `${summary.ready} host${summary.ready === 1 ? "" : "s"} ready`
          : summary.failed === summary.total
            ? "Host service unavailable"
            : "Host check complete";
      const doneLabelElement = doneProgress.querySelector(".np-creator-progress-label");
      const doneCountElement = doneProgress.querySelector(".np-creator-progress-count");
      if (doneLabelElement.textContent !== doneLabel) doneLabelElement.textContent = doneLabel;
      if (doneCountElement.textContent) doneCountElement.textContent = "";
      creatorScanRequested = false;
      creatorScanCompleted = true;
      clearTimeout(creatorScanWatchdogTimer);
      creatorScanWatchdogTimer = null;
      updateHostScanButton();
      creatorProgressHideTimer = setTimeout(() => hideCreatorProgress(), 900);
    }, CREATOR_PROGRESS_SETTLE_MS);
  }
}

function addCreatorProgressKey(key) {
  if (creatorBatchRunning && creatorBatchKeys.has(key)) return;
  if (!creatorBatchRunning) {
    creatorBatchKeys.clear();
    creatorBatchRunning = true;
  }
  clearTimeout(creatorProgressHideTimer);
  clearTimeout(creatorProgressSettleTimer);
  creatorProgressHideTimer = null;
  creatorProgressSettleTimer = null;
  creatorBatchKeys.add(key);
  updateCreatorProgress();
}


// For leaderboard tools we also persist an ID cache to chrome.storage.local.
// We store multiple normalized keys per name to make matching very tolerant.
function npNormalizeName(raw) {
  const s = String(raw || "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "") // invisibles
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();

  // keep unicode letters/numbers/spaces
  const normKey = s.replace(/[^\p{L}\p{N}\s]+/gu, "").replace(/\s+/g, " ").trim();

  // remove spaces too
  const looseKey = normKey.replace(/\s+/g, "");

  return { normKey, looseKey };
}

function creatorKey(name) {
  return npNormalizeName(name).normKey;
}

function loadSavedCreatorHosts() {
  return new Promise((resolve) => {
    try {
      chrome.storage.local.get(CREATOR_CACHE_KEYS, (items) => {
        const cache = items?.[CREATOR_CACHE_KEYS[0]] || items?.[CREATOR_CACHE_KEYS[1]] || {};
        const now = Date.now();
        for (const [storageKey, entry] of Object.entries(cache)) {
          if (
            !entry?.hasCreatorCode ||
            !entry?.verified ||
            !entry?.code ||
            now - Number(entry.checkedAt || 0) > CREATOR_CACHE_DISPLAY_TTL
          ) {
            continue;
          }

          const savedName = storageKey.startsWith("name:")
            ? storageKey.slice(5)
            : entry.accountName;
          const key = creatorKey(savedName || entry.accountName);
          if (!key) continue;
          creatorStates.set(key, {
            status: "done",
            hasCreatorCode: true,
            code: entry.code,
            accountName: entry.accountName || savedName,
            accountId: normalizeEpicAccountId(entry.accountId),
            verified: true,
            source: entry.source || "local-cache",
            checkedAt: Number(entry.checkedAt || 0),
            cached: true
          });
        }
        resolve();
      });
    } catch {
      resolve();
    }
  });
}

function sendCreatorLookup(displayName, epicAccountId = "") {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(value);
    };
    const timer = setTimeout(() => finish({ ok: false, error: "Host service timed out" }), 20_000);

    try {
      chrome.runtime.sendMessage({
        type: "NP_CREATOR_CODE_LOOKUP",
        displayName,
        epicAccountId: normalizeEpicAccountId(epicAccountId)
      }, (response) => {
        const error = chrome.runtime.lastError;
        if (error) finish({ ok: false, error: error.message });
        else finish(response || { ok: false, error: "No creator lookup response" });
      });
    } catch (error) {
      finish({ ok: false, error: error?.message || "Creator lookup failed" });
    }
  });
}

function scheduleCreatorDecorate() {
  clearTimeout(creatorDecorateTimer);
  creatorDecorateTimer = setTimeout(decorateAll, 35);
}

function drainCreatorQueue() {
  const generation = creatorLookupGeneration;
  let active = creatorActiveByGeneration.get(generation) || 0;
  while (active < CREATOR_CONCURRENCY && creatorQueue.length) {
    const item = creatorQueue.shift();
    const current = creatorStates.get(item.key);
    if (!current || current.status !== "queued" || current.generation !== item.generation) continue;

    active++;
    creatorActiveByGeneration.set(item.generation, active);
    creatorStates.set(item.key, {
      status: "checking",
      requestedEpicId: item.epicAccountId || "",
      generation: item.generation
    });
    updateCreatorProgress();
    sendCreatorLookup(item.displayName, item.epicAccountId)
      .then((result) => {
        if (item.generation !== creatorLookupGeneration) return;
        if (result?.ok) {
          creatorStates.set(item.key, {
            status: "done",
            hasCreatorCode: Boolean(result.hasCreatorCode),
            code: result.code || "",
            accountName: result.accountName || item.displayName,
            accountId: normalizeEpicAccountId(result.accountId),
            verified: Boolean(result.verified),
            source: result.source || "",
            checkedAt: Number(result.checkedAt || Date.now()),
            cached: Boolean(result.cached),
            generation: item.generation
          });
        } else {
          creatorStates.set(item.key, {
            status: "error",
            retryAt: Date.now() + 10 * 60 * 1000,
            error: result?.error || "Creator lookup failed",
            requestedEpicId: item.epicAccountId || "",
            generation: item.generation
          });
        }
      })
      .finally(() => {
        const remaining = Math.max(0, (creatorActiveByGeneration.get(item.generation) || 1) - 1);
        if (remaining) creatorActiveByGeneration.set(item.generation, remaining);
        else creatorActiveByGeneration.delete(item.generation);
        if (item.generation !== creatorLookupGeneration) {
          drainCreatorQueue();
          return;
        }
        updateCreatorProgress();
        scheduleCreatorDecorate();
        setTimeout(drainCreatorQueue, 25);
      });
  }
}

function queueCreatorLookup(record, { manual = false } = {}) {
  if (!npSettings.creatorCodes || !record?.ign || (!manual && !creatorScanRequested)) return;
  const key = creatorKey(record.ign);
  const epicAccountId = normalizeEpicAccountId(record.epicAccountId);
  if (!key) return;
  const current = creatorStates.get(key);
  if (
    current &&
    ["queued", "checking"].includes(current.status) &&
    current.generation === creatorLookupGeneration
  ) {
    if (epicAccountId && !current.requestedEpicId) {
      current.requestedEpicId = epicAccountId;
      const queued = creatorQueue.find((item) => item.key === key);
      if (queued) queued.epicAccountId = epicAccountId;
    }
    return;
  }
  if (
    !manual &&
    current?.status === "done" &&
    (!epicAccountId || current.accountId === epicAccountId)
  ) {
    addCreatorProgressKey(key);
    return;
  }
  const hasBetterId = epicAccountId && current?.requestedEpicId !== epicAccountId;
  if (!manual && current?.retryAt && current.retryAt > Date.now() && !hasBetterId) return;

  creatorStates.set(key, {
    status: "queued",
    requestedEpicId: epicAccountId,
    generation: creatorLookupGeneration
  });
  creatorQueue.push({
    key,
    displayName: record.ign,
    epicAccountId,
    generation: creatorLookupGeneration
  });
  addCreatorProgressKey(key);
  drainCreatorQueue();
}

loadSavedCreatorHosts().then(scheduleCreatorDecorate).catch(() => {});

let __npPersistTimer = null;
function npPersistIdCacheSoon() {
  clearTimeout(__npPersistTimer);
  __npPersistTimer = setTimeout(npPersistIdCacheNow, 400);
}

function npPersistIdCacheNow() {
  try {
    if (!chrome?.storage?.local) return;

    const additions = {};
    for (const rec of state.byIgnNorm.values()) {
      if (!rec?.ign || !rec?.userId) continue;
      const { normKey, looseKey } = npNormalizeName(rec.ign);

      // store a few variants so the leaderboard scripts can resolve aggressively
      const plain = norm(rec.ign);

      if (normKey) additions[normKey] = rec.userId;
      if (looseKey) additions[looseKey] = rec.userId;
      if (plain) additions[plain] = rec.userId;
    }

    // Merge instead of replacing the cache. Replacing it made leaderboard IDs
    // disappear whenever the user opened a different session map.
    chrome.storage.local.get(["np_id_cache_v1"], (items) => {
      const merged = { ...(items?.np_id_cache_v1 || {}) };
      for (const [key, value] of Object.entries(additions)) {
        delete merged[key];
        merged[key] = value;
      }

      // Keep local storage bounded while retaining the most recently seen keys.
      const keys = Object.keys(merged);
      for (const key of keys.slice(0, Math.max(0, keys.length - 6000))) delete merged[key];

      chrome.storage.local.set({
        np_id_cache_v1: merged,
        np_id_cache_updated_at: Date.now()
      });
    });
  } catch (e) {
    console.warn("[NP] Failed to persist ID cache", e);
  }
}

function cacheTeams(teams) {
  let added = 0;
  const rosterUserIds = new Set();
  const markedUserIds = new Set();
  let hasMarkingData = false;
  for (const t of teams) {
    if (!t) continue;
    const ign = (t.username || "").trim();
    const userId = t.userId != null ? String(t.userId) : null;
    if (!ign || !userId) continue;
    rosterUserIds.add(userId);

    const markCandidates = [
      t.coordinates,
      t.coordinate,
      t.dropCoordinates,
      t.drop,
      t.location,
      t.position
    ];
    if (markCandidates.some((value) => value !== undefined && value !== null)) {
      hasMarkingData = true;
      const isMarked = markCandidates.some((value) => {
        if (Array.isArray(value)) return value.length >= 2;
        if (value && typeof value === "object") return Object.keys(value).length > 0;
        return Boolean(value);
      });
      if (isMarked) markedUserIds.add(userId);
    }
    const coordinatesKey = dropKey(t.coordinates);
    if (coordinatesKey) state.dropKeyByUserId.set(userId, coordinatesKey);
    else state.dropKeyByUserId.delete(userId);
    const key = norm(ign);
    const previous = state.byIgnNorm.get(key);
    if (!previous) added++;

    const record = {
      ign,
      userId,
      profilePicture: t.profilePicture || t.profilePic || previous?.profilePicture || null,
      epicAccountId: findEpicAccountId(t) || previous?.epicAccountId || ""
    };
    state.byIgnNorm.set(key, record);
    queueCreatorLookup(record);
  }
  if (rosterUserIds.size) state.rosterUserIds = rosterUserIds;
  if (hasMarkingData) state.markedUserIds = markedUserIds;
  state.ready = state.byIgnNorm.size > 0;
  console.log(`[NP ShadowPopover] cached IGNs=${state.byIgnNorm.size} (+${added})`);

  // persist cache for leaderboard tools
  npPersistIdCacheSoon();
  scheduleMapLayerSync();
}

function cacheSessionMapPayload(payload) {
  const p = payload && typeof payload === "object" ? payload : {};
  const event = String(p.event || "").toLowerCase();
  const teams = p.teams || p.data?.teams || p.payload?.teams;
  if (Array.isArray(teams) && teams.length) cacheTeams(teams);

  const userId = String(p.userId || p.playerId || p.data?.userId || p.data?.playerId || "").trim();
  const coordinates = p.coordinates || p.data?.coordinates;
  if (event === "add-team" && userId) {
    state.rosterUserIds.add(userId);
    state.dropKeyByUserId.delete(userId);
    const ign = String(p.username || p.data?.username || "").trim();
    if (ign) {
      state.byIgnNorm.set(norm(ign), {
        ign,
        userId,
        profilePicture: p.profilePicture || p.data?.profilePicture || null,
        epicAccountId: ""
      });
      state.ready = true;
    }
  } else if (event === "drop-claimed" && userId) {
    const key = dropKey(coordinates);
    if (key) {
      state.dropKeyByUserId.set(userId, key);
      state.markedUserIds.add(userId);
    }
  } else if (["drop-unclaimed", "remove-team"].includes(event) && userId) {
    state.dropKeyByUserId.delete(userId);
    state.markedUserIds.delete(userId);
    if (event === "remove-team") state.rosterUserIds.delete(userId);
  }
  scheduleMapLayerSync();
}

// The initial socket payload can arrive before this document-idle script is
// listening. Noble renders the same Epic name and Discord user ID on each
// member row, so use that DOM as a reliable second source for every feature
// that needs the name-to-ID cache.
function cacheVisibleMemberRows(panel) {
  if (!panel) return 0;
  let changed = 0;
  const rows = Array.from(panel.querySelectorAll(PLAYER_LIST_ROW_SELECTOR));

  for (const row of rows) {
    const userId = String(row.getAttribute("userid") || "").trim();
    if (!/^\d{8,24}$/.test(userId)) continue;
    state.rosterUserIds.add(userId);

    const identity = Array.from(row.children || []).find((child) => child.querySelector?.("img") && child.querySelector?.("span"));
    const scope = identity || row;
    const nameElement = Array.from(scope.querySelectorAll("span")).find((element) => {
      if (element.closest(`.${HOST_BADGE_CLASS}, .${WRAP_CLASS}`)) return false;
      const text = (element.textContent || "").replace(/\s+/g, " ").trim();
      return text.length >= 2 && text.length <= 64 && !/^\d+$/.test(text) && text.toLowerCase() !== "host ready";
    });
    const ign = (nameElement?.textContent || "").replace(/\s+/g, " ").trim();
    if (!ign) continue;

    const image = scope.querySelector("img");
    const key = norm(ign);
    const previous = state.byIgnNorm.get(key);
    const record = {
      ign,
      userId,
      profilePicture: image?.currentSrc || image?.src || previous?.profilePicture || null,
      epicAccountId: previous?.epicAccountId || ""
    };
    if (!previous || previous.userId !== userId || previous.ign !== ign) changed++;
    state.byIgnNorm.set(key, record);
    queueCreatorLookup(record);
  }

  if (state.byIgnNorm.size) state.ready = true;
  if (changed) npPersistIdCacheSoon();
  return rows.length;
}

function decorateVisibleCreatorRows(panel) {
  if (!panel || !npSettings.creatorCodes) return;
  const rows = Array.from(panel.querySelectorAll(PLAYER_LIST_ROW_SELECTOR));
  for (const row of rows) {
    const userId = String(row.getAttribute("userid") || "").trim();
    if (!userId) continue;
    const record = Array.from(state.byIgnNorm.values()).find((item) => String(item?.userId || "") === userId);
    if (!record) continue;
    queueCreatorLookup(record);

    // Creator status is independent from the player-card clock button. This
    // keeps Host Ready working on completed, staff, mobile, and 24/7 rows even
    // when Noble changes or hides the row action controls.
    const actionButton = Array.from(row.querySelectorAll("button, a, [role='button']"))
      .find((element) => !element.classList?.contains(BTN_CLASS));
    applyCreatorStatus(row, record, actionButton || null);
  }
}

// Receive parsed WS JSON from page.js
window.addEventListener("message", (ev) => {
  if (ev.source !== window) return;
  if (ev.origin !== location.origin) return;
  const msg = ev.data;
  if (!msg || msg.__NP_HELPER__ !== true) return;
  if (!globalThis.__NP_HELPER_CHANNEL__ || msg.channel !== globalThis.__NP_HELPER_CHANNEL__) return;

  if (msg.type === "NP_WS_JSON") {
    const p = msg.payload;
    cacheSessionMapPayload(p);
    decorateAll();
  }
});

// -------------------- ONE button per row (hard guards) --------------------
const ROW_MARK = "data-np-row-v3";
const BTN_CLASS = "np-ext-chevron-btn";
const WRAP_CLASS = "np-ext-wrap";

// -------------------- LEFT PLAYERS panel finder --------------------
let cachedPlayersPanel = null;
let cachedPlayersPanelAt = 0;
let cachedTeamsMarkedControl = null;

function currentCreatorSessionRoute() {
  return `${location.pathname}${location.search}${location.hash}`;
}

function visiblePanelMemberIds(panel) {
  if (!panel) return new Set();
  return new Set(
    Array.from(panel.querySelectorAll(PLAYER_LIST_ROW_SELECTOR))
      .map((row) => String(row.getAttribute("userid") || "").trim())
      .filter(Boolean)
  );
}

function resetCreatorSession(nextRoute = currentCreatorSessionRoute()) {
  creatorLookupGeneration++;
  creatorPrepareToken++;
  creatorQueue.length = 0;
  creatorBatchKeys.clear();
  creatorBatchRunning = false;
  creatorScanRequested = false;
  creatorScanPreparing = false;
  creatorScanCompleted = false;
  creatorSessionRouteKey = nextRoute;
  creatorSessionMembers = new Set();
  creatorSessionPanel = null;
  creatorButtonFeedback = "";
  clearTimeout(creatorButtonFeedbackTimer);
  creatorButtonFeedbackTimer = null;
  clearTimeout(creatorScanWatchdogTimer);
  creatorScanWatchdogTimer = null;
  cachedPlayersPanel = null;
  cachedPlayersPanelAt = 0;
  state.rosterUserIds.clear();
  state.markedUserIds.clear();
  state.dropKeyByUserId.clear();
  document.getElementById(MAP_NO_DROP_LAYER_ID)?.remove();
  clearPlayerSearchFocus(true);
  hideCreatorProgress(true);
  const button = document.getElementById(HOST_SCAN_BUTTON_ID);
  button?.removeAttribute("data-scanned");
  updateHostScanButton();
  scheduleMapLayerSync(80);
}

function syncCreatorSession(panel = null) {
  const route = currentCreatorSessionRoute();
  if (!creatorSessionRouteKey) creatorSessionRouteKey = route;
  if (route !== creatorSessionRouteKey) {
    resetCreatorSession(route);
    return true;
  }

  const members = visiblePanelMemberIds(panel);
  if (!members.size) return false;
  if (!creatorScanRequested && !creatorScanPreparing && !creatorScanCompleted) {
    creatorSessionMembers = members;
    creatorSessionPanel = panel;
    return false;
  }
  if (!panel || panel === creatorSessionPanel) return false;

  const baselineSize = creatorSessionMembers.size;
  const comparisonSize = Math.min(baselineSize, members.size);
  if (comparisonSize < 2) return false;
  let overlap = 0;
  for (const member of members) {
    if (creatorSessionMembers.has(member)) overlap++;
  }
  if (overlap === 0 || (comparisonSize >= 5 && overlap / comparisonSize < 0.25)) {
    resetCreatorSession(route);
    creatorSessionMembers = members;
    creatorSessionPanel = panel;
    return true;
  }
  creatorSessionPanel = panel;
  return false;
}

function findPlayersPanelRoot() {
  const now = Date.now();
  if (cachedPlayersPanel && now - cachedPlayersPanelAt < 2000 && document.contains(cachedPlayersPanel)) {
    const rect = cachedPlayersPanel.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0 && cachedPlayersPanel.querySelector(PLAYER_LIST_ROW_SELECTOR)) {
      return cachedPlayersPanel;
    }
  }

  cachedPlayersPanel = null;
  cachedPlayersPanelAt = now;

  const candidates = Array.from(document.querySelectorAll("div, section, aside"));
  let best = null;
  let smallestArea = Infinity;
  for (const el of candidates) {
    const t = (el.innerText || "").trim().toLowerCase();
    if (!t.includes("players")) continue;

    const r = el.getBoundingClientRect();
    if (r.width <= 0 || r.height <= 0) continue;
    const memberRows = el.querySelectorAll(PLAYER_LIST_ROW_SELECTOR).length;
    if (!memberRows || !el.querySelector("img")) continue;

    // Noble switches the sidebar to a full-width block below 1110px. The old
    // half-viewport width guard discarded that valid responsive/24/7 panel.
    const area = r.width * r.height;
    if (area < smallestArea) {
      best = el;
      smallestArea = area;
    }
  }

  cachedPlayersPanel = best;

  return cachedPlayersPanel;
}

function findTeamsMarkedControl() {
  if (
    cachedTeamsMarkedControl &&
    document.contains(cachedTeamsMarkedControl) &&
    /teams?\s+marked/i.test(cachedTeamsMarkedControl.textContent || "")
  ) {
    return cachedTeamsMarkedControl;
  }

  const isMarkedControlCandidate = (element) => {
      if (element.closest(`#${CREATOR_PROGRESS_ID}, #${HOST_SCAN_WRAP_ID}`)) return false;
      const text = (element.textContent || "").replace(/\s+/g, " ").trim();
      if (text.length > 70 || !/\bteams?\s+marked\b/i.test(text)) return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && rect.height <= 80 && rect.width <= 340;
  };
  const byArea = (a, b) => {
    const areaA = a.getBoundingClientRect().width * a.getBoundingClientRect().height;
    const areaB = b.getBoundingClientRect().width * b.getBoundingClientRect().height;
    return areaA - areaB;
  };

  // Prefer Noble's actual outer button. The previous selector chose the
  // smallest text span, which made only the right half respond to clicks.
  const nativeControl = Array.from(
    document.querySelectorAll("button, [role='button'], a")
  )
    .filter(isMarkedControlCandidate)
    .sort(byArea)[0] || null;
  if (nativeControl) {
    cachedTeamsMarkedControl = nativeControl;
    return cachedTeamsMarkedControl;
  }

  const label = Array.from(document.querySelectorAll("span, p, div"))
    .filter(isMarkedControlCandidate)
    .sort(byArea)[0] || null;
  if (!label) return null;

  let promoted = label;
  let parent = label.parentElement;
  for (let depth = 0; parent && depth < 4; depth++, parent = parent.parentElement) {
    if (!isMarkedControlCandidate(parent)) break;
    promoted = parent;
  }
  cachedTeamsMarkedControl = promoted;
  return cachedTeamsMarkedControl;
}

function unmarkedDiscordIds() {
  const panel = findPlayersPanelRoot();
  const allIds = new Set();
  if (panel) {
    for (const row of panel.querySelectorAll(PLAYER_LIST_ROW_SELECTOR)) {
      const userId = String(row.getAttribute("userid") || "").trim();
      if (/^\d{8,24}$/.test(userId)) allIds.add(userId);
    }
  }
  if (!allIds.size) {
    for (const userId of state.rosterUserIds) {
      if (/^\d{8,24}$/.test(userId)) allIds.add(userId);
    }
  }

  const markedIds = new Set();
  for (const marker of document.querySelectorAll("[user-id]")) {
    const userId = String(marker.getAttribute("user-id") || "").trim();
    if (userId) markedIds.add(userId);
  }
  if (!markedIds.size) {
    for (const userId of state.markedUserIds) markedIds.add(userId);
  }
  return [...allIds].filter((userId) => !markedIds.has(userId));
}

async function copyUnmarkedDiscordMentions() {
  const ids = unmarkedDiscordIds();
  if (!ids.length) {
    showToast("Everyone is marked");
    return;
  }
  const mentions = ids.map((userId) => `<@${userId}>`).join(" ");
  try {
    await navigator.clipboard.writeText(mentions);
    showToast(`Copied ${ids.length} unmarked player${ids.length === 1 ? "" : "s"}`);
  } catch {
    window.prompt("Copy unmarked Discord mentions:", mentions);
  }
}

function decorateTeamsMarkedCopy() {
  const control = findTeamsMarkedControl();
  if (!control) return;
  control.classList.add(TEAMS_MARKED_CLASS);
  control.setAttribute("role", "button");
  control.setAttribute("tabindex", "0");
  control.setAttribute("aria-label", "Copy unmarked players as Discord mentions");
  control.title = "Copy unmarked players as Discord mentions";
  if (control.dataset.npTeamsMarkedBound === "true") return;
  control.dataset.npTeamsMarkedBound = "true";
  control.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    void copyUnmarkedDiscordMentions();
  });
  control.addEventListener("keydown", (event) => {
    if (!["Enter", " "].includes(event.key)) return;
    event.preventDefault();
    event.stopPropagation();
    void copyUnmarkedDiscordMentions();
  });
}

// -------------------- SEARCH -> LEFT PLAYER LIST --------------------
function isSessionPlayerSearchInput(element) {
  if (!(element instanceof HTMLInputElement)) return false;
  const descriptor = [
    element.placeholder,
    element.getAttribute("aria-label"),
    element.getAttribute("name")
  ].filter(Boolean).join(" ").toLowerCase();
  return descriptor.includes("search") && descriptor.includes("player");
}

function clearPlayerSearchFocus(immediate = false) {
  clearTimeout(playerSearchRevealTimer);
  clearTimeout(playerSearchClearTimer);
  for (const timer of playerSearchRetryTimers) clearTimeout(timer);
  playerSearchRetryTimers = [];
  playerSearchRevealTimer = null;
  playerSearchClearTimer = null;
  if (playerSearchFocusedRow) {
    playerSearchFocusedRow.classList.remove(PLAYER_SEARCH_FOCUS_CLASS);
    playerSearchFocusedRow.removeAttribute("data-np-search-focused");
    playerSearchFocusedRow = null;
  }
  if (immediate) {
    clearTimeout(playerSearchTimer);
    playerSearchTimer = null;
  }
}

function playerListScroller(row, panel) {
  let element = row?.parentElement || null;
  while (element) {
    const style = getComputedStyle(element);
    const canScroll =
      element.scrollHeight > element.clientHeight + 2 &&
      /(auto|scroll|overlay)/i.test(style.overflowY || "");
    if (canScroll) return element;
    if (element === panel) break;
    element = element.parentElement;
  }
  return panel?.scrollHeight > panel?.clientHeight + 2 ? panel : null;
}

function rowForPlayerRecord(panel, record) {
  if (!record) return null;
  const userId = String(record.userId || "").trim();
  const root = panel || document;
  const rows = Array.from(root.querySelectorAll(PLAYER_LIST_ROW_SELECTOR));
  if (userId) {
    const exactIdRow = rows.find((row) =>
      String(row.getAttribute("userid") || "").trim() === userId
    );
    if (exactIdRow) return exactIdRow;
  }

  // Fallback for the brief window before Noble's user IDs have been cached.
  const wantedName = norm(record.ign);
  return rows.find((row) => {
    const spans = Array.from(row.querySelectorAll("span"));
    return spans.some((span) => norm(span.textContent) === wantedName);
  }) || null;
}

function revealPlayerListRow(row, panel) {
  clearPlayerSearchFocus();
  const scroller = playerListScroller(row, panel);
  const smooth = npSettings.animations &&
    !window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;

  if (scroller) {
    const rowRect = row.getBoundingClientRect();
    const scrollerRect = scroller.getBoundingClientRect();
    const targetTop =
      scroller.scrollTop +
      (rowRect.top + rowRect.height / 2) -
      (scrollerRect.top + scrollerRect.height / 2);
    const maxTop = Math.max(0, scroller.scrollHeight - scroller.clientHeight);
    scroller.scrollTo({
      top: Math.max(0, Math.min(maxTop, targetTop)),
      behavior: smooth ? "smooth" : "auto"
    });
  } else {
    row.scrollIntoView({
      behavior: smooth ? "smooth" : "auto",
      block: "center",
      inline: "nearest"
    });
  }

  playerSearchFocusedRow = row;
  playerSearchRevealTimer = setTimeout(() => {
    if (!document.contains(row)) {
      if (playerSearchFocusedRow === row) playerSearchFocusedRow = null;
      return;
    }
    // Restart the sweep when the same player is searched twice.
    row.classList.remove(PLAYER_SEARCH_FOCUS_CLASS);
    void row.offsetWidth;
    row.classList.add(PLAYER_SEARCH_FOCUS_CLASS);
    row.setAttribute("data-np-search-focused", "true");
    playerSearchClearTimer = setTimeout(() => {
      if (playerSearchFocusedRow === row) clearPlayerSearchFocus();
    }, smooth ? 2450 : 2100);
  }, smooth ? 360 : 40);
}

function focusPlayerFromSearchValue(value) {
  const wantedName = norm(value);
  if (!wantedName) return false;

  const panel = findPlayersPanelRoot();
  if (panel) cacheVisibleMemberRows(panel);

  // Epic display names are unique, so only an exact normalized match is safe.
  // Partial input must never jump to the wrong person.
  const record = state.byIgnNorm.get(wantedName);
  const row = rowForPlayerRecord(panel, record);
  if (!row) return false;

  revealPlayerListRow(row, panel);
  return true;
}

function playerRecordFromSearchChoice(target) {
  if (!(target instanceof Element)) return null;
  const panel = findPlayersPanelRoot();
  if (panel) cacheVisibleMemberRows(panel);

  let element = target;
  for (let depth = 0; element && depth < 6; depth++, element = element.parentElement) {
    if (element instanceof HTMLInputElement) continue;
    const resultImage = element.matches?.("img[alt='PFP']")
      ? element
      : element.querySelector?.("img[alt='PFP']");
    if (resultImage) {
      const resultScope = resultImage.parentElement || element;
      const resultName = Array.from(resultScope.querySelectorAll?.("span") || [])
        .map((span) => (span.textContent || "").replace(/\s+/g, " ").trim())
        .find((text) => text.length >= 2 && text.length <= 64);
      if (resultName) {
        return state.byIgnNorm.get(norm(resultName)) || { ign: resultName, userId: "" };
      }
    }
    const candidates = [
      element.getAttribute?.("data-value"),
      element.getAttribute?.("aria-label"),
      ...Array.from(element.querySelectorAll?.("span") || []).map((span) => span.textContent),
      element.textContent
    ];
    for (const candidate of candidates) {
      const record = state.byIgnNorm.get(norm(candidate));
      if (record) return record;
    }
    if (element === document.body) break;
  }
  return null;
}

function firstPlayerRecordInSearchModal(input) {
  if (!isSessionPlayerSearchInput(input)) return null;
  const panel = findPlayersPanelRoot();
  if (panel) cacheVisibleMemberRows(panel);

  const modal = input.closest(".ant-modal-content, [role='dialog']");
  if (!modal) return null;
  for (const image of modal.querySelectorAll("img[alt='PFP']")) {
    const scope = image.parentElement || image.closest("div");
    const name = Array.from(scope?.querySelectorAll?.("span") || [])
      .map((span) => (span.textContent || "").replace(/\s+/g, " ").trim())
      .find((text) => text.length >= 2 && text.length <= 64);
    if (name) return state.byIgnNorm.get(norm(name)) || { ign: name, userId: "" };
  }
  for (const span of modal.querySelectorAll("span")) {
    const record = state.byIgnNorm.get(norm(span.textContent));
    if (record) return record;
  }
  return null;
}

function schedulePlayerRecordFocus(record, delay = 90) {
  if (!record) return false;
  clearTimeout(playerSearchTimer);
  for (const timer of playerSearchRetryTimers) clearTimeout(timer);
  playerSearchRetryTimers = [];

  for (const wait of [delay, delay + 260, delay + 700]) {
    const timer = setTimeout(() => {
      const panel = findPlayersPanelRoot();
      const row = rowForPlayerRecord(panel, record) || rowForPlayerRecord(null, record);
      if (!row) return;
      for (const pending of playerSearchRetryTimers) clearTimeout(pending);
      playerSearchRetryTimers = [];
      revealPlayerListRow(row, panel);
    }, wait);
    playerSearchRetryTimers.push(timer);
  }
  return true;
}

function sessionSearchInputFromTarget(target) {
  if (isSessionPlayerSearchInput(document.activeElement)) return document.activeElement;
  if (!(target instanceof Element)) return null;
  const modal = target.closest(".ant-modal-content, [role='dialog']");
  if (!modal) return null;
  return Array.from(modal.querySelectorAll("input")).find(isSessionPlayerSearchInput) || null;
}

function handlePlayerSearchSelectionEvent(event) {
  const input = sessionSearchInputFromTarget(event.target);
  if (!input) return;
  let record = playerRecordFromSearchChoice(event.target);
  const pressedButton = event.target.closest?.("button");
  if (!record && /^search$/i.test((pressedButton?.textContent || "").trim())) {
    record = firstPlayerRecordInSearchModal(input);
  }
  if (record) schedulePlayerRecordFocus(record, 120);
}

// Delegated listeners survive Noble's React input replacements and preserve
// the site's own search/zoom handlers because they never prevent propagation.
document.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && isSessionPlayerSearchInput(event.target)) {
    const firstResult = firstPlayerRecordInSearchModal(event.target);
    if (!schedulePlayerRecordFocus(firstResult, 120)) {
      const exactRecord = state.byIgnNorm.get(norm(event.target.value));
      schedulePlayerRecordFocus(exactRecord, 120);
    }
  }
}, true);

document.addEventListener("pointerdown", handlePlayerSearchSelectionEvent, true);
document.addEventListener("click", handlePlayerSearchSelectionEvent, true);

function hostScanButtonMarkup(label = "Check hosts") {
  return `
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="11" cy="11" r="6.5" stroke="currentColor" stroke-width="1.8"></circle>
      <path d="m16 16 4 4" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></path>
    </svg>
    <span>${label}</span>
  `;
}

function updateHostScanButton() {
  const button = document.getElementById(HOST_SCAN_BUTTON_ID);
  if (!button) return;
  const busy = creatorScanPreparing || creatorScanRequested;
  button.disabled = busy;
  button.setAttribute("aria-busy", busy ? "true" : "false");
  button.classList.toggle("is-busy", busy);
  const label = busy
    ? creatorScanPreparing ? "Loading players" : "Checking hosts"
    : creatorButtonFeedback || (creatorScanCompleted ? "Check again" : "Check hosts");
  if (button.dataset.npLabel !== label) {
    button.dataset.npLabel = label;
    button.innerHTML = hostScanButtonMarkup(label);
  }
  button.title = busy
    ? "Host check in progress"
    : "Check visible players for active creator codes";
}

function setHostScanButtonFeedback(label, duration = 1200) {
  creatorButtonFeedback = label;
  clearTimeout(creatorButtonFeedbackTimer);
  updateHostScanButton();
  creatorButtonFeedbackTimer = setTimeout(() => {
    creatorButtonFeedback = "";
    creatorButtonFeedbackTimer = null;
    updateHostScanButton();
  }, duration);
}

function findPlayersHeading(panel) {
  return Array.from(panel.querySelectorAll("h1, h2, h3, h4, p, span, div"))
    .filter((element) => {
      if (element.id === HOST_SCAN_WRAP_ID || element.closest(`#${HOST_SCAN_WRAP_ID}`)) return false;
      const directText = Array.from(element.childNodes)
        .filter((node) => node.nodeType === Node.TEXT_NODE)
        .map((node) => node.textContent || "")
        .join(" ")
        .replace(/\s+/g, " ")
        .trim();
      if (!/^players(?:\s*[·:()\-]?\s*[\d/]+)?$/i.test(directText)) return false;
      const rect = element.getBoundingClientRect();
      return rect.width > 0 && rect.height > 0 && rect.height < 90;
    })
    .sort((a, b) => a.getBoundingClientRect().height - b.getBoundingClientRect().height)[0] || null;
}

function ensureHostScanButton(panel) {
  if (!npSettings.creatorCodes || !panel) {
    document.getElementById(HOST_SCAN_WRAP_ID)?.remove();
    return;
  }

  const existing = document.getElementById(HOST_SCAN_BUTTON_ID);
  if (existing && panel.contains(existing)) {
    updateHostScanButton();
    return;
  }
  document.getElementById(HOST_SCAN_WRAP_ID)?.remove();

  const heading = findPlayersHeading(panel);
  const container = heading?.matches("div") ? heading : heading?.parentElement;
  if (!container) return;
  container.setAttribute("data-np-player-header", "true");
  const searchTrigger = Array.from(container.querySelectorAll("button")).find((candidate) =>
    /\bsearch\b/i.test(candidate.textContent || "")
  );
  searchTrigger?.classList.add("np-player-search-trigger");

  const wrapper = document.createElement("span");
  wrapper.id = HOST_SCAN_WRAP_ID;
  const button = document.createElement("button");
  button.id = HOST_SCAN_BUTTON_ID;
  button.type = "button";
  button.dataset.npLabel = "Check hosts";
  button.innerHTML = hostScanButtonMarkup();
  button.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    void startCreatorScan();
  });
  wrapper.appendChild(button);

  const layout = getComputedStyle(container);
  if (layout.display !== "flex" && layout.display !== "inline-flex" && layout.display !== "grid") {
    container.style.display = "flex";
  }
  container.style.alignItems ||= "center";
  container.appendChild(wrapper);
  updateHostScanButton();
}

function visibleCreatorRecords(panel) {
  const records = new Map();
  const byUserId = new Map(
    Array.from(state.byIgnNorm.values())
      .filter((record) => record?.userId)
      .map((record) => [String(record.userId), record])
  );

  for (const row of panel.querySelectorAll(PLAYER_LIST_ROW_SELECTOR)) {
    const userId = String(row.getAttribute("userid") || "").trim();
    const record = byUserId.get(userId) || findRecordInRowText(row.innerText || "");
    if (!record?.ign) continue;
    records.set(creatorKey(record.ign), record);
  }
  return [...records.values()];
}

function creatorScanDelay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function startCreatorScan() {
  if (!npSettings.creatorCodes) return;
  cachedPlayersPanel = null;
  cachedPlayersPanelAt = 0;
  let panel = findPlayersPanelRoot();
  syncCreatorSession(panel);
  if (creatorScanPreparing || creatorScanRequested) return;

  const prepareToken = ++creatorPrepareToken;
  const route = creatorSessionRouteKey || currentCreatorSessionRoute();
  creatorScanPreparing = true;
  creatorButtonFeedback = "";
  clearTimeout(creatorButtonFeedbackTimer);
  creatorButtonFeedbackTimer = null;
  updateHostScanButton();

  let records = [];
  for (let attempt = 0; attempt < 9; attempt++) {
    if (prepareToken !== creatorPrepareToken) return;
    if (route !== currentCreatorSessionRoute()) {
      resetCreatorSession(currentCreatorSessionRoute());
      return;
    }
    cachedPlayersPanel = null;
    cachedPlayersPanelAt = 0;
    panel = findPlayersPanelRoot();
    if (panel) {
      syncCreatorSession(panel);
      if (prepareToken !== creatorPrepareToken) return;
      cacheVisibleMemberRows(panel);
      records = visibleCreatorRecords(panel);
      if (records.length) break;
    }
    await creatorScanDelay(150);
  }

  if (prepareToken !== creatorPrepareToken) return;
  if (route !== currentCreatorSessionRoute()) {
    resetCreatorSession(currentCreatorSessionRoute());
    return;
  }
  creatorScanPreparing = false;
  if (!records.length) {
    setHostScanButtonFeedback(panel ? "No players found" : "Player list unavailable");
    return;
  }

  creatorLookupGeneration++;
  creatorQueue.length = 0;
  clearTimeout(creatorProgressHideTimer);
  clearTimeout(creatorProgressSettleTimer);
  clearTimeout(creatorScanWatchdogTimer);
  creatorProgressHideTimer = null;
  creatorProgressSettleTimer = null;
  creatorScanWatchdogTimer = null;
  creatorBatchKeys.clear();
  creatorBatchRunning = true;
  creatorScanRequested = true;
  creatorScanCompleted = false;
  creatorSessionMembers = visiblePanelMemberIds(panel);
  creatorSessionPanel = panel;
  updateHostScanButton();

  for (const record of records) queueCreatorLookup(record, { manual: true });
  if (!creatorBatchKeys.size) {
    creatorScanRequested = false;
    creatorBatchRunning = false;
    creatorScanCompleted = true;
    updateHostScanButton();
  } else {
    updateCreatorProgress();
    const generation = creatorLookupGeneration;
    creatorScanWatchdogTimer = setTimeout(() => {
      if (!creatorScanRequested || generation !== creatorLookupGeneration) return;
      for (const key of creatorBatchKeys) {
        const item = creatorStates.get(key);
        if (item && !["done", "error"].includes(item.status)) {
          creatorStates.set(key, {
            ...item,
            status: "error",
            error: "Host check timed out",
            retryAt: 0
          });
        }
      }
      updateCreatorProgress();
    }, CREATOR_SCAN_WATCHDOG_MS);
  }
}

// -------------------- Stable "row" selection (different approach) --------------------
// We pick the right-side clock icon, then treat its nearest "row" container as the row.
// This avoids guessing between map labels vs sidebar.
function findClockButtonsInPlayersPanel(panel) {
  if (!panel) return [];

  const buttons = Array.from(panel.querySelectorAll("button, a, [role='button']"));
  const iconButtons = buttons.filter((el) => {
    if (!el || el.nodeType !== 1) return false;
    if (!panel.contains(el)) return false;

    // Must look like icon (svg)
    const hasSvg = !!el.querySelector("svg");
    if (!hasSvg) return false;

    // Must be "small"
    const w = el.offsetWidth || 0;
    const h = el.offsetHeight || 0;
    if (w > 80 || h > 80) return false;

    // Skip our own
    if (el.classList?.contains(BTN_CLASS)) return false;
    if (el.closest?.(`.${WRAP_CLASS}`)) return false;
    if (el.id === HOST_SCAN_BUTTON_ID || el.closest?.(`#${HOST_SCAN_WRAP_ID}`)) return false;

    const cs = window.getComputedStyle(el);
    if (cs.display === "none" || cs.visibility === "hidden" || cs.opacity === "0") return false;

    return true;
  });

  return iconButtons;
}

// Choose a reasonable "row container" for a given clock button
function rowFromClockButton(clockBtn, panel) {
  if (!clockBtn) return null;

  // Prefer the closest element that also contains an avatar img + some text
  let cur = clockBtn.parentElement;
  for (let i = 0; i < 6 && cur; i++) {
    if (panel && !panel.contains(cur)) break;
    const hasImg = !!cur.querySelector("img");
    const txt = (cur.innerText || "").trim();
    if (hasImg && txt && txt.length < 120) return cur;
    cur = cur.parentElement;
  }

  // fallback
  return clockBtn.closest("div, li, button, a");
}

function findRecordInRowText(rowText) {
  const t = norm(rowText);
  if (!t) return null;

  const exact = state.byIgnNorm.get(t);
  if (exact) return exact;

  for (const [ignNorm, rec] of state.byIgnNorm.entries()) {
    if (t.includes(ignNorm)) return rec;
  }
  return null;
}

function rowAlreadyHasOurButton(row) {
  return !!row.querySelector(`.${WRAP_CLASS} .${BTN_CLASS}`);
}

function cleanupDuplicateOurButtons() {
  const rows = new Set();
  for (const wrap of document.querySelectorAll(`.${WRAP_CLASS}`)) {
    const row = wrap.closest(`[${ROW_MARK}]`) || wrap.parentElement;
    if (row) rows.add(row);
  }
  for (const row of rows) {
    const wraps = row.querySelectorAll(`.${WRAP_CLASS}`);
    for (let i = 1; i < wraps.length; i++) wraps[i].remove();
  }
}

function removePlayerCardUi() {
  document.querySelectorAll(`.${WRAP_CLASS}`).forEach((el) => el.remove());
  document.querySelectorAll(`[${ROW_MARK}]`).forEach((el) => el.removeAttribute(ROW_MARK));
  hidePopover();
}

function removeCreatorUi() {
  document.querySelectorAll(`.${HOST_BADGE_CLASS}`).forEach((el) => el.remove());
  document.querySelectorAll(`.${HOST_INDICATOR_CLASS}`).forEach((el) => el.remove());
  document.querySelectorAll(`.${HOST_MAP_NAME_CLASS}`).forEach((el) => {
    el.classList.remove(HOST_MAP_NAME_CLASS);
    el.removeAttribute("title");
  });
  document.querySelectorAll(`.${HOST_NAME_CLASS}`).forEach((el) => {
    el.classList.remove(HOST_NAME_CLASS);
    el.removeAttribute("title");
  });
  document.querySelectorAll('[data-np-host-ready="true"]').forEach((el) => el.removeAttribute("data-np-host-ready"));
  document.querySelectorAll('[data-np-creator-status]').forEach((el) => el.removeAttribute("data-np-creator-status"));
  document.getElementById(HOST_SCAN_WRAP_ID)?.remove();
  hideCreatorProgress(true);
}

// -------------------- Shadow DOM Popover --------------------
let anchorBtn = null;
let host = null;
let pop = null;
let toastTimer = null;

function ensureShadowPopover() {
  if (host) return;

  host = document.createElement("div");
  host.style.position = "fixed";
  host.style.left = "0";
  host.style.top = "0";
  host.style.width = "0";
  host.style.height = "0";
  host.style.zIndex = "2147483647";
  document.body.appendChild(host);

  const shadow = host.attachShadow({ mode: "open" });

  const style = document.createElement("style");
  style.textContent = `
    :host { all: initial; }
    .popover {
      position: fixed;
      width: 340px;
      border-radius: 10px;
      background: #0F1C25;
      border: 1px solid rgba(255,255,255,0.12);
      box-shadow: 0 14px 38px rgba(0,0,0,0.42);
      color: #fff;
      font: 13px/1.4 Gilroy, "Segoe UI", Arial, sans-serif;
      overflow: hidden;
      display: none;
    }
    .hdr {
      display: flex;
      gap: 12px;
      align-items: center;
      padding: 14px 14px 12px 14px;
      border-bottom: 1px solid rgba(255,255,255,0.08);
    }
    .avatar {
      width: 44px;
      height: 44px;
      border-radius: 8px;
      object-fit: cover;
      border: 1px solid rgba(255,255,255,0.12);
      background: rgba(255,255,255,0.06);
      flex: 0 0 auto;
    }
    .headtext { min-width:0; flex: 1 1 auto; }
    .title {
      font-weight: 850;
      font-size: 14px;
      line-height: 1.2;
      margin: 0;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 210px;
    }
    .sub {
      margin-top: 2px;
      font-size: 12px;
      opacity: 0.72;
    }
    .sub.host-ready {
      color: #68e0ae;
      font-weight: 700;
      opacity: 1;
    }
    .trackerBtn {
      flex: 0 0 auto;
      padding: 8px 10px;
      border-radius: 7px;
      border: 1px solid rgba(255,255,255,0.14);
      background: #1A2C38;
      color: inherit;
      cursor: pointer;
      user-select: none;
      font: 600 12px/1 Gilroy, "Segoe UI", Arial, sans-serif;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: background .12s ease, border-color .12s ease, transform .08s ease;
    }
    .trackerBtn:hover { background: rgba(255,191,64,0.10); border-color: rgba(255,191,64,0.40); color: #FFBF40; }
    .trackerBtn:active { transform: scale(0.98); }

    .body {
      padding: 12px 14px 14px 14px;
      display: grid;
      gap: 10px;
    }
    .field {
      padding: 10px;
      border-radius: 8px;
      border: 1px solid rgba(255,255,255,0.10);
      background: #0A1520;
    }
    .label {
      font-size: 11px;
      opacity: 0.72;
      margin-bottom: 6px;
      letter-spacing: 0.25px;
    }
    .row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
    }
    .value {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono","Courier New", monospace;
      font-size: 12px;
      opacity: 0.96;
      word-break: break-all;
    }
    .copy {
      padding: 7px 10px;
      border-radius: 6px;
      border: 1px solid rgba(255,255,255,0.14);
      background: #1A2C38;
      color: inherit;
      cursor: pointer;
      user-select: none;
      font: 600 12px/1 Gilroy, "Segoe UI", Arial, sans-serif;
      transition: background .12s ease, border-color .12s ease, transform .08s ease;
      flex: 0 0 auto;
    }
    .copy:hover { background: rgba(255,191,64,0.10); border-color: rgba(255,191,64,0.40); color: #FFBF40; }
    .copy:active { transform: scale(0.98); }

    .toast {
      position: fixed;
      left: 50%;
      bottom: 22px;
      transform: translateX(-50%);
      background: #0A1520;
      color: white;
      padding: 10px 12px;
      border: 1px solid rgba(255,191,64,.28);
      border-radius: 8px;
      font: 600 12px/1.4 Gilroy, "Segoe UI", Arial, sans-serif;
      box-shadow: 0 12px 30px rgba(0,0,0,0.25);
      display: none;
    }

    .arrow {
      position: fixed;
      width: 12px;
      height: 12px;
      transform: rotate(45deg);
      background: #0F1C25;
      border-left: 1px solid rgba(255,255,255,0.12);
      border-top: 1px solid rgba(255,255,255,0.12);
      display: none;
      z-index: 2147483647;
    }
  `;

  const arrow = document.createElement("div");
  arrow.className = "arrow";

  pop = document.createElement("div");
  pop.className = "popover";
  pop.innerHTML = `
    <div class="hdr">
      <img class="avatar" id="av" />
      <div class="headtext">
        <div class="title" id="t"></div>
        <div class="sub" id="sub">Noble player</div>
      </div>
      <button class="trackerBtn" id="trk" title="Open FortniteTracker profile">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
          <path d="M14 3h7v7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M10 14 21 3" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          <path d="M21 14v6a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        Tracker
      </button>
    </div>
    <div class="body">
      <div class="field">
        <div class="label">EPIC NAME</div>
        <div class="row">
          <div class="value" id="ep"></div>
          <button class="copy" id="c1">Copy</button>
        </div>
      </div>
      <div class="field">
        <div class="label">DISCORD ID</div>
        <div class="row">
          <div class="value" id="dc"></div>
          <button class="copy" id="c2">Copy</button>
        </div>
      </div>
    </div>
  `;

  const toastEl = document.createElement("div");
  toastEl.className = "toast";

  shadow.appendChild(style);
  shadow.appendChild(arrow);
  shadow.appendChild(pop);
  shadow.appendChild(toastEl);

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") hidePopover();
  });

  document.addEventListener("mousedown", (e) => {
    if (!pop || pop.style.display === "none") return;
    const path = e.composedPath ? e.composedPath() : [];
    if (anchorBtn && (e.target === anchorBtn || anchorBtn.contains(e.target))) return;
    if (path.includes(pop)) return;
    hidePopover();
  });

  host.__npShadow = { shadow, pop, arrow, toastEl };
}

function showToast(text) {
  ensureShadowPopover();
  const { toastEl } = host.__npShadow;
  toastEl.textContent = text;
  toastEl.style.display = "block";
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (toastEl.style.display = "none"), 1100);
}

function clamp(v, min, max) {
  return Math.max(min, Math.min(max, v));
}

function showPopover(btn, record) {
  ensureShadowPopover();
  anchorBtn = btn;

  const { pop, arrow } = host.__npShadow;

  pop.querySelector("#t").textContent = record.ign;
  pop.querySelector("#ep").textContent = record.ign;
  pop.querySelector("#dc").textContent = record.userId;
  const creator = creatorStates.get(creatorKey(record.ign));
  const sub = pop.querySelector("#sub");
  const epicAccountId = normalizeEpicAccountId(record.epicAccountId);
  const hostReady =
    creator?.status === "done" &&
    creator.hasCreatorCode &&
    creator.verified &&
    (!epicAccountId || !creator.accountId || creator.accountId === epicAccountId);
  if (hostReady) sub.textContent = `Host ready · ${creator.code}`;
  else if (npSettings.creatorCodes && creator?.status === "done") sub.textContent = "No verified creator code found";
  else if (npSettings.creatorCodes && ["queued", "checking"].includes(creator?.status)) sub.textContent = "Checking creator code…";
  else if (npSettings.creatorCodes && creator?.status === "error") sub.textContent = "Creator check unavailable";
  else sub.textContent = "Noble player";
  sub.classList.toggle("host-ready", hostReady);

  const av = pop.querySelector("#av");
  if (record.profilePicture) {
    av.src = record.profilePicture;
    av.style.display = "block";
  } else {
    av.removeAttribute("src");
    av.style.display = "none";
  }

  pop.querySelector("#trk").onclick = () => {
    const url = `https://fortnitetracker.com/profile/all/${encodeURIComponent(record.ign)}`;
    window.open(url, "_blank", "noopener,noreferrer");
  };

  pop.querySelector("#c1").onclick = async () => {
    try {
      await navigator.clipboard.writeText(record.ign);
      showToast("Copied Epic name");
    } catch {
      window.prompt("Copy Epic name:", record.ign);
    }
  };
  pop.querySelector("#c2").onclick = async () => {
    try {
      await navigator.clipboard.writeText(record.userId);
      showToast("Copied Discord ID");
    } catch {
      window.prompt("Copy Discord ID:", record.userId);
    }
  };

  const rect = btn.getBoundingClientRect();
  const popW = 340;
  const popH = 220;

  let left = rect.right + 14;
  let top = rect.top - 20;

  if (left + popW + 8 > window.innerWidth) left = rect.left - popW - 14;

  left = clamp(left, 8, window.innerWidth - popW - 8);
  top = clamp(top, 8, window.innerHeight - popH - 8);

  pop.style.left = `${left}px`;
  pop.style.top = `${top}px`;
  pop.style.display = "block";

  const arrowSize = 12;
  const arrowLeft = left > rect.right ? rect.right + 6 : rect.left - arrowSize - 6;
  const arrowTop = clamp(rect.top + rect.height / 2 - arrowSize / 2, 8, window.innerHeight - arrowSize - 8);

  arrow.style.left = `${arrowLeft}px`;
  arrow.style.top = `${arrowTop}px`;
  arrow.style.display = "block";
}

function hidePopover() {
  if (!host) return;
  const { pop, arrow } = host.__npShadow || {};
  if (pop) pop.style.display = "none";
  if (arrow) arrow.style.display = "none";
  anchorBtn = null;
}

// -------------------- Inject chevron button --------------------
function createChevronButton() {
  const wrap = document.createElement("span");
  wrap.className = WRAP_CLASS;
  wrap.style.display = "inline-flex";
  wrap.style.alignItems = "center";
  wrap.style.flex = "0 0 auto";
  wrap.style.marginRight = "6px";
  wrap.style.marginLeft = "0px";

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = BTN_CLASS;
  btn.setAttribute("aria-label", "Open user info");
  btn.innerHTML = `
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M9 18l6-6-6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>
  `;

  Object.assign(btn.style, {
    width: "30px",
    height: "30px",
    borderRadius: "12px",
    border: "1px solid rgba(255,255,255,0.14)",
    background: "rgba(255,255,255,0.06)",
    color: "rgba(230,237,245,0.92)",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    userSelect: "none",
    transition: "transform .08s ease, background .12s ease, border-color .12s ease"
  });

  btn.addEventListener("mouseenter", () => {
    btn.style.background = "rgba(255,255,255,0.10)";
    btn.style.borderColor = "rgba(255,255,255,0.20)";
  });
  btn.addEventListener("mouseleave", () => {
    btn.style.background = "rgba(255,255,255,0.06)";
    btn.style.borderColor = "rgba(255,255,255,0.14)";
  });
  btn.addEventListener("mousedown", () => (btn.style.transform = "scale(0.98)"));
  btn.addEventListener("mouseup", () => (btn.style.transform = "scale(1)"));

  wrap.appendChild(btn);
  return { wrap, btn };
}

function syncMapHostName(record, hostReady, code = "") {
  const userId = String(record?.userId || "").trim();
  if (!userId) return;
  for (const marker of document.querySelectorAll("[user-id]")) {
    if (String(marker.getAttribute("user-id") || "").trim() !== userId) continue;
    const name = Array.from(marker.querySelectorAll("span")).find((element) =>
      norm(element.textContent) === norm(record?.ign)
    ) || null;
    if (!name) continue;
    name.classList.toggle(HOST_MAP_NAME_CLASS, hostReady);
    if (hostReady) name.title = `Host ready · Creator code: ${code}`;
    else if (name.title?.startsWith("Host ready")) name.removeAttribute("title");
  }
  scheduleMapLayerSync();
}

function syncSidebarHostIndicator(row, name, hostReady, code = "") {
  name?.classList.remove(HOST_NAME_CLASS);
  if (name?.title?.startsWith("Host ready")) name.removeAttribute("title");

  let indicator = row.querySelector(`.${HOST_INDICATOR_CLASS}`);
  if (!hostReady || !name) {
    indicator?.remove();
    return;
  }
  if (!indicator) {
    indicator = document.createElement("span");
    indicator.className = HOST_INDICATOR_CLASS;
    indicator.setAttribute("role", "img");
    name.insertAdjacentElement("afterend", indicator);
  }
  indicator.setAttribute("aria-label", `Host ready. Creator code: ${code}`);
  indicator.title = `Host ready · Creator code: ${code}`;
}

function applyCreatorStatus(row, record, clockBtn) {
  const key = creatorKey(record?.ign);
  const result = key ? creatorStates.get(key) : null;
  const recordAccountId = normalizeEpicAccountId(record?.epicAccountId);
  const accountMatches = !recordAccountId || !result?.accountId || result.accountId === recordAccountId;
  const hostReady =
    npSettings.creatorCodes &&
    result?.status === "done" &&
    result.hasCreatorCode &&
    result.verified &&
    accountMatches;
  const badge = row.querySelector(`.${HOST_BADGE_CLASS}`);
  const name = Array.from(row.querySelectorAll("span")).find((element) =>
    norm(element.textContent) === norm(record?.ign)
  ) || null;
  row.setAttribute("data-np-creator-status", result?.status || "waiting");
  badge?.remove();
  syncSidebarHostIndicator(row, name, hostReady, result?.code || "");
  syncMapHostName(record, hostReady, result?.code || "");

  if (!hostReady) {
    row.removeAttribute("data-np-host-ready");
    return;
  }

  row.setAttribute("data-np-host-ready", "true");
}

function injectButtonIntoRow(row, rec, clockBtn) {
  if (rowAlreadyHasOurButton(row)) {
    const existing = row.querySelector(`.${BTN_CLASS}`);
    if (existing) existing.__npRecord = rec;
    row.setAttribute(ROW_MARK, String(rec.userId));
    return;
  }

  if (!clockBtn || !clockBtn.parentElement) return;

  const { wrap, btn } = createChevronButton();
  btn.__npRecord = rec;

  btn.addEventListener("click", (e) => {
    e.stopPropagation();
    e.preventDefault();

    if (anchorBtn === btn && host?.__npShadow?.pop?.style.display !== "none") {
      hidePopover();
      return;
    }
    if (btn.__npRecord) showPopover(btn, btn.__npRecord);
  });

  // ✅ Always insert in same parent, right before the clock button
  clockBtn.parentElement.insertBefore(wrap, clockBtn);

  row.setAttribute(ROW_MARK, String(rec.userId));
}

function decorateAll() {
  ensureSiteCredit();
  ensureYuniteLeaderboardOptions();
  scheduleMapLayerSync();
  // Remove badge nodes left by older releases, including any that were
  // accidentally attached to Leaflet marker HTML instead of sidebar rows.
  document.querySelectorAll(`.${HOST_BADGE_CLASS}`).forEach((element) => element.remove());
  decorateTeamsMarkedCopy();
  syncCreatorSession();
  const panel = findPlayersPanelRoot();
  if (!panel) return;
  syncCreatorSession(panel);
  ensureHostScanButton(panel);
  cacheVisibleMemberRows(panel);
  decorateSessionMatchAttendance(panel);
  if (!state.ready) return;
  if (!npSettings.playerCards && !npSettings.creatorCodes) return;

  decorateVisibleCreatorRows(panel);

  // We iterate by clock buttons (one per row), so we will inject for ALL rows.
  const clockButtons = findClockButtonsInPlayersPanel(panel);
  if (!clockButtons.length) return;

  for (const clockBtn of clockButtons) {
    const row = rowFromClockButton(clockBtn, panel);
    if (!row) continue;

    const rowText = (row.innerText || "").trim();
    const rec = findRecordInRowText(rowText);
    if (!rec) continue;

    if (npSettings.creatorCodes) {
      queueCreatorLookup(rec);
      applyCreatorStatus(row, rec, clockBtn);
    }

    if (!npSettings.playerCards) continue;

    const existing = row.querySelector(`.${BTN_CLASS}`);
    if (existing) {
      existing.__npRecord = rec;
      row.setAttribute(ROW_MARK, String(rec.userId));
      continue;
    }

    try {
      injectButtonIntoRow(row, rec, clockBtn);
    } catch (err) {
      console.warn("[NP ShadowPopover] inject error:", err);
      continue;
    }

    row.setAttribute(ROW_MARK, String(rec.userId));
  }

  if (npSettings.playerCards) cleanupDuplicateOurButtons();
}

// Observe React DOM changes
let decorateTimer = null;
const scheduleDecorate = (delay = 45) => {
  clearTimeout(decorateTimer);
  decorateTimer = setTimeout(decorateAll, delay);
};
const obs = new MutationObserver(() => {
  scheduleDecorate();
  scheduleMapLayerSync();
});
obs.observe(document.documentElement, { childList: true, subtree: true });

// Noble uses client-side navigation, which does not always emit popstate.
// A lightweight route check makes session changes reset the host UI even when
// React reuses the existing players panel.
setInterval(() => {
  const route = currentCreatorSessionRoute();
  if (creatorSessionRouteKey && route !== creatorSessionRouteKey) {
    resetCreatorSession(route);
    scheduleDecorate(80);
  }
}, 500);

// initial pass
loadMapFilterModes();
scheduleDecorate(250);

try {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "local" && changes[NPSettings.STORAGE_KEY]) {
      applySharedSettings(changes[NPSettings.STORAGE_KEY].newValue);
    }
    if (area === "local" && changes[MAP_FILTER_STORAGE_KEY]) {
      mapFilterMode = sanitizeMapFilterMode(changes[MAP_FILTER_STORAGE_KEY].newValue);
      scheduleMapLayerSync(0);
    }
    if (area === "local" && changes[MATCH_ATTENDANCE_CACHE_KEY]) {
      matchAttendanceCache = changes[MATCH_ATTENDANCE_CACHE_KEY].newValue || null;
      if (npSettings.matchAttendance) scheduleDecorate(0);
    }
  });
} catch {}
