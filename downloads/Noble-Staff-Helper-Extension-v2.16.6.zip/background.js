"use strict";

// These two values are replaced with the production Worker deployment during
// packaging. The shared key is abuse protection, not a user credential.
const DEFAULT_HOST_SERVICE_URL = "https://noble-toolkit-hosts.noble-toolkit-sneeky.workers.dev";
const DEFAULT_HOST_SERVICE_KEY = "-bxd6C-ybJK8rzGBNVX3J5078UZQaFhG";
const HOST_SERVICE_CONFIG_KEY = "np_host_service_config_v1";

const CREATOR_CACHE_KEY = "np_creator_code_cache_v8";
const LEGACY_CREATOR_CACHE_KEY = "np_creator_code_cache_v7";
const POSITIVE_TTL = 90 * 24 * 60 * 60 * 1000;
const NEGATIVE_TTL = 12 * 60 * 60 * 1000;
const MAX_CACHE_ENTRIES = 2500;
const BATCH_DELAY_MS = 75;
// Leave headroom under the Workers Free 50-external-subrequest limit when a
// Noble payload contains names but no exact Epic account IDs.
const BATCH_LIMIT = 40;
const SERVICE_TIMEOUT_MS = 18_000;

let cachePromise = null;
let serviceConfigPromise = null;
let cachePersistTimer = null;
let cachePersistChain = Promise.resolve();
let cachePersistWaiters = [];
let remoteBatchTimer = null;

const inFlightCreatorLookups = new Map();
const pendingRemoteLookups = new Map();

function normalizeName(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function normalizeEpicId(value) {
  const clean = String(value || "").trim().toLowerCase().replace(/-/g, "");
  return /^[0-9a-f]{32}$/.test(clean) ? clean : "";
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, (items) => resolve(items || {})));
}

function storageSet(items) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(items, () => {
      if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
      else resolve();
    });
  });
}

function storageRemove(keys) {
  return new Promise((resolve) => chrome.storage.local.remove(keys, resolve));
}

function isConfiguredValue(value) {
  const clean = String(value || "").trim();
  return clean && !clean.startsWith("__NP_");
}

async function getServiceConfig() {
  if (!serviceConfigPromise) {
    serviceConfigPromise = storageGet([HOST_SERVICE_CONFIG_KEY]).then((items) => {
      const stored = items[HOST_SERVICE_CONFIG_KEY] || {};
      const url = String(stored.url || DEFAULT_HOST_SERVICE_URL).trim().replace(/\/+$/, "");
      const key = String(stored.key || DEFAULT_HOST_SERVICE_KEY).trim();
      return {
        url,
        key,
        configured: /^https:\/\/[^/]+/i.test(url) && isConfiguredValue(url) && isConfiguredValue(key)
      };
    });
  }
  return serviceConfigPromise;
}

async function creatorCache() {
  if (!cachePromise) {
    cachePromise = storageGet([CREATOR_CACHE_KEY, LEGACY_CREATOR_CACHE_KEY])
      .then((items) => {
        const current = items[CREATOR_CACHE_KEY];
        if (current && typeof current === "object") return current;

        const migrated = {};
        const legacy = items[LEGACY_CREATOR_CACHE_KEY];
        if (legacy && typeof legacy === "object") {
          for (const [key, entry] of Object.entries(legacy)) {
            if (entry?.hasCreatorCode && entry?.verified && entry?.code) {
              migrated[key] = { ...entry, source: entry.source || "verified-legacy" };
            }
          }
        }
        return migrated;
      })
      .catch(() => ({}));
  }
  return cachePromise;
}

function persistCacheSoon() {
  return new Promise((resolve) => {
    cachePersistWaiters.push(resolve);
    if (cachePersistTimer) return;

    cachePersistTimer = setTimeout(() => {
      cachePersistTimer = null;
      const waiters = cachePersistWaiters.splice(0);
      cachePersistChain = cachePersistChain
        .then(async () => {
          const cache = await creatorCache();
          await storageSet({ [CREATOR_CACHE_KEY]: cache });
        })
        .catch((error) => console.warn("[Noble Toolkit] Failed to persist host cache", error))
        .finally(() => waiters.forEach((done) => done()));
    }, 45);
  });
}

async function remember(keys, result) {
  const cache = await creatorCache();
  const entry = { ...result, checkedAt: Date.now() };
  for (const key of new Set(keys.filter(Boolean))) cache[key] = entry;

  const cacheKeys = Object.keys(cache);
  if (cacheKeys.length > MAX_CACHE_ENTRIES) {
    cacheKeys
      .sort((a, b) => Number(cache[b]?.checkedAt || 0) - Number(cache[a]?.checkedAt || 0))
      .slice(MAX_CACHE_ENTRIES)
      .forEach((oldKey) => delete cache[oldKey]);
  }

  await persistCacheSoon();
  return entry;
}

function publicResult(entry, cached = false) {
  return {
    ok: true,
    cached,
    hasCreatorCode: Boolean(entry?.hasCreatorCode),
    code: entry?.code || "",
    status: entry?.status || "",
    accountName: entry?.accountName || "",
    accountId: entry?.accountId || "",
    verified: Boolean(entry?.verified),
    source: entry?.source || "",
    checkedAt: Number(entry?.checkedAt || 0)
  };
}

async function fetchService(path, options = {}, timeout = SERVICE_TIMEOUT_MS) {
  const config = await getServiceConfig();
  if (!config.configured) {
    const error = new Error("Host service is not configured yet");
    error.code = "HOST_SERVICE_NOT_CONFIGURED";
    throw error;
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(`${config.url}${path}`, {
      ...options,
      signal: controller.signal,
      cache: "no-store",
      headers: {
        Accept: "application/json",
        "X-Noble-Key": config.key,
        ...(options.headers || {})
      }
    });
    const text = await response.text();
    let payload = null;
    if (text) {
      try {
        payload = JSON.parse(text);
      } catch {
        payload = null;
      }
    }
    if (!response.ok || !payload?.ok) {
      const error = new Error(payload?.error || `Host service returned ${response.status}`);
      error.status = response.status;
      throw error;
    }
    return payload;
  } finally {
    clearTimeout(timer);
  }
}

function remoteIdentity(displayName, epicAccountId) {
  return epicAccountId
    ? `id:${epicAccountId}`
    : `name:${normalizeName(displayName)}`;
}

function queueRemoteLookup(displayName, epicAccountId) {
  return new Promise((resolve, reject) => {
    const identity = remoteIdentity(displayName, epicAccountId);
    const existing = pendingRemoteLookups.get(identity);
    if (existing) {
      existing.waiters.push({ resolve, reject });
    } else {
      pendingRemoteLookups.set(identity, {
        requestId: identity,
        displayName,
        epicAccountId,
        waiters: [{ resolve, reject }]
      });
    }

    if (!remoteBatchTimer) {
      remoteBatchTimer = setTimeout(flushRemoteLookups, BATCH_DELAY_MS);
    }
  });
}

async function flushRemoteLookups() {
  remoteBatchTimer = null;
  const queued = [...pendingRemoteLookups.values()].slice(0, BATCH_LIMIT);
  for (const item of queued) pendingRemoteLookups.delete(item.requestId);
  if (!queued.length) return;

  if (pendingRemoteLookups.size && !remoteBatchTimer) {
    remoteBatchTimer = setTimeout(flushRemoteLookups, BATCH_DELAY_MS);
  }

  try {
    const payload = await fetchService("/v1/hosts/check", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        players: queued.map((item) => ({
          requestId: item.requestId,
          displayName: item.displayName,
          epicAccountId: item.epicAccountId
        }))
      })
    });
    const results = new Map(
      (Array.isArray(payload.results) ? payload.results : [])
        .map((result) => [String(result?.requestId || ""), result])
    );

    for (const item of queued) {
      const result = results.get(item.requestId);
      if (!result) {
        const error = new Error("Host service omitted a player result");
        for (const waiter of item.waiters) waiter.reject(error);
      } else if (!result.ok) {
        const error = new Error(result.error || "Epic account lookup failed");
        for (const waiter of item.waiters) waiter.reject(error);
      } else {
        for (const waiter of item.waiters) waiter.resolve(result);
      }
    }
  } catch (error) {
    for (const item of queued) {
      for (const waiter of item.waiters) waiter.reject(error);
    }
  }
}

async function requestCreatorCode(displayName, suppliedEpicId, baseKeys) {
  const remote = await queueRemoteLookup(displayName, suppliedEpicId);
  const accountId = normalizeEpicId(remote?.accountId);
  if (!accountId) throw new Error("Host service returned no Epic account ID");

  const cacheKeys = [...baseKeys, `id:${accountId}`];
  const entry = {
    hasCreatorCode: Boolean(remote.hasCreatorCode && remote.code),
    code: remote.hasCreatorCode ? String(remote.code || "").trim() : "",
    status: remote.hasCreatorCode ? "ACTIVE" : "NOT_FOUND",
    accountName: String(remote.displayName || displayName).trim(),
    accountId,
    verified: Boolean(remote.verified),
    source: remote.source || "host-service"
  };
  return publicResult(await remember(cacheKeys, entry));
}

async function lookupCreatorCode(displayName, epicAccountId) {
  const cleanName = String(displayName || "").trim();
  const normalizedName = normalizeName(cleanName);
  const suppliedEpicId = normalizeEpicId(epicAccountId);
  if (!normalizedName || cleanName.length > 100) {
    return { ok: false, error: "Invalid Epic display name" };
  }

  const nameKey = `name:${normalizedName}`;
  const idKey = suppliedEpicId ? `id:${suppliedEpicId}` : "";
  const cacheKeys = [nameKey, idKey].filter(Boolean);
  const cache = await creatorCache();
  const cached = (idKey && cache[idKey]) || cache[nameKey];
  if (cached) {
    const idMatches = !suppliedEpicId || !cached.accountId || cached.accountId === suppliedEpicId;
    const ttl = cached.hasCreatorCode ? POSITIVE_TTL : NEGATIVE_TTL;
    if (idMatches && Date.now() - Number(cached.checkedAt || 0) < ttl) {
      return publicResult(cached, true);
    }
  }

  const requestKey = idKey || nameKey;
  if (inFlightCreatorLookups.has(requestKey)) return inFlightCreatorLookups.get(requestKey);

  const request = requestCreatorCode(cleanName, suppliedEpicId, cacheKeys)
    .catch((error) => ({
      ok: false,
      code: error?.code || "",
      error: error?.name === "AbortError"
        ? "Host service timed out"
        : error?.message || "Host lookup failed"
    }))
    .finally(() => inFlightCreatorLookups.delete(requestKey));
  inFlightCreatorLookups.set(requestKey, request);
  return request;
}

async function hostServiceStatus() {
  const config = await getServiceConfig();
  if (!config.configured) {
    return { ok: true, configured: false, online: false };
  }
  try {
    const payload = await fetchService("/health", {}, 5_000);
    return {
      ok: true,
      configured: true,
      online: true,
      ready: Boolean(payload.configured)
    };
  } catch (error) {
    return {
      ok: true,
      configured: true,
      online: false,
      error: error?.message || "Host service unavailable"
    };
  }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "NP_CREATOR_CODE_LOOKUP") {
    lookupCreatorCode(message.displayName, message.epicAccountId).then(sendResponse);
    return true;
  }
  if (message?.type === "NP_HOST_SERVICE_STATUS") {
    hostServiceStatus().then(sendResponse);
    return true;
  }
  return false;
});

chrome.runtime.onInstalled.addListener(() => {
  // v2.6 briefly used per-user Epic device authentication. The centralized
  // service no longer needs or reads those local credentials. PR lookups were
  // removed in v2.12, so discard their obsolete local result caches as well.
  storageRemove([
    "np_epic_device_auth_v1",
    "np_epic_pending_auth_v1",
    "np_tracker_pr_cache_v1",
    "np_tracker_pr_cache_v2",
    "np_tracker_pr_cache_v3",
    "np_tracker_pr_cache_v4",
    "np_tracker_pr_cache_v5",
    "np_tracker_pr_cache_v6",
    "np_tracker_pr_cache_v7"
  ]).catch(() => {});
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes[CREATOR_CACHE_KEY]?.newValue == null) cachePromise = null;
  if (changes[HOST_SERVICE_CONFIG_KEY]) serviceConfigPromise = null;
});
