"use strict";

const ZNTURO_LOOKUP_URL = "https://znturo.com/api/lookup";
const OSIRION_ACCOUNT_URL = "https://fnapi.osirion.gg/v1/accounts/lookup-by-display-name";
const FORTNITE_STATS_URL = "https://fortnite-api.com/v2/stats/br/v2";
const FORTNITE_CREATOR_URL = "https://fortnite-api.com/v2/creatorcode";
const FORTNITE_API_KEY = "a44d6412-11d9-445f-9a4a-7e37f58d7f11";

const CREATOR_CACHE_KEY = "np_creator_code_cache_v5";
const POSITIVE_TTL = 7 * 24 * 60 * 60 * 1000;
const NEGATIVE_TTL = 30 * 60 * 1000;
const MAX_CACHE_ENTRIES = 2500;
const LOOKUP_TIMEOUT = 6500;

// Publicly confirmed hints only speed up discovery. A hint never produces a
// badge by itself: Fortnite-API must still return the exact Epic account ID and
// an ACTIVE code before the result is accepted.
const KNOWN_CREATOR_HINTS = new Map([
  ["e9aa015a81f44e39802764a53547f3e7", ["sneeky07"]]
]);

let cachePromise = null;
let cachePersistTimer = null;
let cachePersistChain = Promise.resolve();
let cachePersistWaiters = [];
const inFlight = new Map();

function makePool(limit) {
  const queue = [];
  let active = 0;

  function drain() {
    while (active < limit && queue.length) {
      const item = queue.shift();
      active++;
      Promise.resolve()
        .then(item.task)
        .then(item.resolve, item.reject)
        .finally(() => {
          active--;
          drain();
        });
    }
  }

  return (task) => new Promise((resolve, reject) => {
    queue.push({ task, resolve, reject });
    drain();
  });
}

// Znturo starts returning 429s during a full roster burst. Keep its requests
// bounded while letting the much faster creator-code checks run in parallel.
const runZnturo = makePool(3);
const runCreatorCheck = makePool(8);

function normalizeName(value) {
  return String(value || "")
    .normalize("NFKC")
    .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "")
    .replace(/\s+/g, " ")
    .trim()
    .toLowerCase();
}

function normalizeEpicId(value) {
  const clean = String(value || "").trim().toLowerCase();
  return /^[0-9a-f]{32}$/.test(clean) ? clean : "";
}

function normalizeCreatorCode(value) {
  return String(value || "").normalize("NFKC").trim().replace(/^@/, "").toLowerCase();
}

function storageGet(keys) {
  return new Promise((resolve) => chrome.storage.local.get(keys, (items) => resolve(items || {})));
}

function storageSet(items) {
  return new Promise((resolve, reject) => {
    chrome.storage.local.set(items, () => {
      if (chrome.runtime.lastError) reject(chrome.runtime.lastError);
      else resolve();
    });
  });
}

async function creatorCache() {
  if (!cachePromise) {
    cachePromise = storageGet(CREATOR_CACHE_KEY)
      .then((items) => {
        const value = items[CREATOR_CACHE_KEY];
        return value && typeof value === "object" ? value : {};
      })
      .catch(() => ({}));
  }
  return cachePromise;
}

function persistCacheSoon() {
  return new Promise((resolve) => {
    cachePersistWaiters.push(resolve);
    if (cachePersistTimer) return;

    cachePersistTimer = setTimeout(() => {
      cachePersistTimer = null;
      const waiters = cachePersistWaiters.splice(0);
      cachePersistChain = cachePersistChain
        .then(async () => {
          const cache = await creatorCache();
          await storageSet({ [CREATOR_CACHE_KEY]: cache });
        })
        .catch((error) => console.warn("[Noble Toolkit] Failed to persist creator cache", error))
        .finally(() => waiters.forEach((done) => done()));
    }, 45);
  });
}

async function remember(keys, result) {
  const cache = await creatorCache();
  const entry = { ...result, checkedAt: Date.now() };
  for (const key of new Set(keys.filter(Boolean))) cache[key] = entry;

  const cacheKeys = Object.keys(cache);
  if (cacheKeys.length > MAX_CACHE_ENTRIES) {
    cacheKeys
      .sort((a, b) => Number(cache[b]?.checkedAt || 0) - Number(cache[a]?.checkedAt || 0))
      .slice(MAX_CACHE_ENTRIES)
      .forEach((oldKey) => delete cache[oldKey]);
  }

  await persistCacheSoon();
  return entry;
}

function publicResult(entry, cached = false) {
  return {
    ok: true,
    cached,
    hasCreatorCode: Boolean(entry?.hasCreatorCode),
    code: entry?.code || "",
    status: entry?.status || "",
    accountName: entry?.accountName || "",
    accountId: entry?.accountId || "",
    verified: Boolean(entry?.verified),
    source: entry?.source || ""
  };
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function fetchJson(url, { timeout = LOOKUP_TIMEOUT, retries = 1, headers = {}, allow404 = false } = {}) {
  let lastError = null;

  for (let attempt = 0; attempt <= retries; attempt++) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);
    try {
      const response = await fetch(url, {
        signal: controller.signal,
        cache: "no-store",
        headers: { Accept: "application/json", ...headers }
      });

      if (allow404 && response.status === 404) return null;
      if (!response.ok) {
        const error = new Error(`Lookup returned ${response.status}`);
        error.status = response.status;
        const retryAfter = Number(response.headers.get("retry-after"));
        error.retryAfterMs = Number.isFinite(retryAfter) ? retryAfter * 1000 : 0;
        throw error;
      }
      return await response.json();
    } catch (error) {
      lastError = error;
      const retryable = error?.name !== "AbortError" && [429, 502, 503, 504].includes(error?.status);
      if (!retryable || attempt >= retries) throw error;
      await delay(Math.min(1400, Math.max(350, error.retryAfterMs || 500 * (attempt + 1))));
    } finally {
      clearTimeout(timer);
    }
  }

  throw lastError || new Error("Lookup failed");
}

async function resolveAccountWithFortniteApi(displayName) {
  const url = `${FORTNITE_STATS_URL}?name=${encodeURIComponent(displayName)}`;
  const payload = await fetchJson(url, {
    headers: { Authorization: FORTNITE_API_KEY },
    timeout: LOOKUP_TIMEOUT,
    retries: 1
  });
  const accountId = normalizeEpicId(payload?.data?.account?.id);
  const accountName = String(payload?.data?.account?.name || "").trim();
  if (!accountId) throw new Error("Fortnite-API did not return an Epic account ID");
  if (accountName && normalizeName(accountName) !== normalizeName(displayName)) {
    throw new Error("Fortnite-API returned a different Epic account");
  }
  return { accountId, displayName: accountName || displayName };
}

async function resolveAccountWithOsirion(displayName) {
  const url = `${OSIRION_ACCOUNT_URL}?displayName=${encodeURIComponent(displayName)}`;
  const payload = await fetchJson(url, { timeout: LOOKUP_TIMEOUT, retries: 1 });
  const accounts = Array.isArray(payload?.accounts) ? payload.accounts : [];
  const exact = accounts.find((item) => normalizeName(item?.accountDetails?.epic) === normalizeName(displayName));
  const accountId = normalizeEpicId(exact?.accountId || payload?.accountId);
  const accountName = String(exact?.accountDetails?.epic || payload?.accountDetails?.epic || "").trim();
  if (!accountId) throw new Error("Osirion did not return an Epic account ID");
  if (accountName && normalizeName(accountName) !== normalizeName(displayName)) {
    throw new Error("Osirion returned a different Epic account");
  }
  return { accountId, displayName: accountName || displayName };
}

async function resolveAccount(displayName, suppliedEpicId) {
  if (suppliedEpicId) return { accountId: suppliedEpicId, displayName };
  try {
    return await resolveAccountWithFortniteApi(displayName);
  } catch (primaryError) {
    try {
      return await resolveAccountWithOsirion(displayName);
    } catch {
      try {
        const znturo = await lookupZnturoByName(displayName);
        return { accountId: znturo.accountId, displayName: znturo.displayName || displayName, znturo };
      } catch {
        throw primaryError;
      }
    }
  }
}

async function lookupZnturoByName(displayName) {
  return runZnturo(async () => {
    const url = `${ZNTURO_LOOKUP_URL}?q=${encodeURIComponent(displayName)}&type=epic`;
    const payload = await fetchJson(url, { timeout: LOOKUP_TIMEOUT, retries: 2 });
    const accountId = normalizeEpicId(payload?.id);
    const returnedName = String(payload?.displayName || "").trim();
    if (!accountId || normalizeName(returnedName) !== normalizeName(displayName)) {
      throw new Error("Znturo returned a different Epic account");
    }
    const externalNames = Object.values(payload?.externalAuths || {})
      .map((item) => String(item?.externalDisplayName || "").trim())
      .filter(Boolean);
    return {
      accountId,
      displayName: returnedName,
      creatorCode: String(payload?.creatorCode || "").trim(),
      externalNames
    };
  });
}

async function lookupZnturoById(accountId) {
  return runZnturo(async () => {
    const url = `${ZNTURO_LOOKUP_URL}?q=${encodeURIComponent(accountId)}&type=epicId`;
    const payload = await fetchJson(url, { timeout: LOOKUP_TIMEOUT, retries: 2 });
    const returnedId = normalizeEpicId(payload?.id);
    if (!returnedId || returnedId !== accountId) throw new Error("Znturo returned a different Epic account");
    const externalNames = Object.values(payload?.externalAuths || {})
      .map((item) => String(item?.externalDisplayName || "").trim())
      .filter(Boolean);
    return {
      accountId: returnedId,
      displayName: String(payload?.displayName || "").trim(),
      creatorCode: String(payload?.creatorCode || "").trim(),
      externalNames
    };
  });
}

function addCandidate(target, value) {
  const code = normalizeCreatorCode(value);
  if (/^[a-z0-9][a-z0-9._-]{1,14}[a-z0-9]$/.test(code)) target.add(code);
}

function candidateCodes(...names) {
  const result = new Set();
  const stopWords = new Set(["use", "code", "creator", "official", "real"]);

  for (const rawName of names.flat()) {
    const ascii = String(rawName || "")
      .normalize("NFKD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
    const words = ascii.split(/[^a-z0-9]+/).filter(Boolean);
    if (!words.length) continue;

    const useful = words.filter((word) => !stopWords.has(word));
    const bases = useful.length ? useful : words;
    addCandidate(result, bases.join(""));
    for (const word of bases) addCandidate(result, word);
    for (let index = 0; index < Math.min(3, bases.length); index++) {
      const base = bases[index].replace(/^(?:ttv|twitch|yt|youtube|tiktok)/, "");
      if (base.length < 3) continue;
      addCandidate(result, base);
      addCandidate(result, `${base}fn`);
      addCandidate(result, `${base}ftn`);
      addCandidate(result, `${base}fnbr`);
    }
    addCandidate(result, bases.join("-"));
    addCandidate(result, bases.join("_"));
    addCandidate(result, bases.join("."));
  }

  return [...result].slice(0, 12);
}

async function lookupCreatorCodeCandidate(code) {
  return runCreatorCheck(async () => {
    const url = `${FORTNITE_CREATOR_URL}?name=${encodeURIComponent(code)}`;
    const payload = await fetchJson(url, { timeout: 4200, retries: 1, allow404: true });
    if (!payload?.data) return null;
    return {
      code: String(payload.data.code || code).trim(),
      accountId: normalizeEpicId(payload.data.account?.id),
      accountName: String(payload.data.account?.name || "").trim(),
      status: String(payload.data.status || "").toUpperCase()
    };
  });
}

async function findVerifiedCode(candidates, accountId) {
  const unique = [...new Set(candidates.map(normalizeCreatorCode).filter(Boolean))];
  if (!unique.length) return null;

  const settled = await Promise.allSettled(unique.map((code) => lookupCreatorCodeCandidate(code)));
  for (const item of settled) {
    if (item.status !== "fulfilled") continue;
    const match = item.value;
    if (match?.status === "ACTIVE" && match.accountId === accountId) return match;
  }
  return null;
}

function positiveEntry(account, match, source) {
  return {
    hasCreatorCode: true,
    code: match.code,
    status: "ACTIVE",
    accountName: account.displayName || match.accountName,
    accountId: account.accountId,
    verified: true,
    source
  };
}

async function requestCreatorCode(displayName, suppliedEpicId, baseKeys) {
  const account = await resolveAccount(displayName, suppliedEpicId);
  const cacheKeys = [...baseKeys, `id:${account.accountId}`];

  const hints = KNOWN_CREATOR_HINTS.get(account.accountId) || [];
  const hintedMatch = await findVerifiedCode(hints, account.accountId);
  if (hintedMatch) {
    return publicResult(await remember(cacheKeys, positiveEntry(account, hintedMatch, "verified-hint")));
  }

  const znturoPromise = account.znturo
    ? Promise.resolve(account.znturo)
    : lookupZnturoById(account.accountId).catch(() => null);
  const directMatch = await findVerifiedCode(candidateCodes(account.displayName, displayName), account.accountId);
  if (directMatch) {
    return publicResult(await remember(cacheKeys, positiveEntry(account, directMatch, "fortnite-api")));
  }

  const znturo = await znturoPromise;
  if (znturo?.creatorCode) {
    const znturoMatch = await findVerifiedCode([znturo.creatorCode], account.accountId);
    if (znturoMatch) {
      return publicResult(await remember(cacheKeys, positiveEntry(account, znturoMatch, "znturo+fortnite-api")));
    }
  }

  const linkedMatch = await findVerifiedCode(
    candidateCodes(znturo?.displayName, znturo?.externalNames || []).slice(0, 8),
    account.accountId
  );
  if (linkedMatch) {
    return publicResult(await remember(cacheKeys, positiveEntry(account, linkedMatch, "linked-name+fortnite-api")));
  }

  return publicResult(await remember(cacheKeys, {
    hasCreatorCode: false,
    code: "",
    status: "NOT_FOUND",
    accountName: account.displayName || displayName,
    accountId: account.accountId,
    verified: true,
    source: znturo ? "fortnite-api+znturo" : "fortnite-api"
  }));
}

async function lookupCreatorCode(displayName, epicAccountId) {
  const cleanName = String(displayName || "").trim();
  const normalizedName = normalizeName(cleanName);
  const suppliedEpicId = normalizeEpicId(epicAccountId);
  if (!normalizedName || cleanName.length > 100) return { ok: false, error: "Invalid display name" };

  const nameKey = `name:${normalizedName}`;
  const idKey = suppliedEpicId ? `id:${suppliedEpicId}` : "";
  const cacheKeys = [nameKey, idKey].filter(Boolean);
  const cache = await creatorCache();
  const cached = (idKey && cache[idKey]) || cache[nameKey];
  if (cached) {
    const idMatches = !suppliedEpicId || !cached.accountId || cached.accountId === suppliedEpicId;
    const ttl = cached.hasCreatorCode ? POSITIVE_TTL : NEGATIVE_TTL;
    if (idMatches && Date.now() - Number(cached.checkedAt || 0) < ttl) return publicResult(cached, true);
  }

  const requestKey = idKey || nameKey;
  if (inFlight.has(requestKey)) return inFlight.get(requestKey);

  const request = requestCreatorCode(cleanName, suppliedEpicId, cacheKeys)
    .catch((error) => ({
      ok: false,
      error: error?.name === "AbortError" ? "Creator lookup timed out" : error?.message || "Creator lookup failed"
    }))
    .finally(() => inFlight.delete(requestKey));
  inFlight.set(requestKey, request);
  return request;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "NP_CREATOR_CODE_LOOKUP") return false;
  lookupCreatorCode(message.displayName, message.epicAccountId).then(sendResponse);
  return true;
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[CREATOR_CACHE_KEY]?.newValue == null) cachePromise = null;
});
