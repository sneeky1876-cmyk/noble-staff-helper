// Shared settings and page-mode detection for Noble Toolkit.
(() => {
  "use strict";

  const STORAGE_KEY = "np_settings_v2";
  const MODES = ["solo", "duo", "trio", "squad", "ladder", "other"];
  const MODE_LABELS = {
    solo: "Solo",
    duo: "Duo",
    trio: "Trio",
    squad: "Squad",
    ladder: "Ladder",
    other: "Other"
  };

  const DEFAULTS = Object.freeze({
    bottomCounts: Object.freeze({ solo: 5, duo: 5, trio: 5, squad: 5, ladder: 5, other: 5 }),
    minMatches: Object.freeze({ solo: 3, duo: 3, trio: 3, squad: 3, ladder: 5, other: 3 }),
    playerCards: true,
    creatorCodes: true,
    mapCopy: true,
    leaderboardTools: true,
    rowActions: true,
    animations: true
  });

  function clampInt(value, min, max, fallback) {
    const parsed = Number.parseInt(value, 10);
    if (!Number.isFinite(parsed)) return fallback;
    return Math.max(min, Math.min(max, parsed));
  }

  function cloneDefaults() {
    return {
      bottomCounts: { ...DEFAULTS.bottomCounts },
      minMatches: { ...DEFAULTS.minMatches },
      playerCards: DEFAULTS.playerCards,
      creatorCodes: DEFAULTS.creatorCodes,
      mapCopy: DEFAULTS.mapCopy,
      leaderboardTools: DEFAULTS.leaderboardTools,
      rowActions: DEFAULTS.rowActions,
      animations: DEFAULTS.animations
    };
  }

  function sanitize(input) {
    const clean = cloneDefaults();
    const source = input && typeof input === "object" ? input : {};

    for (const mode of MODES) {
      clean.bottomCounts[mode] = clampInt(source.bottomCounts?.[mode], 1, 25, DEFAULTS.bottomCounts[mode]);
      clean.minMatches[mode] = clampInt(source.minMatches?.[mode], 0, 20, DEFAULTS.minMatches[mode]);
    }

    for (const key of ["playerCards", "creatorCodes", "mapCopy", "leaderboardTools", "rowActions", "animations"]) {
      if (typeof source[key] === "boolean") clean[key] = source[key];
    }

    return clean;
  }

  function storageGet(key) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(key, (items) => resolve(items || {}));
      } catch {
        resolve({});
      }
    });
  }

  async function load() {
    const stored = await storageGet(STORAGE_KEY);
    return sanitize(stored[STORAGE_KEY]);
  }

  async function save(settings) {
    const clean = sanitize(settings);
    await new Promise((resolve, reject) => {
      try {
        chrome.storage.local.set({ [STORAGE_KEY]: clean }, () => {
          const err = chrome.runtime?.lastError;
          if (err) reject(err);
          else resolve();
        });
      } catch (error) {
        reject(error);
      }
    });
    return clean;
  }

  function pageText(doc = document, loc = location) {
    const heading = Array.from(doc.querySelectorAll("h1, h2"))
      .slice(0, 4)
      .map((el) => el.textContent || "")
      .join(" ");
    const primary = `${doc.title || ""} ${loc.pathname || ""} ${loc.search || ""} ${heading}`.toLowerCase();
    if (primary.trim()) return primary;
    return (doc.body?.innerText || "").slice(0, 1600).toLowerCase();
  }

  function detectMode(doc = document, loc = location) {
    const text = pageText(doc, loc);
    if (/\bladders?\b/.test(text)) return "ladder";
    if (/\bsolos?\b/.test(text)) return "solo";
    if (/\bduos?\b/.test(text)) return "duo";
    if (/\btrios?\b/.test(text)) return "trio";
    if (/\bsquads?\b/.test(text)) return "squad";

    // Some pages only expose the team size lower in the rendered body.
    const body = (doc.body?.innerText || "").slice(0, 2200).toLowerCase();
    if (/\bladders?\b/.test(body)) return "ladder";
    if (/\bsolos?\b/.test(body)) return "solo";
    if (/\bduos?\b/.test(body)) return "duo";
    if (/\btrios?\b/.test(body)) return "trio";
    if (/\bsquads?\b/.test(body)) return "squad";
    return "other";
  }

  function modeConfig(settings, mode = detectMode()) {
    const clean = sanitize(settings);
    const key = MODES.includes(mode) ? mode : "other";
    return {
      mode: key,
      label: MODE_LABELS[key],
      bottomCount: clean.bottomCounts[key],
      minMatches: clean.minMatches[key]
    };
  }

  globalThis.NPSettings = Object.freeze({
    STORAGE_KEY,
    MODES: Object.freeze([...MODES]),
    MODE_LABELS: Object.freeze({ ...MODE_LABELS }),
    DEFAULTS,
    cloneDefaults,
    sanitize,
    load,
    save,
    detectMode,
    modeConfig
  });
})();
