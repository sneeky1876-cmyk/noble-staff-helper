// Runs at document_start so the page-world bridge is installed before NoblePrac opens its socket.
(() => {
  "use strict";

  const token = Array.from(crypto.getRandomValues(new Uint32Array(4)), (n) => n.toString(36)).join("-");
  globalThis.__NP_HELPER_CHANNEL__ = token;

  function inject() {
    const root = document.head || document.documentElement;
    if (!root) return false;

    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("page.js");
    script.dataset.npChannel = token;
    script.async = false;
    script.onload = () => script.remove();
    script.onerror = () => script.remove();
    root.appendChild(script);
    return true;
  }

  if (!inject()) {
    const observer = new MutationObserver(() => {
      if (inject()) observer.disconnect();
    });
    observer.observe(document, { childList: true, subtree: true });
  }
})();
