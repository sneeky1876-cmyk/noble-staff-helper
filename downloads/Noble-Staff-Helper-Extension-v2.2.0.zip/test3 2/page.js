// Page-world bridge: observes NoblePrac WebSocket JSON and forwards relevant payloads.
(() => {
  "use strict";

  const TAG = "__NP_HELPER__";
  const channel = document.currentScript?.dataset?.npChannel || "";
  if (!channel || window.__np_ws_patched) return;
  window.__np_ws_patched = true;

  const NativeWebSocket = window.WebSocket;
  if (typeof NativeWebSocket !== "function") return;

  function post(payload) {
    window.postMessage({
      [TAG]: true,
      channel,
      type: "NP_WS_JSON",
      payload
    }, location.origin);
  }

  function isRelevant(payload) {
    if (!payload || typeof payload !== "object") return false;
    return Boolean(
      Array.isArray(payload.teams) ||
      Array.isArray(payload.drops) ||
      Array.isArray(payload.data?.teams) ||
      Array.isArray(payload.data?.drops) ||
      Array.isArray(payload.payload?.teams) ||
      Array.isArray(payload.payload?.drops)
    );
  }

  function parseText(text) {
    try {
      const parsed = JSON.parse(text);
      if (isRelevant(parsed)) post(parsed);
    } catch {
      // NoblePrac also sends non-JSON socket frames; ignore those.
    }
  }

  function handleMessage(event) {
    const data = event.data;
    if (typeof data === "string") {
      parseText(data);
      return;
    }

    if (data instanceof ArrayBuffer) {
      try {
        parseText(new TextDecoder("utf-8").decode(new Uint8Array(data)));
      } catch {}
      return;
    }

    if (data instanceof Blob) {
      data.text().then(parseText).catch(() => {});
    }
  }

  function observeSocket(socket) {
    // One independent listener avoids duplicate forwarding and does not interfere
    // with the page's add/removeEventListener or onmessage behavior.
    NativeWebSocket.prototype.addEventListener.call(socket, "message", handleMessage);
    return socket;
  }

  const WebSocketProxy = new Proxy(NativeWebSocket, {
    construct(target, args, newTarget) {
      const constructor = newTarget === WebSocketProxy ? target : newTarget;
      return observeSocket(Reflect.construct(target, args, constructor));
    },
    apply(target, thisArg, args) {
      // Preserve the native error when WebSocket is called without `new`.
      return Reflect.apply(target, thisArg, args);
    }
  });

  window.WebSocket = WebSocketProxy;
  console.debug("[Noble Toolkit] WebSocket bridge active");
})();
