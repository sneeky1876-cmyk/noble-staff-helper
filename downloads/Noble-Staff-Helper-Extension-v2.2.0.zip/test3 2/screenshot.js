// Captures and caches the initial full Leaflet view, then copies it without
// moving or zooming the live map.
(() => {
  "use strict";

  const BTN_ID = "np-ext-copy-map-btn";
  const WRAP_ID = "np-ext-copy-map-wrap";
  const TOAST_ID = "np-ext-copy-map-toast";
  const MAX_CANVAS_PIXELS = 14_000_000;
  const MAX_CAPTURE_SCALE = 2;
  const MIN_CAPTURE_SCALE = 1.75;
  const READY_TIMEOUT = 8_000;
  const QUIET_WINDOW = 300;
  const MIN_READY_AGE = 550;
  const TEAM_FALLBACK_AGE = 1_800;

  let settings = NPSettings.cloneDefaults();
  let activeState = null;
  let generation = 0;
  let copyInProgress = false;
  let cachedBadgeRow = null;
  let lastRoute = null;

  const wait = (milliseconds) => new Promise((resolve) => setTimeout(resolve, milliseconds));
  const sessionKey = () => `${location.pathname}${location.search}`;
  const isSessionMapPage = () => /^\/sessions\/[^/?#]+/i.test(location.pathname);
  lastRoute = sessionKey();

  function visibleMapElements() {
    return Array.from(document.querySelectorAll(".leaflet-container, [class*='leaflet-container']"))
      .filter((element) => {
        const rect = element.getBoundingClientRect();
        const style = getComputedStyle(element);
        return rect.width >= 280 && rect.height >= 240 && style.display !== "none" && style.visibility !== "hidden";
      })
      .sort((a, b) => {
        const ar = a.getBoundingClientRect();
        const br = b.getBoundingClientRect();
        return br.width * br.height - ar.width * ar.height;
      });
  }

  function findMapElement() {
    return visibleMapElements()[0] || null;
  }

  function toast(message) {
    let element = document.getElementById(TOAST_ID);
    if (!element) {
      element = document.createElement("div");
      element.id = TOAST_ID;
      Object.assign(element.style, {
        position: "fixed", left: "50%", bottom: "24px", transform: "translateX(-50%)", zIndex: "2147483647",
        padding: "9px 12px", border: "1px solid rgba(255,191,64,.32)", borderRadius: "7px",
        color: "#fff", background: "#0f1c25", boxShadow: "0 10px 30px rgba(0,0,0,.35)",
        font: "600 12px/1.35 system-ui,-apple-system,Segoe UI,sans-serif", display: "none", pointerEvents: "none"
      });
      document.body.appendChild(element);
    }
    element.textContent = message;
    element.style.display = "block";
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { element.style.display = "none"; }, 1900);
  }

  function mapButtonMarkup(label = "Copy Map") {
    return `
      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="m9 18-6 3V6l6-3 6 3 6-3v15l-6 3-6-3Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/>
        <path d="M9 3v15m6-12v15" stroke="currentColor" stroke-width="1.8"/>
      </svg>
      <span>${label}</span>
    `;
  }

  function updateButton() {
    const button = document.getElementById(BTN_ID);
    if (!button || copyInProgress) return;
    const ready = Boolean(activeState?.blob);
    // Avoid replacing identical children: the page-level MutationObserver
    // would otherwise schedule this function again forever.
    if (!button.querySelector("svg") || button.querySelector("span")?.textContent !== "Copy Map") {
      button.innerHTML = mapButtonMarkup();
    }
    button.disabled = false;
    button.classList.toggle("np-map-snapshot-ready", Boolean(ready));
    button.title = ready
      ? "Copy the full map captured when this session loaded"
      : activeState?.status === "failed" || activeState?.status === "missed"
        ? "Full-map snapshot unavailable; refresh the session before zooming"
        : "The initial full-map snapshot is being prepared";
  }

  function makeButton() {
    const button = document.createElement("button");
    button.id = BTN_ID;
    button.type = "button";
    button.innerHTML = mapButtonMarkup();
    Object.assign(button.style, {
      display: "inline-flex", alignItems: "center", justifyContent: "center", gap: "7px", minHeight: "34px",
      padding: "8px 11px", border: "1px solid rgba(255,255,255,.14)", borderRadius: "6px",
      color: "#fff", background: "#131e27", cursor: "pointer", userSelect: "none",
      font: "600 12px/1 system-ui,-apple-system,Segoe UI,sans-serif", whiteSpace: "nowrap"
    });
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      copyCachedMap(button);
    });
    return button;
  }

  function textHas(element, needle) {
    return (element?.innerText || "").toLowerCase().includes(needle);
  }

  function findBadgeRow() {
    if (
      cachedBadgeRow?.isConnected &&
      textHas(cachedBadgeRow, "contested drops") &&
      textHas(cachedBadgeRow, "teams marked")
    ) return cachedBadgeRow;

    let best = null;
    let smallestArea = Infinity;
    for (const element of document.querySelectorAll("div, header, nav, section")) {
      const text = (element.innerText || "").toLowerCase();
      if (!text.includes("contested drops") || !text.includes("teams marked")) continue;
      const rect = element.getBoundingClientRect();
      if (rect.width < 200 || rect.height < 20 || rect.height > 160) continue;
      const area = rect.width * rect.height;
      if (area < smallestArea) {
        best = element;
        smallestArea = area;
      }
    }
    if (best) {
      cachedBadgeRow = best;
      return best;
    }

    const contested = Array.from(document.querySelectorAll("button, a, div, span")).find((element) => textHas(element, "contested drops"));
    for (let current = contested, depth = 0; current && depth < 10; current = current.parentElement, depth++) {
      if (!textHas(current, "teams marked")) continue;
      const rect = current.getBoundingClientRect();
      if (rect.width > 200 && rect.height > 20 && rect.height < 160) {
        cachedBadgeRow = current;
        return current;
      }
    }
    return null;
  }

  function removeButton() {
    document.getElementById(WRAP_ID)?.remove();
    document.getElementById(BTN_ID)?.remove();
  }

  function placeButton() {
    if (!settings.mapCopy || !isSessionMapPage()) {
      removeButton();
      return;
    }
    if (document.getElementById(BTN_ID)) {
      updateButton();
      return;
    }
    const row = findBadgeRow();
    if (!row) return;

    const wrapper = document.createElement("span");
    wrapper.id = WRAP_ID;
    Object.assign(wrapper.style, { display: "inline-flex", alignItems: "center", flex: "0 0 auto", marginRight: "6px" });
    wrapper.appendChild(makeButton());

    const computed = getComputedStyle(row);
    if (computed.display !== "flex" && computed.display !== "inline-flex") row.style.display = "flex";
    row.style.alignItems ||= "center";
    row.style.gap ||= "10px";
    row.insertAdjacentElement("afterbegin", wrapper);
    updateButton();
  }

  function teamStatus() {
    const row = findBadgeRow();
    const text = row?.innerText || "";
    const match = text.match(/(\d+)\s*\/\s*(\d+)\s*Teams Marked/i);
    return match ? { marked: Number(match[1]), total: Number(match[2]) } : null;
  }

  function teamStatusText() {
    const status = teamStatus();
    return status ? `${status.marked}/${status.total}` : "";
  }

  function viewSignature(mapElement) {
    const selectors = [
      ".leaflet-map-pane",
      ".leaflet-overlay-pane",
      ".leaflet-marker-pane",
      ".leaflet-shadow-pane"
    ];
    return selectors.map((selector) => {
      const element = mapElement.querySelector(selector);
      return `${selector}:${element?.getAttribute("style") || ""}`;
    }).join("|");
  }

  function contentSignature(mapElement) {
    const overlays = Array.from(mapElement.querySelectorAll(".leaflet-overlay-pane img, img.leaflet-image-layer"));
    const markers = Array.from(mapElement.querySelectorAll(".leaflet-marker-pane img, .leaflet-marker-icon"));
    const paths = Array.from(mapElement.querySelectorAll(".leaflet-overlay-pane path, .leaflet-marker-pane path"));
    return [
      viewSignature(mapElement),
      teamStatusText(),
      overlays.map((image) => `${image.currentSrc || image.src}|${image.complete}|${image.naturalWidth}|${image.getAttribute("style") || ""}`).join(","),
      markers.map((image) => `${image.currentSrc || image.src}|${image.getAttribute("style") || ""}|${image.textContent || ""}`).join(","),
      paths.map((path) => path.getAttribute("d") || "").join(",")
    ].join("||");
  }

  function allImagesReady(mapElement, visibleElapsed) {
    const overlays = Array.from(mapElement.querySelectorAll(".leaflet-overlay-pane img, img.leaflet-image-layer"));
    if (!overlays.length) return false;
    const markerImages = Array.from(mapElement.querySelectorAll(".leaflet-marker-pane img"));
    const overlaysReady = overlays.every((image) => image.complete && image.naturalWidth > 0);
    if (!overlaysReady) return false;

    // A single expired Discord avatar used to block large 24/7 sessions
    // forever. Wait for marker requests to settle, but do not require every
    // remote avatar to decode successfully before the map itself can capture.
    const markersSettled = markerImages.every((image) => image.complete);
    return markersSettled || visibleElapsed >= 2_200;
  }

  function stateIsCurrent(state) {
    return activeState === state && state.generation === generation && state.key === sessionKey() && state.mapElement.isConnected;
  }

  async function waitForInitialMap(state) {
    let remaining = READY_TIMEOUT;
    let visibleElapsed = 0;
    let previousTick = performance.now();
    let lastSignature = "";
    let quietSince = 0;

    while (remaining > 0) {
      if (!stateIsCurrent(state)) throw new Error("Session changed");
      if (state.userInteracted) throw new Error("Initial map view was changed");

      const mapElement = state.mapElement;
      const rect = mapElement.getBoundingClientRect();
      const now = performance.now();
      const documentVisible = document.visibilityState !== "hidden";
      const elapsed = now - previousTick;
      previousTick = now;
      if (documentVisible) {
        remaining -= elapsed;
        visibleElapsed += elapsed;
      }
      const visible = documentVisible && rect.width >= 280 && rect.height >= 240;
      const stable = !mapElement.classList.contains("leaflet-zoom-anim");
      const signature = contentSignature(mapElement);
      if (signature !== lastSignature) {
        lastSignature = signature;
        quietSince = performance.now();
      }

      const teams = teamStatus();
      const markerCount = mapElement.querySelectorAll(".leaflet-marker-pane .leaflet-marker-icon").length;
      const hasTeamState = teams
        ? teams.marked > 0
          ? markerCount >= teams.marked
          : visibleElapsed >= 900
        : visibleElapsed > TEAM_FALLBACK_AGE;
      if (
        visible &&
        stable &&
        visibleElapsed >= MIN_READY_AGE &&
        allImagesReady(mapElement, visibleElapsed) &&
        hasTeamState &&
        performance.now() - quietSince >= QUIET_WINDOW
      ) {
        return signature;
      }
      await wait(60);
    }
    throw new Error("Map assets did not finish loading");
  }

  function captureScale(mapElement) {
    const rect = mapElement.getBoundingClientRect();
    const desired = Math.min(MAX_CAPTURE_SCALE, Math.max(MIN_CAPTURE_SCALE, window.devicePixelRatio || 1));
    const pixelLimitScale = Math.sqrt(MAX_CANVAS_PIXELS / Math.max(1, rect.width * rect.height));
    return Math.min(desired, pixelLimitScale);
  }

  function canvasToBlob(canvas) {
    return new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
  }

  function canvasLooksUsable(canvas) {
    if (!canvas || canvas.width < 280 || canvas.height < 240) return false;
    try {
      const context = canvas.getContext("2d", { willReadFrequently: true });
      if (!context) return false;
      let opaque = 0;
      const colors = new Set();
      for (let y = 1; y <= 6; y++) {
        for (let x = 1; x <= 8; x++) {
          const px = Math.min(canvas.width - 1, Math.floor((canvas.width * x) / 9));
          const py = Math.min(canvas.height - 1, Math.floor((canvas.height * y) / 7));
          const data = context.getImageData(px, py, 1, 1).data;
          if (data[3] > 32) opaque++;
          colors.add(`${data[0] >> 4}:${data[1] >> 4}:${data[2] >> 4}:${data[3] >> 5}`);
        }
      }
      return opaque >= 28 && colors.size >= 4;
    } catch {
      return false;
    }
  }

  function freezeClonedMap(clonedDocument, mapElement, captureRect) {
    const clone = mapElement.id
      ? clonedDocument.getElementById(mapElement.id)
      : clonedDocument.querySelector(".leaflet-container");
    if (!clone) return;
    clone.classList.remove("leaflet-zoom-anim", "leaflet-touching");
    Object.assign(clone.style, {
      width: `${captureRect.width}px`,
      height: `${captureRect.height}px`,
      minWidth: `${captureRect.width}px`,
      minHeight: `${captureRect.height}px`,
      maxWidth: `${captureRect.width}px`,
      maxHeight: `${captureRect.height}px`,
      boxSizing: "border-box",
      overflow: "hidden"
    });
    for (const element of [clone, ...clone.querySelectorAll("*")]) {
      element.style.animation = "none";
      element.style.transition = "none";
      element.style.caretColor = "transparent";
      element.style.transformOrigin = "0 0";
      element.style.willChange = "auto";
    }
  }

  async function captureInitialSnapshot(state, isRefresh = false) {
    if (!stateIsCurrent(state) || state.capturePromise) return state?.capturePromise;
    state.status = isRefresh && state.blob ? "refreshing" : "preparing";
    updateButton();

    state.capturePromise = (async () => {
      const expectedContent = await waitForInitialMap(state);
      if (document.fonts?.ready) await Promise.race([document.fonts.ready, wait(150)]);
      if (!stateIsCurrent(state) || state.userInteracted) throw new Error("Initial map view changed");

      const expectedView = viewSignature(state.mapElement);
      const captureRect = state.mapElement.getBoundingClientRect();
      const scale = captureScale(state.mapElement);
      const canvas = await window.html2canvas(state.mapElement, {
        backgroundColor: "#0a1520",
        scale,
        width: Math.round(captureRect.width),
        height: Math.round(captureRect.height),
        windowWidth: document.documentElement.clientWidth,
        windowHeight: document.documentElement.clientHeight,
        scrollX: window.scrollX,
        scrollY: window.scrollY,
        useCORS: true,
        allowTaint: false,
        logging: false,
        imageTimeout: 2500,
        onclone: (clonedDocument) => freezeClonedMap(clonedDocument, state.mapElement, captureRect),
        ignoreElements: (element) =>
          element.classList?.contains("leaflet-control-container") ||
          element.id === TOAST_ID ||
          element.id === BTN_ID ||
          element.id === WRAP_ID
      });

      if (
        !stateIsCurrent(state) ||
        state.userInteracted ||
        viewSignature(state.mapElement) !== expectedView ||
        contentSignature(state.mapElement) !== expectedContent
      ) {
        throw new Error("Map changed while the snapshot was being created");
      }

      if (!canvasLooksUsable(canvas)) throw new Error("Snapshot canvas was blank or incomplete");

      const blob = await canvasToBlob(canvas);
      if (!blob) throw new Error("PNG encoding failed");
      state.blob = blob;
      state.fullViewSignature = expectedView;
      state.status = "ready";
      state.error = null;
    })()
      .catch((error) => {
        state.error = error;
        const mayRetry =
          !state.blob &&
          /changed while|blank|incomplete/i.test(error.message) &&
          stateIsCurrent(state) &&
          !state.userInteracted &&
          state.retryCount < 3;

        if (mayRetry) {
          state.retryCount++;
          state.status = "waiting";
          setTimeout(() => {
            if (stateIsCurrent(state) && !state.capturePromise) captureInitialSnapshot(state);
          }, 280);
          return;
        }
        if (!state.blob) {
          state.status = /changed|missed/i.test(error.message) ? "missed" : "failed";
          console.warn("[Noble Toolkit] Initial map snapshot unavailable", error);
        } else {
          state.status = "ready";
          console.debug("[Noble Toolkit] Kept previous map snapshot after refresh failed", error);
        }
      })
      .finally(() => {
        state.capturePromise = null;
        updateButton();
      });

    return state.capturePromise;
  }

  function mutationAffectsMapContent(mutation) {
    const target = mutation.target instanceof Element ? mutation.target : mutation.target?.parentElement;
    if (!target) return false;
    return Boolean(target.closest(".leaflet-overlay-pane, .leaflet-marker-pane, .leaflet-shadow-pane"));
  }

  function observeState(state) {
    const markInteraction = () => { state.userInteracted = true; };
    for (const type of ["pointerdown", "wheel", "touchstart", "keydown"]) {
      state.mapElement.addEventListener(type, markInteraction, { capture: true, passive: true });
    }

    state.observer = new MutationObserver((mutations) => {
      if (!stateIsCurrent(state) || state.userInteracted || !state.blob) return;
      if (!mutations.some(mutationAffectsMapContent)) return;
      clearTimeout(state.refreshTimer);
      state.refreshTimer = setTimeout(() => {
        if (
          stateIsCurrent(state) &&
          !state.userInteracted &&
          (!state.fullViewSignature || viewSignature(state.mapElement) === state.fullViewSignature)
        ) {
          captureInitialSnapshot(state, true);
        }
      }, 320);
    });
    state.observer.observe(state.mapElement, {
      childList: true,
      subtree: true,
      attributes: true,
      characterData: true,
      attributeFilter: ["src", "d", "style"]
    });

    state.cleanup = () => {
      state.observer?.disconnect();
      clearTimeout(state.refreshTimer);
      for (const type of ["pointerdown", "wheel", "touchstart", "keydown"]) {
        state.mapElement.removeEventListener(type, markInteraction, { capture: true });
      }
    };
  }

  function resetSnapshot() {
    generation++;
    activeState?.cleanup?.();
    activeState = null;
    cachedBadgeRow = null;
    updateButton();
  }

  function ensureInitialSnapshot() {
    if (!settings.mapCopy || !isSessionMapPage() || typeof window.html2canvas !== "function") return;
    const mapElement = findMapElement();
    if (!mapElement) return;
    const key = sessionKey();
    lastRoute = key;
    if (activeState && activeState.key === key && activeState.mapElement === mapElement) return;

    resetSnapshot();
    const state = {
      key,
      mapElement,
      generation,
      status: "waiting",
      blob: null,
      error: null,
      userInteracted: false,
      capturePromise: null,
      retryCount: 0,
      observer: null,
      refreshTimer: null,
      cleanup: null
    };
    activeState = state;
    observeState(state);
    captureInitialSnapshot(state);
  }

  async function copyCachedMap(button) {
    if (copyInProgress) return;
    if (!activeState?.blob) {
      if (activeState?.status === "failed" || activeState?.status === "missed") {
        toast("Full-map snapshot unavailable. Refresh before zooming.");
        return;
      }

      // On marker-heavy 24/7 sessions the user can click before the cached
      // PNG has finished encoding. Keep the click alive and copy as soon as
      // the initial untouched view is ready instead of making them retry.
      copyInProgress = true;
      button.disabled = true;
      button.textContent = "Preparing…";
      toast("Preparing the full map…");
      const deadline = Date.now() + READY_TIMEOUT + 2_500;
      while (!activeState?.blob && Date.now() < deadline) {
        if (!activeState || activeState.status === "failed" || activeState.status === "missed") break;
        await wait(90);
      }
      button.disabled = false;
      copyInProgress = false;
      updateButton();
      if (!activeState?.blob) {
        toast("Full-map snapshot unavailable. Refresh the session and try again.");
        return;
      }
    }
    if (activeState.key !== sessionKey()) {
      toast("Session changed. Waiting for a new map snapshot.");
      return;
    }

    copyInProgress = true;
    const original = button.innerHTML;
    button.disabled = true;
    button.classList.add("np-map-capture-busy");
    button.textContent = "Copying…";
    try {
      if (typeof ClipboardItem !== "function" || !navigator.clipboard?.write) throw new Error("Image clipboard is unavailable");
      await navigator.clipboard.write([new ClipboardItem({ "image/png": activeState.blob })]);
      toast("Full map copied ✓");
    } catch (error) {
      console.warn("[Noble Toolkit] Map clipboard copy failed", error);
      toast(`Copy failed: ${error?.message || "unknown error"}`);
    } finally {
      button.innerHTML = original;
      button.disabled = false;
      button.classList.remove("np-map-capture-busy");
      copyInProgress = false;
      updateButton();
    }
  }

  let scheduled = false;
  function scheduleBoot() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      placeButton();
      ensureInitialSnapshot();
    }, 20);
  }

  NPSettings.load().then((loaded) => {
    settings = loaded;
    scheduleBoot();
  }).catch(scheduleBoot);

  new MutationObserver(scheduleBoot).observe(document.documentElement, { childList: true, subtree: true });

  setInterval(() => {
    const route = sessionKey();
    if (route !== lastRoute) {
      lastRoute = route;
      resetSnapshot();
      scheduleBoot();
    }
  }, 500);

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[NPSettings.STORAGE_KEY]) {
        settings = NPSettings.sanitize(changes[NPSettings.STORAGE_KEY].newValue);
        if (!settings.mapCopy) resetSnapshot();
        scheduleBoot();
      }
    });
  } catch {}
})();
