// Per-row leaderboard actions. Uses the shared Bottom-N mode settings.
(() => {
  "use strict";

  const ROW_WRAP_CLASS = "np-lb-row-actions-v1";
  const TOAST_ID = "np-lb-toast-v1";
  let settings = NPSettings.cloneDefaults();
  let idCache = {};
  let idCacheLoadedAt = 0;

  const isLeaderboardPage = () => /^\/leaderboards\/[^/]+/i.test(location.pathname);
  const currentRule = () => NPSettings.modeConfig(settings, NPSettings.detectMode());

  function normalizeName(raw) {
    const normalized = String(raw || "")
      .normalize("NFKC")
      .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
    const normKey = normalized.replace(/[^\p{L}\p{N}\s]+/gu, "").replace(/\s+/g, " ").trim();
    return { normKey, looseKey: normKey.replace(/\s+/g, "") };
  }

  function editDistance(a = "", b = "") {
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    const row = Array.from({ length: b.length + 1 }, (_, index) => index);
    for (let i = 1; i <= a.length; i++) {
      let diagonal = row[0];
      row[0] = i;
      for (let j = 1; j <= b.length; j++) {
        const previous = row[j];
        row[j] = Math.min(row[j] + 1, row[j - 1] + 1, diagonal + (a[i - 1] === b[j - 1] ? 0 : 1));
        diagonal = previous;
      }
    }
    return row[b.length];
  }

  function resolveDiscordId(name, cache) {
    const { normKey, looseKey } = normalizeName(name);
    if (!normKey || !looseKey) return null;
    if (cache[normKey]) return cache[normKey];
    if (cache[looseKey]) return cache[looseKey];

    let substringMatch = null;
    for (const [key, id] of Object.entries(cache)) {
      const candidate = normalizeName(key).looseKey;
      if (!candidate) continue;
      if (candidate === looseKey) return id;
      if (Math.min(candidate.length, looseKey.length) < 4) continue;
      if (candidate.includes(looseKey) || looseKey.includes(candidate)) {
        const score = Math.abs(candidate.length - looseKey.length);
        if (!substringMatch || score < substringMatch.score) substringMatch = { id, score };
      }
    }
    if (substringMatch) return substringMatch.id;

    let fuzzyMatch = null;
    for (const [key, id] of Object.entries(cache)) {
      const candidate = normalizeName(key).looseKey;
      if (!candidate || Math.abs(candidate.length - looseKey.length) > 2) continue;
      const distance = editDistance(looseKey, candidate);
      if (!fuzzyMatch || distance < fuzzyMatch.distance) fuzzyMatch = { id, distance };
    }
    const maxDistance = looseKey.length < 6 ? 1 : 2;
    return fuzzyMatch && fuzzyMatch.distance <= maxDistance ? fuzzyMatch.id : null;
  }

  function storageGet(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(keys, (items) => resolve(items || {}));
      } catch {
        resolve({});
      }
    });
  }

  async function refreshCache(force = false) {
    if (!force && Date.now() - idCacheLoadedAt < 8000) return idCache;
    const stored = await storageGet(["np_id_cache_v1"]);
    idCache = stored.np_id_cache_v1 || {};
    idCacheLoadedAt = Date.now();
    return idCache;
  }

  function parseLeaderboardRow(element) {
    if (!element || element.tagName !== "TR") return null;
    const cell = Array.from(element.children || []).find((child) => child.tagName === "TD");
    const shell = cell?.firstElementChild;
    const columns = Array.from(shell?.children || []);
    if (columns.length < 6) return null;

    const rank = Number.parseInt((columns[0].textContent || "").trim(), 10);
    const matches = Number.parseInt((columns[3].textContent || "").trim(), 10);
    if (!Number.isFinite(rank) || rank < 1 || rank > 500 || !Number.isFinite(matches)) return null;

    let elements = Array.from(columns[1].querySelectorAll("span")).filter((span) =>
      String(span.className || "").includes("text-[var(--yellow)]")
    );
    if (!elements.length) {
      elements = Array.from(columns[1].querySelectorAll("span")).filter((span) => {
        if (span.closest(`.${ROW_WRAP_CLASS}`)) return false;
        const text = (span.textContent || "").trim();
        return text.length >= 2 && text.length <= 64 && text !== "+" && !/^\d+(?:\.\d+)?$/.test(text);
      });
    }
    const players = elements
      .map((el) => ({ el, text: (el.textContent || "").replace(/\s+/g, " ").trim() }))
      .filter(({ text }) => Boolean(text));
    return players.length ? { rank, matches, players, shell } : null;
  }

  function toast(message) {
    let element = document.getElementById(TOAST_ID);
    if (!element) {
      element = document.createElement("div");
      element.id = TOAST_ID;
      Object.assign(element.style, {
        position: "fixed", left: "50%", top: "18px", transform: "translateX(-50%)", zIndex: "2147483647",
        maxWidth: "84vw", padding: "9px 12px", border: "1px solid rgba(255,191,64,.28)", borderRadius: "8px",
        color: "#fff", background: "#0f1c25",
        boxShadow: "0 12px 34px rgba(0,0,0,.4)",
        font: "600 12px/1.35 Gilroy,Segoe UI,Arial,sans-serif", display: "none"
      });
      document.body.appendChild(element);
    }
    element.textContent = message;
    element.style.display = "block";
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => { element.style.display = "none"; }, 1500);
  }

  function looksLikeRow(element) {
    if (!parseLeaderboardRow(element)) return false;
    const rect = element.getBoundingClientRect();
    return rect.height >= 18 && rect.height <= 220 && rect.width >= 180;
  }

  function findRows() {
    const elements = Array.from(document.querySelectorAll("tbody > tr, tr")).filter(looksLikeRow);
    const byRank = new Map();
    for (const element of elements) {
      if (element.closest(`.${ROW_WRAP_CLASS}`)) continue;
      const parsed = parseLeaderboardRow(element);
      if (!parsed) continue;
      const { rank } = parsed;
      const previous = byRank.get(rank);
      if (!previous || element.getBoundingClientRect().height < previous.el.getBoundingClientRect().height) {
        byRank.set(rank, { el: element, rank, parsed });
      }
    }
    return Array.from(byRank.values()).sort((a, b) => a.rank - b.rank);
  }

  function extractMatchesPlayed(rowElement) {
    return parseLeaderboardRow(rowElement)?.matches ?? null;
  }

  function nameCandidates(rowElement) {
    return parseLeaderboardRow(rowElement)?.players || [];
  }

  function extractLeftName(rowElement) {
    return nameCandidates(rowElement)[0]?.text || null;
  }

  function bottomRanks(rows, minMatches, count) {
    const ranks = new Set();
    for (let index = rows.length - 1; index >= 0 && ranks.size < count; index--) {
      const matches = extractMatchesPlayed(rows[index].el);
      if (matches != null && matches >= minMatches) ranks.add(rows[index].rank);
    }
    return ranks;
  }

  function styleButton(button, role = false) {
    Object.assign(button.style, {
      padding: "4px 7px", borderRadius: "9px", border: `1px solid ${role ? "rgba(251,113,133,.28)" : "rgba(255,255,255,.14)"}`,
      background: role ? "rgba(244,63,94,.08)" : "rgba(255,255,255,.045)", color: role ? "#fecdd3" : "#e8eaeb",
      cursor: "pointer", font: "600 11px/1 Gilroy,Segoe UI,Arial,sans-serif", whiteSpace: "nowrap"
    });
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        window.prompt("Copy:", text);
        return true;
      } catch {
        return false;
      }
    }
  }

  function makeActionButton(playerName, kind) {
    const button = document.createElement("button");
    button.type = "button";
    button.dataset.kind = kind;
    button.textContent = kind === "id" ? "Copy ID" : "*role bott";
    styleButton(button, kind === "role");
    button.addEventListener("click", async (event) => {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      // Always refresh here so buttons created before a new session cache update
      // never hold on to a stale cache object.
      const cache = await refreshCache(true);
      const id = resolveDiscordId(playerName, cache);
      if (!id) {
        toast(`Missing ID for ${playerName}. Refresh a session page once.`);
        return;
      }
      const output = kind === "role" ? `*role ${id} bott` : String(id);
      const copied = await copyText(output);
      toast(copied ? (kind === "role" ? "Role command copied" : `Copied ID ${id}`) : "Copy failed");
    });
    return button;
  }

  function ensureActions(rowElement, rank, isBottom) {
    const candidates = nameCandidates(rowElement);
    const wrappers = Array.from(rowElement.querySelectorAll(`.${ROW_WRAP_CLASS}`));
    const liveKeys = new Set();

    candidates.forEach(({ el, text }, index) => {
      const baseKey = normalizeName(text).looseKey || `player-${index}`;
      const playerKey = `${baseKey}:${index}`;
      liveKeys.add(playerKey);
      let wrapper = wrappers.find((item) => item.dataset.playerKey === playerKey);

      if (!wrapper) {
        wrapper = document.createElement("span");
        wrapper.className = ROW_WRAP_CLASS;
        wrapper.dataset.playerKey = playerKey;
        wrapper.dataset.playerName = text;
        Object.assign(wrapper.style, { display: "inline-flex", alignItems: "center", gap: "5px", marginLeft: "6px", marginRight: "2px", verticalAlign: "middle", flex: "0 0 auto" });
        wrapper.appendChild(makeActionButton(text, "id"));
        try {
          el.insertAdjacentElement("afterend", wrapper);
        } catch {
          rowElement.appendChild(wrapper);
        }
      }

      wrapper.dataset.rank = String(rank);
      const roleButton = wrapper.querySelector('button[data-kind="role"]');
      if (isBottom && !roleButton) wrapper.appendChild(makeActionButton(text, "role"));
      if (!isBottom && roleButton) roleButton.remove();
    });

    wrappers.forEach((wrapper) => {
      if (!liveKeys.has(wrapper.dataset.playerKey || "")) wrapper.remove();
    });
  }

  function removeUi() {
    document.querySelectorAll(`.${ROW_WRAP_CLASS}`).forEach((element) => element.remove());
    document.getElementById(TOAST_ID)?.remove();
  }

  let scheduled = false;
  async function tick() {
    scheduled = false;
    if (!isLeaderboardPage() || !settings.rowActions) {
      removeUi();
      return;
    }

    const rows = findRows();
    if (!rows.length) return;
    const rule = currentRule();
    const ranks = bottomRanks(rows, rule.minMatches, rule.bottomCount);
    for (const row of rows) ensureActions(row.el, row.rank, ranks.has(row.rank));

    // Remove actions from React-recycled elements no longer recognized as rows.
    const liveRows = new Set(rows.map(({ el }) => el));
    document.querySelectorAll(`.${ROW_WRAP_CLASS}`).forEach((wrapper) => {
      if (!Array.from(liveRows).some((element) => element.contains(wrapper))) wrapper.remove();
    });
  }

  function scheduleTick() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(tick, 180);
  }

  NPSettings.load().then((loaded) => {
    settings = loaded;
    scheduleTick();
  }).catch(scheduleTick);

  new MutationObserver(scheduleTick).observe(document.documentElement, { childList: true, subtree: true });

  let lastRoute = location.pathname + location.search;
  setInterval(() => {
    const route = location.pathname + location.search;
    if (route !== lastRoute) {
      lastRoute = route;
      scheduleTick();
    }
  }, 700);

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== "local") return;
      if (changes.np_id_cache_v1) idCacheLoadedAt = 0;
      if (changes[NPSettings.STORAGE_KEY]) settings = NPSettings.sanitize(changes[NPSettings.STORAGE_KEY].newValue);
      scheduleTick();
    });
  } catch {}
})();
