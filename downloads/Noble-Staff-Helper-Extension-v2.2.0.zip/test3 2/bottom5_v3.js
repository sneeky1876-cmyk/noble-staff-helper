// Bulk leaderboard actions with per-mode Bottom-N settings.
(() => {
  "use strict";

  const BAR_ID = "np-lb-actions-bar-v3";
  const BTN_ID = "np-bottom5-btn-v3";
  const ROLE_BTN_ID = "np-bottom5-role-btn-v3";
  const PANEL_ID = "np-bottom5-panel-v3";
  const SEARCH_GAP = 28;
  const SCROLLED_RIGHT_GUTTER = 4;
  let settings = NPSettings.cloneDefaults();

  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const isLeaderboardPage = () => /^\/leaderboards\/[^/]+/i.test(location.pathname);
  const currentRule = () => NPSettings.modeConfig(settings, NPSettings.detectMode());

  function normalizeName(raw) {
    const normalized = String(raw || "")
      .normalize("NFKC")
      .replace(/[\u200B-\u200F\u202A-\u202E\u2060-\u206F\uFEFF]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
    const normKey = normalized.replace(/[^\p{L}\p{N}\s]+/gu, "").replace(/\s+/g, " ").trim();
    return { normKey, looseKey: normKey.replace(/\s+/g, "") };
  }

  function editDistance(a = "", b = "") {
    if (!a.length) return b.length;
    if (!b.length) return a.length;
    const row = Array.from({ length: b.length + 1 }, (_, index) => index);
    for (let i = 1; i <= a.length; i++) {
      let diagonal = row[0];
      row[0] = i;
      for (let j = 1; j <= b.length; j++) {
        const previous = row[j];
        row[j] = Math.min(row[j] + 1, row[j - 1] + 1, diagonal + (a[i - 1] === b[j - 1] ? 0 : 1));
        diagonal = previous;
      }
    }
    return row[b.length];
  }

  function resolveDiscordId(name, cache) {
    const { normKey, looseKey } = normalizeName(name);
    if (!normKey || !looseKey) return null;
    if (cache[normKey]) return cache[normKey];
    if (cache[looseKey]) return cache[looseKey];

    let substringMatch = null;
    for (const [key, id] of Object.entries(cache)) {
      const candidate = normalizeName(key).looseKey;
      if (!candidate) continue;
      if (candidate === looseKey) return id;
      if (Math.min(candidate.length, looseKey.length) < 4) continue;
      if (candidate.includes(looseKey) || looseKey.includes(candidate)) {
        const score = Math.abs(candidate.length - looseKey.length);
        if (!substringMatch || score < substringMatch.score) substringMatch = { id, score };
      }
    }
    if (substringMatch) return substringMatch.id;

    let fuzzyMatch = null;
    for (const [key, id] of Object.entries(cache)) {
      const candidate = normalizeName(key).looseKey;
      if (!candidate || Math.abs(candidate.length - looseKey.length) > 2) continue;
      const distance = editDistance(looseKey, candidate);
      if (!fuzzyMatch || distance < fuzzyMatch.distance) fuzzyMatch = { id, distance };
    }
    const maxDistance = looseKey.length < 6 ? 1 : 2;
    return fuzzyMatch && fuzzyMatch.distance <= maxDistance ? fuzzyMatch.id : null;
  }

  function storageGet(keys) {
    return new Promise((resolve) => {
      try {
        chrome.storage.local.get(keys, (items) => resolve(items || {}));
      } catch {
        resolve({});
      }
    });
  }

  function parseLeaderboardRow(element) {
    if (!element || element.tagName !== "TR") return null;
    const cell = Array.from(element.children || []).find((child) => child.tagName === "TD");
    const shell = cell?.firstElementChild;
    const columns = Array.from(shell?.children || []);
    if (columns.length < 6) return null;

    const rank = Number.parseInt((columns[0].textContent || "").trim(), 10);
    const matches = Number.parseInt((columns[3].textContent || "").trim(), 10);
    if (!Number.isFinite(rank) || rank < 1 || rank > 500 || !Number.isFinite(matches)) return null;

    let nameElements = Array.from(columns[1].querySelectorAll("span")).filter((span) =>
      String(span.className || "").includes("text-[var(--yellow)]")
    );
    if (!nameElements.length) {
      nameElements = Array.from(columns[1].querySelectorAll("span")).filter((span) => {
        if (span.closest(`#${BAR_ID}, .np-lb-row-actions-v1`)) return false;
        const text = (span.textContent || "").trim();
        return text.length >= 2 && text.length <= 64 && text !== "+" && !/^\d+(?:\.\d+)?$/.test(text);
      });
    }
    const names = [...new Set(nameElements.map((span) => (span.textContent || "").replace(/\s+/g, " ").trim()).filter(Boolean))];
    if (!names.length) return null;
    return { rank, matches, names, shell };
  }

  function looksLikeLeaderboardRow(element) {
    if (!parseLeaderboardRow(element)) return false;
    const rect = element.getBoundingClientRect();
    return rect.height >= 18 && rect.height <= 220 && rect.width >= 180;
  }

  function findLeaderboardRows() {
    const elements = Array.from(document.querySelectorAll("tbody > tr, tr")).filter(looksLikeLeaderboardRow);
    const byRank = new Map();
    for (const element of elements) {
      const parsed = parseLeaderboardRow(element);
      if (!parsed) continue;
      const { rank } = parsed;
      const previous = byRank.get(rank);
      if (!previous || element.getBoundingClientRect().height < previous.el.getBoundingClientRect().height) {
        byRank.set(rank, { el: element, rank, parsed });
      }
    }
    return Array.from(byRank.values()).sort((a, b) => a.rank - b.rank);
  }

  function extractMatchesPlayed(rowElement) {
    return parseLeaderboardRow(rowElement)?.matches ?? null;
  }

  function extractPlayerNames(rowElement) {
    return parseLeaderboardRow(rowElement)?.names || [];
  }

  function pickBottom(rows, minMatches, count) {
    const selected = [];
    for (let index = rows.length - 1; index >= 0 && selected.length < count; index--) {
      const matches = extractMatchesPlayed(rows[index].el);
      if (matches != null && matches >= minMatches) selected.push(rows[index]);
    }
    return selected;
  }

  function ensurePanel() {
    let panel = document.getElementById(PANEL_ID);
    if (panel) return panel;
    panel = document.createElement("div");
    panel.id = PANEL_ID;
    Object.assign(panel.style, {
      position: "fixed", right: "16px", top: "76px", zIndex: "2147483647",
      maxWidth: "370px", padding: "12px 14px", border: "1px solid rgba(255,191,64,.28)",
      borderRadius: "9px", color: "#fff", background: "#0f1c25",
      boxShadow: "0 12px 34px rgba(0,0,0,.4)",
      font: "12px/1.4 Gilroy,Segoe UI,Arial,sans-serif", display: "none"
    });
    document.body.appendChild(panel);
    return panel;
  }

  function showPanel(title, messages) {
    const panel = ensurePanel();
    panel.replaceChildren();
    const heading = document.createElement("strong");
    heading.textContent = title;
    panel.appendChild(heading);
    for (const message of messages) {
      const line = document.createElement("div");
      line.textContent = message;
      line.style.marginTop = "6px";
      line.style.color = "rgba(226,232,240,.76)";
      panel.appendChild(line);
    }
    panel.style.display = "block";
    clearTimeout(showPanel.timer);
    showPanel.timer = setTimeout(() => { panel.style.display = "none"; }, 3200);
  }

  function styleButton(button) {
    Object.assign(button.style, {
      padding: "7px 10px", borderRadius: "10px", border: "1px solid rgba(255,255,255,.14)",
      background: "#1a2c38", color: "#fff", cursor: "pointer",
      font: "600 12px/1 Gilroy,Segoe UI,Arial,sans-serif", whiteSpace: "nowrap"
    });
  }

  function ensureBar() {
    let bar = document.getElementById(BAR_ID);
    if (bar) return bar;
    bar = document.createElement("div");
    bar.id = BAR_ID;
    Object.assign(bar.style, { position: "fixed", zIndex: "2147483647", display: "inline-flex", alignItems: "center", gap: "6px", top: "16px", right: "16px" });

    const bottomButton = document.createElement("button");
    bottomButton.id = BTN_ID;
    bottomButton.type = "button";
    styleButton(bottomButton);
    bottomButton.addEventListener("click", copyBottomMentions);

    const roleButton = document.createElement("button");
    roleButton.id = ROLE_BTN_ID;
    roleButton.type = "button";
    styleButton(roleButton);
    roleButton.addEventListener("click", copyRoleCommands);

    bar.append(bottomButton, roleButton);
    document.body.appendChild(bar);
    return bar;
  }

  function findSearchInput() {
    return Array.from(document.querySelectorAll("input")).find((input) => {
      const placeholder = (input.placeholder || "").toLowerCase();
      return placeholder.includes("search") && placeholder.includes("player");
    }) || document.querySelector('input[type="search"]');
  }

  function findSearchAnchor(input) {
    if (!input) return null;
    const inputRect = input.getBoundingClientRect();
    let anchor = input;
    let current = input.parentElement;

    // NoblePrac renders the border on a wrapper around the actual input. Use
    // that visible shell, but stop before climbing into the whole toolbar.
    for (let depth = 0; current && depth < 4; depth++, current = current.parentElement) {
      const rect = current.getBoundingClientRect();
      if (rect.width > inputRect.width + 90 || rect.height > Math.max(64, inputRect.height + 28)) break;
      if (rect.width >= inputRect.width && rect.height >= inputRect.height) anchor = current;
    }
    return anchor;
  }

  function positionBar() {
    const bar = document.getElementById(BAR_ID);
    if (!bar) return;
    const barRect = bar.getBoundingClientRect();
    let left = window.innerWidth - barRect.width - SCROLLED_RIGHT_GUTTER;
    let top = 12;
    const input = findSearchInput();
    const searchAnchor = findSearchAnchor(input);
    if (searchAnchor) {
      const rect = searchAnchor.getBoundingClientRect();
      if (rect.width > 80 && rect.height > 18 && rect.bottom > 0 && rect.top < window.innerHeight) {
        top = rect.top + (rect.height - barRect.height) / 2;
        left = rect.left - barRect.width - SEARCH_GAP;
        // On narrow layouts, put the actions above the search instead of in
        // the pagination area to its right.
        if (left < 8) {
          left = rect.left;
          top = rect.top - barRect.height - 10;
        }
      }
    }
    bar.style.left = `${clamp(left, SCROLLED_RIGHT_GUTTER, window.innerWidth - barRect.width - SCROLLED_RIGHT_GUTTER)}px`;
    bar.style.top = `${clamp(top, 8, window.innerHeight - barRect.height - 8)}px`;
    bar.style.right = "auto";
  }

  async function computeSelection() {
    const rule = currentRule();
    const rows = findLeaderboardRows();
    const picked = pickBottom(rows, rule.minMatches, rule.bottomCount);
    const stored = await storageGet(["np_id_cache_v1"]);
    const cache = stored.np_id_cache_v1 || {};
    const resolved = [];
    const missing = [];
    const seenIds = new Set();
    const seenMissing = new Set();
    for (const row of picked) {
      const names = extractPlayerNames(row.el);
      if (!names.length) {
        if (!seenMissing.has("Unknown player")) missing.push("Unknown player");
        seenMissing.add("Unknown player");
        continue;
      }
      for (const name of names) {
        const id = resolveDiscordId(name, cache);
        if (id && !seenIds.has(String(id))) {
          seenIds.add(String(id));
          resolved.push({ name, id: String(id) });
        } else if (!id && !seenMissing.has(name)) {
          seenMissing.add(name);
          missing.push(name);
        }
      }
    }
    return { rule, rows, picked, resolved, missing, cacheSize: Object.keys(cache).length };
  }

  async function copyText(text) {
    try {
      await navigator.clipboard.writeText(text);
      return true;
    } catch {
      try {
        window.prompt("Copy:", text);
        return true;
      } catch {
        return false;
      }
    }
  }

  function selectionProblem(result) {
    const { rule, picked, resolved, cacheSize } = result;
    if (!picked.length) {
      showPanel(`Bottom ${rule.bottomCount} · ${rule.label}`, [`No eligible teams found. Minimum games: ${rule.minMatches}.`]);
      return true;
    }
    if (!resolved.length) {
      showPanel(`Bottom ${rule.bottomCount} · ${rule.label}`, ["No Discord IDs could be resolved.", `Cached name keys: ${cacheSize}. Open a session map to refresh IDs.`]);
      return true;
    }
    return false;
  }

  async function copyBottomMentions() {
    const result = await computeSelection();
    if (selectionProblem(result)) return;
    const output = `${result.resolved.map(({ id }) => `<@${id}>`).join(" ")} ${location.href}`;
    const copied = await copyText(output);
    const messages = [`${result.resolved.length} mention${result.resolved.length === 1 ? "" : "s"} ${copied ? "copied" : "ready"}.`];
    if (result.missing.length) messages.push(`Missing IDs: ${result.missing.slice(0, 6).join(", ")}${result.missing.length > 6 ? "…" : ""}`);
    showPanel(copied ? "Copied ✓" : "Copy failed", messages);
  }

  async function copyRoleCommands() {
    const result = await computeSelection();
    if (selectionProblem(result)) return;
    const output = result.resolved.map(({ id }) => `*role ${id} bott`).join("\n");
    const copied = await copyText(output);
    const messages = [`${result.resolved.length} role command${result.resolved.length === 1 ? "" : "s"} ${copied ? "copied" : "ready"}.`];
    if (result.missing.length) messages.push(`Missing IDs: ${result.missing.slice(0, 6).join(", ")}${result.missing.length > 6 ? "…" : ""}`);
    showPanel(copied ? "Copied ✓" : "Copy failed", messages);
  }

  function removeUi() {
    document.getElementById(BAR_ID)?.remove();
    document.getElementById(PANEL_ID)?.remove();
  }

  function tick() {
    if (!isLeaderboardPage() || !settings.leaderboardTools) {
      removeUi();
      return;
    }
    const bar = ensureBar();
    const rule = currentRule();
    const bottomButton = bar.querySelector(`#${BTN_ID}`);
    const roleButton = bar.querySelector(`#${ROLE_BTN_ID}`);
    const bottomLabel = `Copy bottom ${rule.bottomCount}`;
    if (bottomButton.textContent !== bottomLabel) bottomButton.textContent = bottomLabel;
    bottomButton.title = `${rule.label}: at least ${rule.minMatches} games`;
    if (roleButton.textContent !== "Copy roles") roleButton.textContent = "Copy roles";
    roleButton.title = `${rule.label}: Dyno role commands`;
    positionBar();
  }

  let scheduled = false;
  function scheduleTick() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      tick();
    }, 120);
  }

  let positionFrame = 0;
  function schedulePosition() {
    if (positionFrame) return;
    positionFrame = requestAnimationFrame(() => {
      positionFrame = 0;
      positionBar();
    });
  }

  NPSettings.load().then((loaded) => {
    settings = loaded;
    tick();
  }).catch(tick);

  window.addEventListener("resize", () => {
    schedulePosition();
    scheduleTick();
  }, { passive: true });
  window.addEventListener("scroll", schedulePosition, { passive: true });
  new MutationObserver(scheduleTick).observe(document.documentElement, { childList: true, subtree: true });

  let lastRoute = location.pathname + location.search;
  setInterval(() => {
    const route = location.pathname + location.search;
    if (route !== lastRoute) {
      lastRoute = route;
      scheduleTick();
    }
  }, 600);

  try {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && changes[NPSettings.STORAGE_KEY]) {
        settings = NPSettings.sanitize(changes[NPSettings.STORAGE_KEY].newValue);
        tick();
      }
    });
  } catch {}
})();
